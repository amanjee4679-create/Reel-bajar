# 📱 Reel Bajar - Android APK और AAB (Play Store) निर्माण संपूर्ण गाइड

Reel Bajar के पूरे प्रोजेक्ट सोर्स कोड में आपका स्वागत है!
इस फोल्डर में सभी React + Vite + Tailwind CSS + Capacitor और Android प्रोजेक्ट फाइल्स शामिल हैं।

---

## 🚀 तरीका 1: Capacitor + Android Studio से APK और AAB बनाएं (अनुशंसित)

### कदम 1: प्रोजेक्ट फोल्डर खोलें और लाइब्रेरी इंस्टॉल करें
टर्मिनल (VS Code / Terminal) में लिखें:
```bash
npm install
```

### कदम 2: प्रोडक्शन वेब बिल्ड बनाएं
```bash
npm run build
```

### कदम 3: Android प्रोजेक्ट सिंक करें
```bash
npx cap add android
npx cap sync
```

### कदम 4: Android Studio में प्रोजेक्ट खोलें
```bash
npx cap open android
```

### कदम 5 (A): टेस्टिंग के लिए Direct APK बनाएं
1. Android Studio में ऊपर मेनू बार में जाएँ:
   **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**
2. कुछ ही पलों में Android Studio नीचे दाईं ओर **locate** का विकल्प देगा।
3. आपकी `app-debug.apk` तैयार है! इसे किसी भी Android फ़ोन में भेजकर सीधे इंस्टॉल कर सकते हैं।

### कदम 5 (B): Google Play Store के लिए Signed AAB (App Bundle) बनाएं
1. Android Studio में ऊपर मेनू में जाएँ:
   **Build** -> **Generate Signed Bundle / APK...**
2. **Android App Bundle (.aab)** विकल्प चुनें और **Next** दबाएं।
3. अपना Keystore चुनें (यदि नया बनाना है तो 'Create new' दबाएं)।
4. **release** बिल्ड वेरिएंट चुनें और **Finish** दबाएं।
5. जनरेट हुई `app-release.aab` फाइल को Google Play Console पर अपलोड करें!

---

## ⚡ तरीका 2: Bubblewrap CLI से बिना Android Studio के डायरेक्ट कमांड लाइन बिल्ड

यदि आप Android Studio इंस्टॉल नहीं करना चाहते, तो Bubblewrap CLI से सीधे कमांड लाइन में AAB बना सकते हैं:

```bash
# 1. Bubblewrap इंस्टॉल करें
npm install -g @bubblewrap/cli

# 2. मैनिफेस्ट से प्रोजेक्ट इनिशियलाइज़ करें
bubblewrap init --manifest=https://ais-pre-3bea2vvonuz6powkikzq6e-572432472094.asia-southeast1.run.app/manifest.webmanifest

# 3. प्रोडक्शन AAB बंडल बिल्ड करें
bubblewrap build
```

---

## 🔑 रिलीज Keystore जनरेट करने का कमांड:
```bash
keytool -genkey -v -keystore reelbajar-release.keystore -alias reelbajar -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Reel Bajar, OU=App, O=Reel Bajar Commerce, L=Bengaluru, ST=Karnataka, C=IN"
```

---

## 📂 फ़ाइल संरचना (Project Structure):
- `src/` - सभी कंपोनेंट्स (Reels Player, Bazaar, Direct Chat, Studio, Profile, Cart)
- `public/` - PWA Manifest, HD Icons (192 & 512), Service Worker (sw.js)
- `capacitor.config.json` - Android App Configuration
- `android/` - Native Android Studio Manifest & Gradle Settings
- `vite.config.ts` - Vite Bundler & Headers Configuration
