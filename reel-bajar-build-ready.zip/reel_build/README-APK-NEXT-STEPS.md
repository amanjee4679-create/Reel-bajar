# Reel Bajar — APK build

The source is a React/Vite project. The included Android folder is now a standalone Android Studio project for a quick APK test build. It opens the current Reel Bajar web app in a native Android WebView.

## Build APK in Android Studio
1. Install Android Studio (with Android SDK 35 and JDK 17).
2. Open this `android` folder.
3. Let Gradle sync finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be under `android/app/build/outputs/apk/debug/app-debug.apk`.

## Important
For a production Play Store release, the React/Vite `dist` output should be packaged through Capacitor instead of the temporary WebView wrapper. The source already contains `capacitor.config.json`; internet access is required to install Capacitor packages.
