import { ChatConversation } from '../types';

export const INITIAL_CONVERSATIONS: ChatConversation[] = [
  {
    id: 'conv_priya',
    participantId: 'seller_priya',
    participantName: 'Priya Sharma (प्रिया)',
    participantAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    participantHandle: '@priyastyle_in',
    participantCity: 'Varanasi, UP',
    isVerified: true,
    isOnline: true,
    lastSeen: 'Active now',
    lastMessage: 'हाँ जी, यह पीस आज ही डिस्पैच हो सकता है!',
    lastTimestamp: '10:45 AM',
    unreadCount: 1,
    messages: [
      {
        id: 'm1',
        senderId: 'seller_priya',
        senderName: 'Priya Sharma',
        text: 'नमस्ते! रील बाज़ार में आपका स्वागत है। हमारे पास सीधे वाराणसी के बुनकरों से तैयार असली सिल्क साड़ियां उपलब्ध हैं। 🙏✨',
        timestamp: '10:40 AM',
        isSender: false,
        status: 'read'
      },
      {
        id: 'm2',
        senderId: 'user',
        senderName: 'You',
        text: 'नमस्ते दीदी, क्या इस बनारसी साड़ी के साथ मैचिंग ब्लाउज पीस भी शामिल है?',
        timestamp: '10:42 AM',
        isSender: true,
        status: 'read',
        productAttachment: {
          id: 'prod-1',
          title: 'Varanasi Pure Soft Silk Handloom Saree (Maroon & Antique Gold)',
          price: 1899,
          originalPrice: 4999,
          image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80',
          category: 'Fashion'
        }
      },
      {
        id: 'm3',
        senderId: 'seller_priya',
        senderName: 'Priya Sharma',
        text: 'हाँ बिल्कुल! 5.5 मीटर साड़ी के साथ 0.8 मीटर का हेवी जरी वर्क वाला अनस्टिच्ड ब्लाउज पीस बिल्कुल फ्री शामिल है।',
        timestamp: '10:43 AM',
        isSender: false,
        status: 'read'
      },
      {
        id: 'm4',
        senderId: 'user',
        senderName: 'You',
        text: 'और कैश ऑन डिलीवरी (COD) उपलब्ध है क्या?',
        timestamp: '10:44 AM',
        isSender: true,
        status: 'read'
      },
      {
        id: 'm5',
        senderId: 'seller_priya',
        senderName: 'Priya Sharma',
        text: 'हाँ जी, यह पीस आज ही डिस्पैच हो सकता है! पूरे भारत में Cash on Delivery और फ्री शिपिंग उपलब्ध है।',
        timestamp: '10:45 AM',
        isSender: false,
        status: 'delivered'
      }
    ]
  },
  {
    id: 'conv_rohit',
    participantId: 'seller_rohit',
    participantName: 'Tech Rohit (रोहित)',
    participantAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    participantHandle: '@gadgetguy_rohit',
    participantCity: 'Bengaluru, KA',
    isVerified: true,
    isOnline: true,
    lastSeen: 'Active now',
    lastMessage: 'AuraPods Pro ke saath 1 saal ki direct door-step replacement warranty hai.',
    lastTimestamp: 'Yesterday',
    unreadCount: 0,
    messages: [
      {
        id: 'mr1',
        senderId: 'seller_rohit',
        senderName: 'Tech Rohit',
        text: 'AuraPods Pro ANC TWS ke baare me koi sawal ho to batayein! Gaming mode me latency sirf 45ms hai.',
        timestamp: 'Yesterday 4:15 PM',
        isSender: false,
        status: 'read',
        productAttachment: {
          id: 'prod-2',
          title: 'AuraPods Pro ANC Wireless Earbuds (50hr Playtime & Super Bass)',
          price: 999,
          originalPrice: 2999,
          image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80',
          category: 'Electronics'
        }
      },
      {
        id: 'mr2',
        senderId: 'user',
        senderName: 'You',
        text: 'Bhai warranty claim kaise hoti hai agar issue aaye to?',
        timestamp: 'Yesterday 4:20 PM',
        isSender: true,
        status: 'read'
      },
      {
        id: 'mr3',
        senderId: 'seller_rohit',
        senderName: 'Tech Rohit',
        text: 'AuraPods Pro ke saath 1 saal ki direct door-step replacement warranty hai.',
        timestamp: 'Yesterday 4:22 PM',
        isSender: false,
        status: 'read'
      }
    ]
  },
  {
    id: 'conv_kabir',
    participantId: 'seller_kabir',
    participantName: 'Artisan Kabir (कबीर)',
    participantAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
    participantHandle: '@kabir_crafts',
    participantCity: 'Kanpur, UP',
    isVerified: true,
    isOnline: false,
    lastSeen: '15m ago',
    lastMessage: 'हम वॉलेट पर नाम भी गोल्ड फॉयल से लिख सकते हैं।',
    lastTimestamp: 'Sep 26',
    unreadCount: 0,
    messages: [
      {
        id: 'mk1',
        senderId: 'seller_kabir',
        senderName: 'Artisan Kabir',
        text: 'नमस्ते! हमारे सभी लेदर वॉलेट 100% असली फुल-ग्रेन बफेलो लेदर से हाथ से सिले जाते हैं।',
        timestamp: 'Sep 26',
        isSender: false,
        status: 'read',
        productAttachment: {
          id: 'prod-5',
          title: 'Handstitched Vintage Full-Grain Leather Wallet with RFID Shield',
          price: 699,
          originalPrice: 1899,
          image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=600&q=80',
          category: 'Accessories'
        }
      },
      {
        id: 'mk2',
        senderId: 'user',
        senderName: 'You',
        text: 'क्या इस पर कस्टम नाम प्रिंट हो सकता है गिफ्ट के लिए?',
        timestamp: 'Sep 26',
        isSender: true,
        status: 'read'
      },
      {
        id: 'mk3',
        senderId: 'seller_kabir',
        senderName: 'Artisan Kabir',
        text: 'जी हाँ, हम वॉलेट पर नाम भी गोल्ड फॉयल से लिख सकते हैं। ऑर्डर के बाद चैट में नाम भेज दीजिएगा।',
        timestamp: 'Sep 26',
        isSender: false,
        status: 'read'
      }
    ]
  }
];

export const AVAILABLE_SELLERS_FOR_CHAT = [
  {
    id: 'seller_priya',
    name: 'Priya Sharma (प्रिया)',
    handle: '@priyastyle_in',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    city: 'Varanasi, UP',
    isVerified: true,
    category: 'Handloom & Fashion',
    rating: 4.9
  },
  {
    id: 'seller_rohit',
    name: 'Tech Rohit (रोहित)',
    handle: '@gadgetguy_rohit',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    city: 'Bengaluru, KA',
    isVerified: true,
    category: 'Audio & Tech Gadgets',
    rating: 4.8
  },
  {
    id: 'seller_pooja',
    name: 'Chef Pooja (पूजा)',
    handle: '@healthy_bites_pooja',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    city: 'Surat, GJ',
    isVerified: false,
    category: 'Kitchen & Smart Living',
    rating: 4.7
  },
  {
    id: 'seller_simran',
    name: 'Simran Glow (सिमरन)',
    handle: '@simranglowup',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
    city: 'Haridwar, UK',
    isVerified: true,
    category: 'Ayurvedic Skincare',
    rating: 4.9
  },
  {
    id: 'seller_kabir',
    name: 'Artisan Kabir (कबीर)',
    handle: '@kabir_crafts',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
    city: 'Kanpur, UP',
    isVerified: true,
    category: 'Handmade Leathercraft',
    rating: 4.8
  }
];
