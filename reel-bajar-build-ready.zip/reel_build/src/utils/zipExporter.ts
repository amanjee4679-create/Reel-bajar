import JSZip from 'jszip';
import { saveAs } from './fileSaver';

export async function exportProjectZip(): Promise<void> {
  const zip = new JSZip();

  // Root configuration files
  zip.file('package.json', JSON.stringify({
    "name": "reel-bajar",
    "private": true,
    "version": "1.0.0",
    "type": "module",
    "scripts": {
      "dev": "vite --port=3000 --host=0.0.0.0",
      "build": "vite build",
      "preview": "vite preview",
      "cap:init": "cap init \"Reel Bajar\" com.reelbajar.app",
      "cap:add": "cap add android",
      "cap:sync": "cap sync",
      "cap:open": "cap open android",
      "build:apk": "npm run build && npx cap sync && npx cap open android"
    },
    "dependencies": {
      "@tailwindcss/vite": "^4.3.3",
      "@vitejs/plugin-react": "^6.1.1",
      "canvas-confetti": "^1.9.4",
      "jszip": "^3.10.1",
      "lucide-react": "^0.546.0",
      "motion": "^12.23.24",
      "react": "^19.0.1",
      "react-dom": "^19.0.1",
      "vite": "^8.3.0"
    },
    "devDependencies": {
      "@capacitor/android": "^6.0.0",
      "@capacitor/cli": "^6.0.0",
      "@capacitor/core": "^6.0.0",
      "@types/canvas-confetti": "^1.9.0",
      "@types/jszip": "^3.4.1",
      "@types/node": "^22.14.0",
      "@types/react": "^19.3.0",
      "@types/react-dom": "^19.3.0",
      "autoprefixer": "^10.4.21",
      "tailwindcss": "^4.3.3",
      "typescript": "^7.0.2"
    }
  }, null, 2));

  zip.file('vite.config.ts', `import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
  build: {
    outDir: 'dist',
  },
});
`);

  zip.file('tsconfig.json', JSON.stringify({
    "compilerOptions": {
      "target": "ES2022",
      "module": "ESNext",
      "lib": ["ES2022", "DOM", "DOM.Iterable"],
      "moduleResolution": "bundler",
      "jsx": "react-jsx",
      "paths": { "@/*": ["./*"] },
      "skipLibCheck": true,
      "noEmit": true
    }
  }, null, 2));

  zip.file('capacitor.config.json', JSON.stringify({
    "appId": "com.reelbajar.app",
    "appName": "Reel Bajar",
    "webDir": "dist",
    "server": {
      "androidScheme": "https"
    },
    "android": {
      "backgroundColor": "#0A0A0E",
      "allowMixedContent": true
    }
  }, null, 2));

  zip.file('index.html', `<!doctype html>
<html lang="hi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Reel Bajar - Short Video Shopping</title>
    <meta name="description" content="Reel Bajar (रील बाज़ार) - Social commerce short video reels app with product marketplace." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="manifest" href="/manifest.webmanifest" />
    <meta name="theme-color" content="#FF0055" />
  </head>
  <body class="bg-neutral-950 text-neutral-100 font-sans antialiased selection:bg-pink-500 selection:text-white overflow-x-hidden">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`);

  // Public folder
  const pub = zip.folder('public');
  pub?.file('manifest.webmanifest', JSON.stringify({
    "name": "Reel Bajar - रील बाज़ार",
    "short_name": "Reel Bajar",
    "description": "Short Video Shopping & Creator Marketplace in India",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#0a0a0a",
    "theme_color": "#FF0055",
    "orientation": "portrait",
    "categories": ["shopping", "entertainment", "social"]
  }, null, 2));

  // Android Studio Manifest Template
  const androidFolder = zip.folder('android-template');
  androidFolder?.file('AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.reelbajar.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.CAMERA" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Reel Bajar"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen">
        <activity
            android:name="com.reelbajar.app.MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`);

  androidFolder?.file('build.gradle', `apply plugin: 'com.android.application'

android {
    compileSdkVersion 34
    defaultConfig {
        applicationId "com.reelbajar.app"
        minSdkVersion 22
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
`);

  // Step by step Build Guide for APK/AAB
  zip.file('README-BUILD-APK-AAB.md', `# 📱 Reel Bajar - APK और AAB (Android App Bundle) निर्माण गाइड

यह Reel Bajar का संपूर्ण सोर्स कोड है। इससे आप **APK** (टेस्टिंग के लिए) और **AAB** (Google Play Store के लिए) आसानी से बना सकते हैं।

---

## 🛠️ तरीका 1: Capacitor के ज़रिए (सबसे आसान - 5 मिनट)

### कदम 1: डिपेंडेंसी इंस्टॉल करें
अपने कंप्यूटर (VS Code / Terminal) में यह प्रोजेक्ट अनज़िप करें और खोलें:
\`\`\`bash
npm install
\`\`\`

### कदम 2: ऐप बिल्ड करें
\`\`\`bash
npm run build
\`\`\`

### कदम 3: Android प्रोजेक्ट जोड़ें
\`\`\`bash
npx cap add android
npx cap sync
\`\`\`

### कदम 4: Android Studio में खोलें
\`\`\`bash
npx cap open android
\`\`\`

Android Studio खुल जाने के बाद:
1. ऊपर मेनू में जाएं: **Build** -> **Build Bundle(s) / APK(s)**
2. टेस्टिंग के लिए: **Build APK(s)** चुनें -> \`app-debug.apk\` तैयार हो जाएगी जिसे आप फोन में इंस्टॉल कर सकते हैं!
3. Play Store के लिए: **Generate Signed Bundle / APK** -> **Android App Bundle (.aab)** चुनें। अपना Keystore चुनें और Finish दबाएं!

---

## 🚀 तरीका 2: Bubblewrap TWA के ज़रिए (बिना Android Studio के कमांड लाइन से)

\`\`\`bash
# 1. Bubblewrap CLI इंस्टॉल करें
npm install -g @bubblewrap/cli

# 2. इनिशियलाइज़ करें
bubblewrap init --manifest=https://your-domain.com/manifest.webmanifest

# 3. रिलीज AAB बिल्ड करें
bubblewrap build
\`\`\`

---

## 🔑 रिलीज Keystore कमांड (Play Store Signing):
\`\`\`bash
keytool -genkey -v -keystore reelbajar-release.keystore -alias reelbajar -keyalg RSA -keysize 2048 -validity 10000
\`\`\`
`);

  // Generate the zip blob
  const content = await zip.generateAsync({ type: 'blob' });
  saveAs(content, 'reel-bajar-source-code.zip');
}
