import React, { useState } from 'react';
import { X, Send, Heart } from 'lucide-react';
import { CommentItem, UserProfile } from '../types';

interface CommentsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  comments: CommentItem[];
  onAddComment: (text: string) => void;
  onLikeComment: (commentId: string) => void;
  lang: 'hi' | 'en';
  currentUser: UserProfile | null;
  onRequireAuth: () => void;
}

export const CommentsDrawer: React.FC<CommentsDrawerProps> = ({
  isOpen,
  onClose,
  comments,
  onAddComment,
  onLikeComment,
  lang,
  currentUser,
  onRequireAuth
}) => {
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    if (!currentUser) {
      onRequireAuth();
      return;
    }
    onAddComment(inputText.trim());
    setInputText('');
  };

  const handleQuickEmoji = (emoji: string) => {
    setInputText(prev => prev + emoji);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs animate-fadeIn">
      {/* Background click dismiss */}
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full sm:max-w-md bg-neutral-900 border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl shadow-2xl h-[75vh] sm:h-[600px] flex flex-col z-10 overflow-hidden">
        {/* Drag handle */}
        <div className="w-12 h-1.5 bg-neutral-700 rounded-full mx-auto mt-3 mb-1 sm:hidden" />

        {/* Header */}
        <div className="px-5 py-3 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-sm text-white">
              {lang === 'hi' ? 'टिप्पणियाँ (कमेंट्स)' : 'Comments'}
            </h3>
            <span className="text-xs text-neutral-400 bg-neutral-800 px-2 py-0.5 rounded-full">
              {comments.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 no-scrollbar">
          {comments.length === 0 ? (
            <div className="text-center py-12 text-neutral-500 text-xs">
              {lang === 'hi' ? 'अभी तक कोई कमेंट नहीं है। पहले कमेंट करें!' : 'No comments yet. Be the first to comment!'}
            </div>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="flex items-start gap-3 group">
                <img
                  src={comment.avatar}
                  alt={comment.author}
                  className="w-8 h-8 rounded-full object-cover border border-neutral-700 mt-0.5 flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2">
                    <span className="text-xs font-semibold text-neutral-200 truncate">
                      {comment.author}
                    </span>
                    <span className="text-[10px] text-neutral-500">
                      {comment.timeAgo}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-300 mt-0.5 leading-relaxed break-words">
                    {comment.text}
                  </p>
                </div>
                <button
                  onClick={() => onLikeComment(comment.id)}
                  className="flex flex-col items-center gap-0.5 text-neutral-400 hover:text-pink-500 pt-1 transition-colors"
                >
                  <Heart
                    className={`w-3.5 h-3.5 ${
                      comment.isLiked ? 'fill-pink-500 text-pink-500' : 'text-neutral-400'
                    }`}
                  />
                  <span className="text-[10px]">{comment.likes}</span>
                </button>
              </div>
            ))
          )}
        </div>

        {/* Quick Emoji Bar */}
        <div className="px-4 py-1.5 border-t border-neutral-800/80 bg-neutral-950 flex items-center justify-between text-base">
          {['🔥', '😍', '🥻', '💯', '👌', '🛍️', '⚡'].map((emoji) => (
            <button
              key={emoji}
              type="button"
              onClick={() => handleQuickEmoji(emoji)}
              className="p-1 hover:scale-125 transition-transform"
            >
              {emoji}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="p-3 bg-neutral-900 border-t border-neutral-800 flex items-center gap-2">
          {currentUser ? (
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-7 h-7 rounded-full object-cover border border-neutral-700"
            />
          ) : (
            <div className="w-7 h-7 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center text-[10px] text-neutral-400">
              ?
            </div>
          )}
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              currentUser 
                ? (lang === 'hi' ? 'अपनी राय लिखें...' : 'Add a comment...')
                : (lang === 'hi' ? 'कमेंट करने के लिए लॉगिन करें...' : 'Login to comment...')
            }
            className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500 transition-colors"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2 rounded-xl bg-pink-600 text-white disabled:opacity-40 disabled:hover:bg-pink-600 hover:bg-pink-500 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
