import React, { useState } from 'react';
import { X, ShieldAlert, Flag, UserX, CheckCircle2 } from 'lucide-react';
import { ReelItem } from '../types';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reel: ReelItem | null;
  onReportReel: (reelId: string, reason: string) => void;
  onBlockCreator: (creatorName: string) => void;
  lang: 'hi' | 'en';
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  reel,
  onReportReel,
  onBlockCreator,
  lang
}) => {
  const [selectedReason, setSelectedReason] = useState<string>('counterfeit');
  const [otherText, setOtherText] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  if (!isOpen || !reel) return null;

  const reasons = [
    {
      id: 'counterfeit',
      titleHi: 'नकली या डुप्लीकेट सामान (Counterfeit Product)',
      titleEn: 'Counterfeit or Fake Product',
      descHi: 'वीडियो में दिखाया गया सामान ओरिजिनल नहीं लगता',
      descEn: 'Product appears to be a replica or counterfeit'
    },
    {
      id: 'misleading',
      titleHi: 'गलत या भ्रामक कीमत (Misleading Price / Offer)',
      titleEn: 'Misleading Price or False Claims',
      descHi: 'कीमत या डिस्काउंट सही नहीं है',
      descEn: 'Discounts or prices differ from checkout'
    },
    {
      id: 'inappropriate',
      titleHi: 'अनुचित या अश्लील सामग्री (Inappropriate Content)',
      titleEn: 'Inappropriate or Adult Content',
      descHi: 'वीडियो कम्युनिटी गाइडलाइन्स का उल्लंघन करता है',
      descEn: 'Violates community standards or decency'
    },
    {
      id: 'spam',
      titleHi: 'स्पैम या धोखाधड़ी (Spam / Scam)',
      titleEn: 'Spam, Fraud or Scam',
      descHi: 'बार-बार एक ही वीडियो या फर्जी सेलर',
      descEn: 'Suspicious seller or repetitive spam'
    }
  ];

  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    const finalReason = selectedReason === 'other' ? (otherText || 'Other issue') : selectedReason;
    onReportReel(reel.id, finalReason);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 1800);
  };

  const handleBlock = () => {
    onBlockCreator(reel.creator.name);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl p-6 text-neutral-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">
                {lang === 'hi' ? 'सामग्री रिपोर्ट व सुरक्षा' : 'Report & Moderation'}
              </h3>
              <p className="text-[10px] text-neutral-400">
                {reel.creator.name} ({reel.product.title.slice(0, 24)}...)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-sm font-bold text-white">
              {lang === 'hi' ? 'आपकी रिपोर्ट दर्ज कर ली गई है' : 'Report Submitted'}
            </h4>
            <p className="text-xs text-neutral-400 max-w-xs mx-auto">
              {lang === 'hi'
                ? 'यह रील अब आपकी फीड में नहीं दिखेगी। हमारी मॉडरेशन टीम 2 घंटे के अंदर इसकी जांच करेगी।'
                : 'This reel has been hidden from your feed. Our review team will inspect it.'}
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            <p className="text-xs font-semibold text-neutral-300">
              {lang === 'hi' ? 'रिपोर्ट करने का कारण चुनें:' : 'Select a reason for reporting:'}
            </p>

            <form onSubmit={handleSubmitReport} className="space-y-2.5">
              {reasons.map((r) => (
                <label
                  key={r.id}
                  onClick={() => setSelectedReason(r.id)}
                  className={`flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedReason === r.id
                      ? 'bg-pink-950/30 border-pink-500 text-white'
                      : 'bg-neutral-950/70 border-neutral-800 hover:border-neutral-700 text-neutral-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="reportReason"
                    checked={selectedReason === r.id}
                    onChange={() => setSelectedReason(r.id)}
                    className="mt-1 text-pink-500 focus:ring-pink-500"
                  />
                  <div>
                    <p className="text-xs font-bold">
                      {lang === 'hi' ? r.titleHi : r.titleEn}
                    </p>
                    <p className="text-[10px] text-neutral-400 mt-0.5">
                      {lang === 'hi' ? r.descHi : r.descEn}
                    </p>
                  </div>
                </label>
              ))}

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-colors"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'रील रिपोर्ट करें' : 'Submit Report'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleBlock}
                  className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-rose-400 border border-neutral-700 text-xs font-bold flex items-center gap-1 transition-colors"
                  title="Block this creator"
                >
                  <UserX className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'ब्लॉक' : 'Block'}</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
