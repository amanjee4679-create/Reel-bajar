import React, { useState } from 'react';
import { X, ShieldCheck, Heart, ShoppingBag, MessageSquare, Play, MapPin, UserPlus, UserCheck } from 'lucide-react';
import { ReelItem, ProductItem } from '../types';

interface CreatorProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  creator: ReelItem['creator'] | null;
  reels: ReelItem[];
  isFollowing: boolean;
  onToggleFollow: (creatorName: string) => void;
  onSelectReel: (reel: ReelItem) => void;
  onOpenChat: (reel?: ReelItem) => void;
  onOpenBuyModal: (product: ProductItem) => void;
  onAddToCart: (product: ProductItem) => void;
  lang: 'hi' | 'en';
}

export const CreatorProfileModal: React.FC<CreatorProfileModalProps> = ({
  isOpen,
  onClose,
  creator,
  reels,
  isFollowing,
  onToggleFollow,
  onSelectReel,
  onOpenChat,
  onOpenBuyModal,
  onAddToCart,
  lang
}) => {
  const [activeTab, setActiveTab] = useState<'reels' | 'shop'>('reels');

  if (!isOpen || !creator) return null;

  // Find all reels created by this creator
  const creatorReels = reels.filter(r => r.creator.name === creator.name);
  const creatorProducts = creatorReels.map(r => r.product);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Top Header Banner */}
        <div className="relative h-28 bg-gradient-to-r from-pink-900/60 via-purple-900/50 to-indigo-950 p-4 flex items-start justify-end border-b border-neutral-800">
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-black/50 text-neutral-300 hover:text-white backdrop-blur-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Info Bar */}
        <div className="px-6 pb-4 pt-0 relative border-b border-neutral-800/80">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-12">
            <div className="flex items-end gap-3.5">
              <div className="relative">
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-neutral-900 shadow-xl"
                />
                {creator.isVerified && (
                  <span className="absolute bottom-0 right-0 p-1 bg-blue-500 text-white rounded-full border-2 border-neutral-900">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </span>
                )}
              </div>
              <div className="mb-1">
                <h3 className="font-extrabold text-base text-white flex items-center gap-1.5">
                  {creator.name}
                </h3>
                <p className="text-xs text-neutral-400">{creator.handle}</p>
              </div>
            </div>

            {/* Actions: Follow / Chat */}
            <div className="flex items-center gap-2 mb-1">
              <button
                onClick={() => onToggleFollow(creator.name)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                  isFollowing
                    ? 'bg-neutral-800 border border-neutral-700 text-neutral-200 hover:bg-neutral-700'
                    : 'bg-gradient-to-r from-pink-600 to-purple-600 text-white hover:opacity-95'
                }`}
              >
                {isFollowing ? (
                  <>
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{lang === 'hi' ? 'फॉलोइंग (Following)' : 'Following'}</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'फॉलो करें' : 'Follow'}</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenChat(creatorReels[0]);
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-bold transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-pink-400" />
                <span>{lang === 'hi' ? 'चैट करें' : 'Message'}</span>
              </button>
            </div>
          </div>

          {/* Bio & Stats */}
          <div className="mt-3 space-y-2">
            <p className="text-xs text-neutral-300 leading-relaxed max-w-xl">
              {creator.bio || (lang === 'hi' ? 'वेरिफाइड निर्माता व क्रिएटर · 100% असली व गुणवत्ता प्रमाणित सामान' : 'Verified maker & creator · 100% genuine quality products')}
            </p>

            <div className="flex items-center gap-5 text-xs pt-1">
              <div>
                <span className="font-extrabold text-white">
                  {isFollowing ? `${parseInt(creator.followers) || 120}K+` : creator.followers}
                </span>
                <span className="text-neutral-400 ml-1">{lang === 'hi' ? 'फॉलोअर्स' : 'Followers'}</span>
              </div>
              <div className="w-px h-3 bg-neutral-800" />
              <div>
                <span className="font-extrabold text-white">{creatorReels.length}</span>
                <span className="text-neutral-400 ml-1">{lang === 'hi' ? 'रील्स' : 'Reels'}</span>
              </div>
              <div className="w-px h-3 bg-neutral-800" />
              <div className="flex items-center gap-1 text-neutral-400">
                <MapPin className="w-3 h-3 text-pink-500" />
                <span>{creatorReels[0]?.product.sellerCity || 'India'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center border-b border-neutral-800 bg-neutral-950 px-6">
          <button
            onClick={() => setActiveTab('reels')}
            className={`py-2.5 px-4 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-colors ${
              activeTab === 'reels'
                ? 'text-pink-500 border-pink-500'
                : 'text-neutral-400 border-transparent hover:text-white'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'रील्स' : 'Reels'} ({creatorReels.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('shop')}
            className={`py-2.5 px-4 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-colors ${
              activeTab === 'shop'
                ? 'text-pink-500 border-pink-500'
                : 'text-neutral-400 border-transparent hover:text-white'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'दुकान / सामान' : 'Store Catalog'} ({creatorProducts.length})</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 no-scrollbar">
          {activeTab === 'reels' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {creatorReels.map((reel) => (
                <div
                  key={reel.id}
                  onClick={() => {
                    onClose();
                    onSelectReel(reel);
                  }}
                  className="relative aspect-[9/14] rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-800 cursor-pointer group shadow-md"
                >
                  <img
                    src={reel.posterUrl}
                    alt={reel.caption}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />
                  <div className="absolute top-2 right-2 bg-black/60 px-2 py-0.5 rounded-lg text-[10px] text-white flex items-center gap-1">
                    <Heart className="w-3 h-3 fill-pink-500 text-pink-500" />
                    <span>{reel.likesCount}</span>
                  </div>
                  <div className="absolute bottom-2 left-2 right-2">
                    <p className="text-xs font-bold text-white truncate">{reel.product.title}</p>
                    <p className="text-[11px] font-extrabold text-pink-400">₹{reel.product.price}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {creatorProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={prod.image}
                      alt={prod.title}
                      className="w-16 h-16 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">{prod.title}</p>
                      <div className="flex items-baseline gap-2 mt-0.5">
                        <span className="text-sm font-black text-pink-400">₹{prod.price}</span>
                        <span className="text-[10px] text-neutral-500 line-through">₹{prod.originalPrice}</span>
                        <span className="text-[9px] text-emerald-400 font-bold bg-emerald-950/60 px-1 rounded">
                          {prod.discountPercent}% OFF
                        </span>
                      </div>
                      <p className="text-[10px] text-neutral-400 mt-1">
                        ⭐ {prod.rating} ({prod.reviewsCount} reviews) · {prod.sellerCity}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => onAddToCart(prod)}
                      className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold border border-neutral-700 transition-colors"
                    >
                      {lang === 'hi' ? '+ कार्ट' : '+ Cart'}
                    </button>
                    <button
                      onClick={() => {
                        onClose();
                        onOpenBuyModal(prod);
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold shadow-md transition-colors"
                    >
                      {lang === 'hi' ? 'खरीदें' : 'Buy'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
