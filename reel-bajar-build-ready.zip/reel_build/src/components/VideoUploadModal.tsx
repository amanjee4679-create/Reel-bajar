import React, { useState } from 'react';
import { X, Upload, Sparkles, Music, Tag, Check, Film, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { ReelItem, UserProfile } from '../types';

interface VideoUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPublishReel: (newReel: ReelItem) => void;
  currentUser: UserProfile | null;
  onRequireAuth: () => void;
  lang: 'hi' | 'en';
}

const SAMPLE_CLIPS = [
  {
    title: 'Ethnic Saree Walk',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-woman-posing-with-a-red-traditional-dress-41131-large.mp4',
    poster: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=400&q=80',
    defaultProduct: 'Handcrafted Festive Silk Saree',
    defaultPrice: 1699
  },
  {
    title: 'Smart Earbuds Sound',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-listening-to-music-with-wireless-earbuds-42962-large.mp4',
    poster: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=400&q=80',
    defaultProduct: 'BassBoost Pro Wireless TWS',
    defaultPrice: 899
  },
  {
    title: 'Juicer Blender Demo',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-woman-making-a-smoothie-with-fresh-fruits-41584-large.mp4',
    poster: 'https://images.unsplash.com/photo-1570831739435-6601aa3fa4fb?auto=format&fit=crop&w=400&q=80',
    defaultProduct: 'Mini Portable USB Blender',
    defaultPrice: 549
  },
  {
    title: 'Glowing Skin Routine',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-young-woman-applying-facial-serum-with-a-pipette-42861-large.mp4',
    poster: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=400&q=80',
    defaultProduct: 'Ayurvedic Kumkumadi Serum',
    defaultPrice: 429
  }
];

export const VideoUploadModal: React.FC<VideoUploadModalProps> = ({
  isOpen,
  onClose,
  onPublishReel,
  currentUser,
  onRequireAuth,
  lang
}) => {
  const [videoUrl, setVideoUrl] = useState<string>(SAMPLE_CLIPS[0].url);
  const [posterUrl, setPosterUrl] = useState<string>(SAMPLE_CLIPS[0].poster);
  const [caption, setCaption] = useState<string>('सिर्फ ₹1,699 में सीधा कारीगरों से! असली सिल्क और फ्री होम डिलीवरी। कमेंट में लिखें अगर बुक करना है! 🥻✨');
  const [tags, setTags] = useState<string>('#ReelBajar #DesiShopping #HandloomIndia');
  const [musicTrack, setMusicTrack] = useState<string>('Trending Festive Dhol Beats · High Vibe');
  
  // Tagged Product State
  const [productTitle, setProductTitle] = useState<string>('Pure Handloom Festive Silk Saree');
  const [productPrice, setProductPrice] = useState<number>(1699);
  const [originalPrice, setOriginalPrice] = useState<number>(3999);
  const [productCategory, setProductCategory] = useState<string>('Fashion');
  const [sellerCity, setSellerCity] = useState<string>('Varanasi, UP');

  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setVideoUrl(url);
      setPosterUrl('https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80');
    }
  };

  const handleSelectSample = (sample: typeof SAMPLE_CLIPS[0]) => {
    setVideoUrl(sample.url);
    setPosterUrl(sample.poster);
    setProductTitle(sample.defaultProduct);
    setProductPrice(sample.defaultPrice);
  };

  const handleGenerateAiCaption = () => {
    setIsGeneratingAi(true);
    setTimeout(() => {
      const aiCaptions = [
        `🔥 ${productTitle} पर महा लूट ऑफर! ₹${originalPrice} की जगह सिर्फ ₹${productPrice} में! पूरे भारत में Cash on Delivery उपलब्ध। ऑर्डर करने के लिए अभी 'Buy Now' दबाएं! 🛍️⚡`,
        `क्या आपने कभी देखा है ऐसा प्रीमियम ${productTitle}? Direct manufacturer price ₹${productPrice}! सीमित स्टॉक बचा है, जल्दी बुक करें! 📦✨`,
        `100% ओरिजिनल गारंटी और 7 दिन की आसान वापसी! ${productTitle} सिर्फ ₹${productPrice} में। अपने दोस्तों को भी टैग करें! 😍🇮🇳`
      ];
      const randomCaption = aiCaptions[Math.floor(Math.random() * aiCaptions.length)];
      setCaption(randomCaption);
      setTags('#ReelBajar #LootDeal #OnlineShoppingIndia #TrendingNow');
      setIsGeneratingAi(false);
    }, 600);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onRequireAuth();
      return;
    }

    const discount = Math.round(((originalPrice - productPrice) / originalPrice) * 100);

    const newReel: ReelItem = {
      id: 'reel_' + Date.now(),
      videoUrl: videoUrl,
      posterUrl: posterUrl,
      creator: {
        name: currentUser.name,
        handle: currentUser.handle,
        avatar: currentUser.avatar,
        isVerified: true,
        followers: '1.2K'
      },
      caption: caption,
      tags: tags.split(' ').filter(t => t.startsWith('#')),
      musicTrack: musicTrack,
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      isLiked: true,
      isSaved: false,
      product: {
        id: 'prod_' + Date.now(),
        title: productTitle,
        price: Number(productPrice),
        originalPrice: Number(originalPrice),
        discountPercent: discount > 0 ? discount : 40,
        rating: 4.9,
        reviewsCount: 1,
        image: posterUrl,
        sellerName: currentUser.name,
        sellerCity: sellerCity,
        isVerifiedSeller: true,
        category: productCategory,
        description: `${productTitle} - verified quality on Reel Bajar platform.`,
        inStock: true,
        commissionRate: 15,
        features: ['100% Genuine Quality Check', 'Cash On Delivery Available', 'Fast 3-Day Shipping across India']
      },
      comments: []
    };

    onPublishReel(newReel);

    // Confetti burst
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // safe fallback
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl h-[90vh] max-h-[780px] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-pink-500/10 text-pink-500 border border-pink-500/20">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {lang === 'hi' ? 'नई रील बनाएं और प्रोडक्ट टैग करें' : 'Create Reel & Tag Product'}
              </h2>
              <p className="text-xs text-neutral-400">
                {lang === 'hi' ? 'शॉर्ट वीडियो अपलोड करें, प्रोडक्ट लिंक करें और सीधे सेल करें' : 'Upload video, link product & start earning'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-6 no-scrollbar">
          {/* Left Column: Video Preview & Source */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-2">
                {lang === 'hi' ? '1. वीडियो चुने या अपलोड करें' : '1. Select or Upload Video'}
              </label>

              {/* Video Player Preview Box */}
              <div className="relative aspect-[9/14] w-full max-w-[280px] mx-auto rounded-2xl overflow-hidden bg-black border border-neutral-800 shadow-xl group">
                <video
                  src={videoUrl}
                  poster={posterUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="w-full h-full object-cover"
                />
                
                {/* Floating Preview Badge */}
                <div className="absolute top-3 left-3 bg-neutral-900/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 text-[10px] text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-pink-500 animate-pulse" />
                  <span>{lang === 'hi' ? 'लाइव प्रीव्यू' : 'Live Preview'}</span>
                </div>

                {/* Floating Product Tag Preview */}
                <div className="absolute bottom-3 left-3 right-3 bg-neutral-900/90 backdrop-blur-md p-2 rounded-xl border border-white/15 flex items-center gap-2">
                  <img
                    src={posterUrl}
                    alt="product"
                    className="w-8 h-8 rounded-lg object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-bold text-white truncate">{productTitle || 'Product Title'}</p>
                    <p className="text-pink-400 font-extrabold text-[11px]">₹{productPrice} <span className="line-through text-[9px] text-neutral-500">₹{originalPrice}</span></p>
                  </div>
                  <span className="bg-pink-600 text-white text-[9px] font-bold px-2 py-1 rounded-lg">
                    Buy
                  </span>
                </div>
              </div>
            </div>

            {/* Upload File Button */}
            <div className="flex items-center gap-2">
              <label className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-xs font-semibold text-neutral-200 cursor-pointer transition-colors">
                <Upload className="w-4 h-4 text-pink-400" />
                <span>{lang === 'hi' ? 'डिवाइस से वीडियो चुनें (.mp4)' : 'Upload from Device'}</span>
                <input
                  type="file"
                  accept="video/mp4,video/webm"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Quick Demo Clips Picker */}
            <div>
              <p className="text-[11px] font-medium text-neutral-400 mb-2">
                {lang === 'hi' ? 'या डेमो क्लिप चुनें:' : 'Or choose a trending demo clip:'}
              </p>
              <div className="grid grid-cols-2 gap-2">
                {SAMPLE_CLIPS.map((clip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectSample(clip)}
                    className={`p-2 rounded-xl border text-left text-xs transition-all flex items-center gap-2 ${
                      videoUrl === clip.url
                        ? 'bg-pink-950/40 border-pink-500 text-pink-300'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <img src={clip.poster} alt={clip.title} className="w-8 h-8 rounded-lg object-cover" />
                    <span className="font-semibold text-[11px] truncate">{clip.title}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Details & Tagging */}
          <div className="space-y-4">
            {/* Caption & AI Generator */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-neutral-300">
                  {lang === 'hi' ? '2. रील कैप्शन और विवरण' : '2. Reel Caption'}
                </label>
                <button
                  type="button"
                  onClick={handleGenerateAiCaption}
                  disabled={isGeneratingAi}
                  className="flex items-center gap-1 text-[11px] font-semibold text-pink-400 hover:text-pink-300 bg-pink-500/10 px-2.5 py-1 rounded-lg border border-pink-500/20"
                >
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                  <span>{isGeneratingAi ? 'जनरेट हो रहा है...' : (lang === 'hi' ? 'AI कैप्शन बनाएं' : 'AI Caption')}</span>
                </button>
              </div>
              <textarea
                required
                rows={3}
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder={lang === 'hi' ? 'रील के बारे में बताएं...' : 'Describe your reel and product...'}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500 transition-colors resize-none"
              />
            </div>

            {/* Hashtags */}
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                {lang === 'hi' ? 'हैशटैग्स (Hashtags)' : 'Hashtags'}
              </label>
              <input
                type="text"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-pink-400 font-medium focus:outline-none focus:border-pink-500"
              />
            </div>

            {/* Music Track */}
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                <Music className="w-3.5 h-3.5 inline mr-1 text-pink-400" />
                {lang === 'hi' ? 'ऑडियो / संगीत' : 'Audio Track'}
              </label>
              <input
                type="text"
                value={musicTrack}
                onChange={(e) => setMusicTrack(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
              />
            </div>

            {/* Product Tagging Details */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800/90 space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                <Tag className="w-4 h-4" />
                <span>{lang === 'hi' ? '3. प्रोडक्ट टैगिंग (रील्स में बिकने वाला सामान)' : '3. Tag Product in Reel'}</span>
              </div>

              <div>
                <label className="block text-[11px] text-neutral-400 mb-1">
                  {lang === 'hi' ? 'प्रोडक्ट का नाम' : 'Product Name'}
                </label>
                <input
                  type="text"
                  required
                  value={productTitle}
                  onChange={(e) => setProductTitle(e.target.value)}
                  placeholder="e.g. Pure Silk Handloom Saree"
                  className="w-full bg-neutral-900 border border-neutral-700/80 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'बिक्री मूल्य (Selling ₹)' : 'Selling Price (₹)'}
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={productPrice}
                    onChange={(e) => setProductPrice(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-neutral-700/80 rounded-lg px-3 py-2 text-xs font-bold text-pink-400 focus:outline-none focus:border-pink-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'असली मूल्य (MRP ₹)' : 'MRP (₹)'}
                  </label>
                  <input
                    type="number"
                    required
                    min={productPrice}
                    value={originalPrice}
                    onChange={(e) => setOriginalPrice(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-neutral-700/80 rounded-lg px-3 py-2 text-xs text-neutral-400 focus:outline-none focus:border-pink-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'श्रेणी (Category)' : 'Category'}
                  </label>
                  <select
                    value={productCategory}
                    onChange={(e) => setProductCategory(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700/80 rounded-lg px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-pink-500"
                  >
                    <option value="Fashion">फैशन (Fashion)</option>
                    <option value="Electronics">इलेक्ट्रॉनिक्स (Electronics)</option>
                    <option value="Home & Kitchen">होम & किचन (Home)</option>
                    <option value="Beauty">ब्यूटी (Beauty)</option>
                    <option value="Accessories">एक्सेसरीज (Accessories)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'विक्रेता शहर (City)' : 'Seller City'}
                  </label>
                  <input
                    type="text"
                    value={sellerCity}
                    onChange={(e) => setSellerCity(e.target.value)}
                    placeholder="e.g. Varanasi, UP"
                    className="w-full bg-neutral-900 border border-neutral-700/80 rounded-lg px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-pink-500"
                  />
                </div>
              </div>
            </div>

            {/* Auth Notice */}
            {!currentUser && (
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/40 flex items-center gap-2 text-xs text-amber-300">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>
                  {lang === 'hi' ? 'पब्लिश करने के लिए कृपया पहले लॉगिन करें' : 'Please log in to publish your reel'}
                </span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 text-white font-bold text-sm shadow-lg shadow-pink-600/25 hover:opacity-95 transition-all flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5" />
              <span>{lang === 'hi' ? 'रील पब्लिश करें (Publish Reel)' : 'Publish Reel Now'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
