import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark, 
  Volume2, 
  VolumeX, 
  ShoppingBag, 
  ChevronUp, 
  ChevronDown, 
  Play, 
  Check, 
  Music,
  Send,
  MoreVertical,
  Info
} from 'lucide-react';
import { ReelItem, ProductItem } from '../types';

interface ReelPlayerProps {
  reels: ReelItem[];
  currentReelIndex: number;
  setCurrentReelIndex: (index: number) => void;
  onLikeReel: (reelId: string) => void;
  onSaveReel: (reelId: string) => void;
  onOpenComments: (reel: ReelItem) => void;
  onOpenChat: (reel: ReelItem) => void;
  onOpenBuyModal: (product: ProductItem) => void;
  onOpenProductDetail: (product: ProductItem) => void;
  onOpenCreatorProfile: (creator: ReelItem['creator']) => void;
  onOpenReportModal: (reel: ReelItem) => void;
  followingCreatorNames: string[];
  onToggleFollow: (creatorName: string) => void;
  lang: 'hi' | 'en';
}

export const ReelPlayer: React.FC<ReelPlayerProps> = ({
  reels,
  currentReelIndex,
  setCurrentReelIndex,
  onLikeReel,
  onSaveReel,
  onOpenComments,
  onOpenChat,
  onOpenBuyModal,
  onOpenProductDetail,
  onOpenCreatorProfile,
  onOpenReportModal,
  followingCreatorNames,
  onToggleFollow,
  lang
}) => {
  const currentReel = reels[currentReelIndex] || reels[0];
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [showHeartBurst, setShowHeartBurst] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<boolean>(false);

  // Touch swipe tracking
  const touchStartY = useRef<number>(0);
  const touchEndY = useRef<number>(0);

  const handleNext = useCallback(() => {
    if (reels.length === 0) return;
    setCurrentReelIndex((currentReelIndex + 1) % reels.length);
  }, [currentReelIndex, reels.length, setCurrentReelIndex]);

  const handlePrev = useCallback(() => {
    if (reels.length === 0) return;
    setCurrentReelIndex((currentReelIndex - 1 + reels.length) % reels.length);
  }, [currentReelIndex, reels.length, setCurrentReelIndex]);

  // Keyboard navigation (ArrowUp, ArrowDown)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.key === 'j') {
        handleNext();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        handlePrev();
      } else if (e.key === 'm') {
        setIsMuted(prev => !prev);
      } else if (e.key === ' ') {
        e.preventDefault();
        togglePlayPause();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNext, handlePrev]);

  // Touch swipe events
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.targetTouches[0].clientY;
  };

  const onTouchMove = (e: React.TouchEvent) => {
    touchEndY.current = e.targetTouches[0].clientY;
  };

  const onTouchEnd = () => {
    const deltaY = touchStartY.current - touchEndY.current;
    if (deltaY > 50) {
      // Swiped Up -> Next Reel
      handleNext();
    } else if (deltaY < -50) {
      // Swiped Down -> Previous Reel
      handlePrev();
    }
  };

  // Play/pause management on slide change
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {
        setIsPlaying(false);
      });
      setIsPlaying(true);
    }
  }, [currentReelIndex]);

  const togglePlayPause = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const handleDoubleTap = () => {
    if (!currentReel.isLiked) {
      onLikeReel(currentReel.id);
    }
    setShowHeartBurst(true);
    setTimeout(() => {
      setShowHeartBurst(false);
    }, 800);
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      navigator.share({
        title: `Reel Bajar: ${currentReel.product.title}`,
        text: `${currentReel.caption} सिर्फ ₹${currentReel.product.price} में!`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleSaveWithToast = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSaveReel(currentReel.id);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2000);
  };

  if (!currentReel) {
    return (
      <div className="flex-1 flex items-center justify-center text-neutral-400 text-xs">
        {lang === 'hi' ? 'कोई रील उपलब्ध नहीं है।' : 'No reels available.'}
      </div>
    );
  }

  const isCreatorFollowed = followingCreatorNames.includes(currentReel.creator.name);

  return (
    <div className="relative w-full h-[calc(100vh-62px)] max-h-[920px] flex items-center justify-center py-2 px-2 sm:px-4">
      {/* Container simulating a mobile phone viewport on desktop */}
      <div 
        ref={containerRef}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        className="relative w-full max-w-[420px] h-full rounded-3xl overflow-hidden bg-black shadow-2xl border border-neutral-800 flex flex-col select-none group"
      >
        
        {/* Main Video Element */}
        <div 
          className="relative flex-1 w-full h-full cursor-pointer bg-neutral-950 overflow-hidden"
          onClick={togglePlayPause}
          onDoubleClick={handleDoubleTap}
        >
          <video
            ref={videoRef}
            src={currentReel.videoUrl}
            poster={currentReel.posterUrl}
            playsInline
            loop
            muted={isMuted}
            autoPlay
            className="w-full h-full object-cover"
          />

          {/* Vignette Gradients for readability */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/90 pointer-events-none" />

          {/* Heart Explosion Animation on Double-Tap */}
          {showHeartBurst && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <Heart className="w-28 h-28 text-pink-500 fill-pink-500 drop-shadow-2xl animate-ping" />
            </div>
          )}

          {/* Big Play Pause Indicator if paused */}
          {!isPlaying && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none bg-black/30">
              <div className="w-16 h-16 rounded-full bg-neutral-900/80 backdrop-blur-md flex items-center justify-center border border-white/20 text-white shadow-2xl">
                <Play className="w-8 h-8 fill-white ml-1" />
              </div>
            </div>
          )}

          {/* Toast Notification (Save / Link Copied) */}
          {saveToast && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 z-30 bg-neutral-900/90 text-amber-300 border border-amber-500/30 text-xs px-3.5 py-1.5 rounded-full shadow-xl flex items-center gap-1.5 animate-fadeIn">
              <Bookmark className="w-3.5 h-3.5 fill-current" />
              <span>{lang === 'hi' ? 'रील आपकी विशलिस्ट में सेव हो गई!' : 'Reel saved to your wishlist!'}</span>
            </div>
          )}

          {/* Top Bar inside Reel */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-20">
            {/* Live Reel Index Indicator */}
            <div className="flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 text-[11px] text-white font-medium">
              <span className="w-2 h-2 rounded-full bg-pink-500 animate-pulse" />
              <span>Reel {currentReelIndex + 1}/{reels.length}</span>
            </div>

            {/* Right Tools: Mute + Moderation (3 dots) */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={toggleMute}
                className="p-2 rounded-full bg-black/40 backdrop-blur-md border border-white/15 text-white hover:bg-black/60 transition-colors"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-neutral-300" /> : <Volume2 className="w-4 h-4 text-pink-400" />}
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenReportModal(currentReel);
                }}
                className="p-2 rounded-full bg-black/40 backdrop-blur-md border border-white/15 text-white hover:bg-black/60 transition-colors"
                title="Report / Moderation"
              >
                <MoreVertical className="w-4 h-4 text-neutral-300" />
              </button>
            </div>
          </div>

          {/* Right Action Rail (Like, Comment, Chat, Share, Bookmark) */}
          <div className="absolute right-3 bottom-32 sm:bottom-28 flex flex-col items-center gap-3.5 z-20">
            {/* Creator Profile Avatar with Follow Plus */}
            <div className="relative group/avatar cursor-pointer" onClick={(e) => {
              e.stopPropagation();
              onOpenCreatorProfile(currentReel.creator);
            }}>
              <img
                src={currentReel.creator.avatar}
                alt={currentReel.creator.name}
                className="w-11 h-11 rounded-full object-cover border-2 border-pink-500 shadow-lg hover:scale-105 transition-transform"
              />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleFollow(currentReel.creator.name);
                }}
                className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-black transition-transform ${
                  isCreatorFollowed
                    ? 'bg-neutral-800 text-emerald-400 border border-neutral-600'
                    : 'bg-pink-600 text-white shadow-sm hover:scale-110'
                }`}
                title={isCreatorFollowed ? 'Following' : 'Follow'}
              >
                {isCreatorFollowed ? '✓' : '+'}
              </button>
            </div>

            {/* Like Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onLikeReel(currentReel.id);
              }}
              className="flex flex-col items-center gap-0.5 group/btn"
            >
              <div className={`p-2.5 rounded-full backdrop-blur-md border transition-all ${
                currentReel.isLiked
                  ? 'bg-pink-600/40 border-pink-500 text-pink-500 scale-110'
                  : 'bg-black/40 border-white/10 text-white group-hover/btn:bg-black/60'
              }`}>
                <Heart className={`w-6 h-6 ${currentReel.isLiked ? 'fill-pink-500' : ''}`} />
              </div>
              <span className="text-[11px] font-bold text-white drop-shadow-md">
                {(currentReel.likesCount + (currentReel.isLiked ? 1 : 0)).toLocaleString()}
              </span>
            </button>

            {/* Comment Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onOpenComments(currentReel);
              }}
              className="flex flex-col items-center gap-0.5 group/btn"
            >
              <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 text-white group-hover/btn:bg-black/60 transition-colors">
                <MessageCircle className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-bold text-white drop-shadow-md">
                {currentReel.commentsCount || currentReel.comments.length}
              </span>
            </button>

            {/* Chat with Seller / Creator */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onOpenChat(currentReel);
              }}
              className="flex flex-col items-center gap-0.5 group/btn"
              title="Chat with Seller"
            >
              <div className="p-2.5 rounded-full bg-emerald-500/30 backdrop-blur-md border border-emerald-400/40 text-emerald-300 group-hover/btn:bg-emerald-500/50 transition-colors">
                <Send className="w-5 h-5 ml-0.5" />
              </div>
              <span className="text-[10px] font-semibold text-emerald-400 drop-shadow-md">
                {lang === 'hi' ? 'चैट' : 'Chat'}
              </span>
            </button>

            {/* Bookmark / Save */}
            <button
              onClick={handleSaveWithToast}
              className="flex flex-col items-center gap-0.5 group/btn"
            >
              <div className={`p-2.5 rounded-full backdrop-blur-md border transition-all ${
                currentReel.isSaved
                  ? 'bg-amber-500/40 border-amber-400 text-amber-400'
                  : 'bg-black/40 border-white/10 text-white'
              }`}>
                <Bookmark className={`w-5 h-5 ${currentReel.isSaved ? 'fill-amber-400' : ''}`} />
              </div>
              <span className="text-[10px] font-semibold text-white drop-shadow-md">
                {lang === 'hi' ? 'सेव' : 'Save'}
              </span>
            </button>

            {/* Share */}
            <button
              onClick={handleShare}
              className="flex flex-col items-center gap-0.5 group/btn"
            >
              <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 text-white group-hover/btn:bg-black/60 transition-colors">
                {copiedLink ? <Check className="w-5 h-5 text-emerald-400" /> : <Share2 className="w-5 h-5" />}
              </div>
              <span className="text-[10px] font-semibold text-white drop-shadow-md">
                {copiedLink ? 'Copied' : (lang === 'hi' ? 'शेयर' : 'Share')}
              </span>
            </button>

            {/* Spinning Music Disc */}
            <div className="relative w-9 h-9 rounded-full bg-neutral-900 border-2 border-neutral-700 p-0.5 flex items-center justify-center animate-spin [animation-duration:5s]">
              <img
                src={currentReel.posterUrl}
                alt="music"
                className="w-full h-full rounded-full object-cover"
              />
            </div>
          </div>

          {/* Bottom Left Details & Tagged Product Floating Bar */}
          <div className="absolute left-3 right-16 bottom-3 z-20 space-y-2 pointer-events-auto">
            {/* Tagged Product Highlight Card */}
            <div 
              onClick={(e) => {
                e.stopPropagation();
                onOpenProductDetail(currentReel.product);
              }}
              className="p-2.5 rounded-2xl bg-neutral-950/90 backdrop-blur-md border border-pink-500/30 shadow-xl flex items-center gap-2.5 cursor-pointer hover:border-pink-500 hover:scale-[1.02] transition-all group/prod"
            >
              <img
                src={currentReel.product.image}
                alt={currentReel.product.title}
                className="w-12 h-12 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-bold text-white truncate group-hover/prod:text-pink-300 transition-colors">
                  {currentReel.product.title}
                </p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs font-black text-pink-400">
                    ₹{currentReel.product.price}
                  </span>
                  <span className="text-[10px] text-neutral-500 line-through">
                    ₹{currentReel.product.originalPrice}
                  </span>
                  <span className="text-[9px] font-extrabold text-emerald-400 bg-emerald-950/80 px-1 rounded border border-emerald-800/40">
                    {currentReel.product.discountPercent}% OFF
                  </span>
                </div>
                <p className="text-[9px] text-neutral-400 truncate mt-0.5">
                  📍 {currentReel.product.sellerCity} · ⭐ {currentReel.product.rating}
                </p>
              </div>

              {/* Direct Buy CTA */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenBuyModal(currentReel.product);
                }}
                className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 text-white font-extrabold text-[10px] shadow-md shadow-pink-600/30 flex items-center gap-1 flex-shrink-0 hover:opacity-95"
              >
                <ShoppingBag className="w-3 h-3" />
                <span>{lang === 'hi' ? 'खरीदें' : 'Buy'}</span>
              </button>
            </div>

            {/* Creator Username & Caption */}
            <div className="space-y-1">
              <div 
                className="flex items-center gap-1.5 cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenCreatorProfile(currentReel.creator);
                }}
              >
                <span className="font-extrabold text-xs text-white hover:underline">
                  {currentReel.creator.name}
                </span>
                {currentReel.creator.isVerified && (
                  <span className="w-3.5 h-3.5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[8px] font-bold">
                    ✓
                  </span>
                )}
                <span className="text-[11px] text-neutral-400">
                  {currentReel.creator.handle}
                </span>
              </div>

              <p className="text-xs text-neutral-200 line-clamp-2 leading-relaxed font-normal">
                {currentReel.caption}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 text-[11px] font-semibold text-pink-400">
                {currentReel.tags.slice(0, 3).map((tag, idx) => (
                  <span key={idx}>{tag}</span>
                ))}
              </div>

              {/* Audio Track Ticker */}
              <div className="flex items-center gap-1.5 text-[10px] text-neutral-300 pt-0.5">
                <Music className="w-3 h-3 text-pink-400 flex-shrink-0" />
                <span className="truncate">{currentReel.musicTrack}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Up / Down Navigation Floaters for Desktop / Mouse users */}
        <div className="absolute right-[-48px] top-1/2 -translate-y-1/2 hidden md:flex flex-col gap-2">
          <button
            onClick={handlePrev}
            className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-800 hover:border-neutral-700 shadow-xl transition-all"
            title="Previous Reel (Up Arrow / k)"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-800 hover:border-neutral-700 shadow-xl transition-all"
            title="Next Reel (Down Arrow / j)"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
