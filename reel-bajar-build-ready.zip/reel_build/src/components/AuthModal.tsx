import React, { useState } from 'react';
import { X, Phone, Lock, User, CheckCircle2, ShieldCheck } from 'lucide-react';
import { UserProfile } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  lang: 'hi' | 'en';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  lang
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [isSellerAccount, setIsSellerAccount] = useState(false);

  if (!isOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || phone.length < 10) {
      alert(lang === 'hi' ? 'कृपया मान्य 10 अंकों का मोबाइल नंबर दर्ज करें' : 'Please enter a valid 10-digit phone number');
      return;
    }
    setOtpSent(true);
    setOtp('5842'); // Auto prefilled demo OTP for ease
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: UserProfile = {
      id: 'user_' + Date.now(),
      name: name || (lang === 'hi' ? 'अमन कुमार' : 'Aman Kumar'),
      handle: name ? `@${name.toLowerCase().replace(/\s+/g, '_')}` : '@aman_reels',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      bio: lang === 'hi' ? 'रील्स और शॉपिंग लवर | रील बाज़ार वेरिफाइड खरीदार' : 'Reels & shopping enthusiast | Reel Bajar verified buyer',
      followersCount: 142,
      followingCount: 38,
      isSeller: isSellerAccount,
      walletBalance: isSellerAccount ? 3500 : 250,
      phone: `+91 ${phone}`
    };
    onLoginSuccess(newUser);
    onClose();
  };

  const handleQuickDemoLogin = (role: 'buyer' | 'seller') => {
    const demoUser: UserProfile = role === 'seller' ? {
      id: 'seller_priya',
      name: 'Priya Sharma (प्रिया)',
      handle: '@priyastyle_in',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      bio: 'Fashion Designer & Handloom Creator | Direct Weaver Collection 🥻',
      followersCount: 184000,
      followingCount: 112,
      isSeller: true,
      walletBalance: 18450,
      phone: '+91 9876543210'
    } : {
      id: 'buyer_aman',
      name: 'Aman Kumar (अमन)',
      handle: '@aman_shopper',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      bio: 'Lover of Indian crafts, tech gadgets & budget fashion deals ✨',
      followersCount: 420,
      followingCount: 89,
      isSeller: false,
      walletBalance: 750,
      phone: '+91 9123456789'
    };
    onLoginSuccess(demoUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl text-neutral-100 overflow-hidden">
        {/* Glow Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-2 bg-gradient-to-r from-pink-500 via-purple-500 to-amber-400 rounded-b-full shadow-lg shadow-pink-500/30" />
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mt-2 mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-600 to-purple-600 mb-3 shadow-lg shadow-pink-500/25">
            <Lock className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-bold tracking-tight text-white">
            {mode === 'login' 
              ? (lang === 'hi' ? 'रील बाज़ार में लॉगिन करें' : 'Login to Reel Bajar') 
              : (lang === 'hi' ? 'नया खाता बनाएं' : 'Create an Account')}
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {lang === 'hi' 
              ? 'रील्स बनाएं, प्रोडक्ट्स खरीदें और कमीशन कमाएं' 
              : 'Post reels, shop tagged products & earn commission'}
          </p>
        </div>

        {/* Form */}
        {!otpSent ? (
          <form onSubmit={handleSendOtp} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  {lang === 'hi' ? 'आपका पूरा नाम' : 'Your Full Name'}
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={lang === 'hi' ? 'जैसे: अमन कुमार' : 'e.g. Aman Kumar'}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500 transition-colors"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                {lang === 'hi' ? 'मोबाइल नंबर (OTP के लिए)' : 'Mobile Number (For OTP)'}
              </label>
              <div className="relative flex">
                <span className="inline-flex items-center px-3.5 bg-neutral-950 border border-r-0 border-neutral-800 rounded-l-xl text-xs font-semibold text-neutral-400">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-r-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500 transition-colors"
                />
              </div>
            </div>

            {mode === 'signup' && (
              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-neutral-950 border border-neutral-800/80 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isSellerAccount}
                  onChange={(e) => setIsSellerAccount(e.target.checked)}
                  className="rounded border-neutral-700 text-pink-600 focus:ring-pink-500"
                />
                <div className="text-xs">
                  <span className="font-semibold text-white">
                    {lang === 'hi' ? 'मैं एक क्रिएटर / विक्रेता (Seller) भी हूँ' : 'I want to sell & earn as Creator / Seller'}
                  </span>
                  <p className="text-[10px] text-neutral-400">
                    {lang === 'hi' ? 'रील्स में अपने उत्पाद टैग करें और ऑर्डर प्राप्त करें' : 'Tag products in reels and receive buyer orders'}
                  </p>
                </div>
              </label>
            )}

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 text-white font-bold text-sm shadow-lg shadow-pink-600/20 hover:opacity-95 transition-opacity"
            >
              {lang === 'hi' ? 'OTP प्राप्त करें (Get OTP)' : 'Send OTP via SMS'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyOtp} className="space-y-4">
            <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-800/50 flex items-center gap-2 text-xs text-emerald-400">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>
                {lang === 'hi' ? `OTP +91 ${phone} पर भेजा गया` : `OTP sent to +91 ${phone}`}
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                {lang === 'hi' ? '4-अंकीय OTP दर्ज करें (Demo: 5842)' : 'Enter 4-Digit OTP (Demo: 5842)'}
              </label>
              <input
                type="text"
                required
                maxLength={4}
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full text-center tracking-widest text-2xl font-bold bg-neutral-950 border border-neutral-800 rounded-xl py-3 text-white focus:outline-none focus:border-pink-500 transition-colors"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 text-white font-bold text-sm shadow-lg shadow-pink-600/20 hover:opacity-95 transition-opacity"
            >
              {lang === 'hi' ? 'सत्यापित करें और प्रवेश करें' : 'Verify & Continue'}
            </button>

            <button
              type="button"
              onClick={() => setOtpSent(false)}
              className="w-full text-center text-xs text-neutral-400 hover:text-neutral-200"
            >
              {lang === 'hi' ? 'नंबर बदलें' : 'Change Phone Number'}
            </button>
          </form>
        )}

        {/* Quick Demo Login Buttons */}
        <div className="mt-6 pt-4 border-t border-neutral-800 text-center">
          <p className="text-[11px] font-medium text-neutral-400 mb-2">
            {lang === 'hi' ? '⚡ 1-क्लिक टेस्ट लॉगिन (बिना OTP):' : '⚡ Quick 1-Click Demo Login:'}
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleQuickDemoLogin('buyer')}
              className="py-2 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 border border-neutral-700 transition-colors"
            >
              👤 {lang === 'hi' ? 'खरीदार (Aman)' : 'Buyer (Aman)'}
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemoLogin('seller')}
              className="py-2 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-pink-300 border border-pink-500/30 transition-colors"
            >
              ✨ {lang === 'hi' ? 'क्रिएटर (Priya)' : 'Creator (Priya)'}
            </button>
          </div>
        </div>

        {/* Mode Toggle Switch */}
        <div className="mt-4 text-center">
          <button
            type="button"
            onClick={() => {
              setMode(mode === 'login' ? 'signup' : 'login');
              setOtpSent(false);
            }}
            className="text-xs text-pink-400 hover:text-pink-300 font-medium"
          >
            {mode === 'login' 
              ? (lang === 'hi' ? 'नया खाता बनाना है? यहाँ रजिस्टर करें' : "Don't have an account? Sign Up") 
              : (lang === 'hi' ? 'पहले से खाता है? यहाँ लॉगिन करें' : 'Already have an account? Login')}
          </button>
        </div>

        <div className="mt-4 flex items-center justify-center gap-1.5 text-[10px] text-neutral-500">
          <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
          <span>{lang === 'hi' ? 'सुरक्षित और एन्क्रिप्टेड · रील बाज़ार गारंटी' : '100% Secure & Encrypted'}</span>
        </div>
      </div>
    </div>
  );
};
