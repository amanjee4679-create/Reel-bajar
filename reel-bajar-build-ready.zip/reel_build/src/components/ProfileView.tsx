import React, { useState } from 'react';
import { User, Heart, Bookmark, Wallet, ArrowUpRight, LogOut, CheckCircle2, ShieldCheck, Film, ShoppingBag, Edit3, Package, Truck, Clock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserProfile, ReelItem } from '../types';

interface ProfileViewProps {
  currentUser: UserProfile | null;
  onLoginRequest: () => void;
  onLogout: () => void;
  onUpdateProfile: (updated: UserProfile) => void;
  myReels: ReelItem[];
  likedReels: ReelItem[];
  savedReels: ReelItem[];
  onSelectReel: (reel: ReelItem) => void;
  lang: 'hi' | 'en';
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentUser,
  onLoginRequest,
  onLogout,
  onUpdateProfile,
  myReels,
  likedReels,
  savedReels,
  onSelectReel,
  lang
}) => {
  const [activeTab, setActiveTab] = useState<'my' | 'liked' | 'saved' | 'orders' | 'earnings'>('my');
  const [withdrawSuccess, setWithdrawSuccess] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  // Edit Profile Form State
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editBio, setEditBio] = useState(currentUser?.bio || '');
  const [editPhone, setEditPhone] = useState(currentUser?.phone || '');

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto py-16 px-4 text-center">
        <div className="w-20 h-20 mx-auto rounded-3xl bg-neutral-900 border border-neutral-800 flex items-center justify-center mb-4 shadow-xl">
          <User className="w-10 h-10 text-neutral-500" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">
          {lang === 'hi' ? 'अपनी प्रोफाइल देखने के लिए लॉगिन करें' : 'Log in to view your Profile'}
        </h2>
        <p className="text-xs text-neutral-400 mb-6 max-w-sm mx-auto">
          {lang === 'hi'
            ? 'अपनी बनाई गई रील्स देखें, पसंदीदा प्रोडक्ट्स ट्रैक करें और अपनी क्रिएटर कमाई मैनेज करें।'
            : 'Track your uploaded reels, liked videos, orders, and creator commissions.'}
        </p>
        <button
          onClick={onLoginRequest}
          className="px-6 py-3 rounded-2xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 text-white font-bold text-sm shadow-lg shadow-pink-600/30 hover:opacity-95 transition-all"
        >
          {lang === 'hi' ? 'लॉगिन / साइन अप करें' : 'Login / Sign Up'}
        </button>
      </div>
    );
  }

  const handleWithdraw = () => {
    setWithdrawSuccess(true);
    try {
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
    } catch {
      // safe fallback
    }
    setTimeout(() => {
      setWithdrawSuccess(false);
    }, 4000);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...currentUser,
      name: editName,
      bio: editBio,
      phone: editPhone
    });
    setIsEditing(false);
  };

  const sampleOrders = [
    {
      id: 'RB-839211',
      date: '28 Sep 2026',
      title: 'Varanasi Pure Soft Silk Handloom Saree',
      price: 1899,
      statusHi: 'रास्ते में है (In Transit)',
      statusEn: 'In Transit',
      color: 'text-amber-400',
      icon: Truck,
      image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80'
    },
    {
      id: 'RB-619283',
      date: '22 Sep 2026',
      title: 'AuraPods Pro ANC Wireless Earbuds',
      price: 999,
      statusHi: 'सफलतापूर्वक डिलीवर हुआ',
      statusEn: 'Delivered',
      color: 'text-emerald-400',
      icon: CheckCircle2,
      image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=200&q=80'
    }
  ];

  return (
    <div className="max-w-3xl mx-auto py-6 px-4 space-y-6">
      {/* Profile Card */}
      <div className="relative rounded-3xl bg-neutral-900/90 border border-neutral-800 p-6 shadow-xl overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-pink-600/10 blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 relative z-10">
          {/* Avatar */}
          <div className="relative">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-24 h-24 rounded-full object-cover border-3 border-pink-500 shadow-xl"
            />
            {currentUser.isSeller && (
              <span className="absolute bottom-0 right-0 p-1 bg-amber-400 text-neutral-950 rounded-full border-2 border-neutral-900" title="Verified Creator Seller">
                <ShieldCheck className="w-4 h-4 fill-current" />
              </span>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-xl font-bold text-white flex items-center justify-center sm:justify-start gap-2">
                  {currentUser.name}
                  {currentUser.isSeller && (
                    <span className="text-[11px] bg-pink-500/20 text-pink-400 px-2 py-0.5 rounded-full font-semibold border border-pink-500/30">
                      {lang === 'hi' ? 'वेरिफाइड क्रिएटर' : 'Verified Creator'}
                    </span>
                  )}
                </h1>
                <p className="text-xs text-neutral-400 mt-0.5">{currentUser.handle}</p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-center gap-2">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold border border-neutral-700 transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5 text-pink-400" />
                  <span>{lang === 'hi' ? 'एडिट' : 'Edit'}</span>
                </button>
                <button
                  onClick={onLogout}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-semibold border border-neutral-700 transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'लॉगआउट' : 'Logout'}</span>
                </button>
              </div>
            </div>

            {isEditing ? (
              <form onSubmit={handleSaveProfile} className="mt-3 p-3 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2 text-xs">
                <div>
                  <label className="text-[10px] text-neutral-400">Name:</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-lg p-1.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-neutral-400">Bio:</label>
                  <textarea
                    rows={2}
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-lg p-1.5 text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="px-3 py-1 bg-pink-600 rounded-lg text-white font-bold"
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-3 py-1 bg-neutral-800 rounded-lg text-neutral-300"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              <p className="text-xs text-neutral-300 mt-3 leading-relaxed max-w-xl">
                {currentUser.bio}
              </p>
            )}

            {/* Counts */}
            <div className="flex items-center justify-center sm:justify-start gap-6 mt-4 pt-4 border-t border-neutral-800/80 text-xs">
              <div>
                <span className="font-extrabold text-white text-sm">{currentUser.followersCount.toLocaleString()}</span>
                <span className="text-neutral-400 ml-1.5">{lang === 'hi' ? 'फॉलोअर्स' : 'Followers'}</span>
              </div>
              <div className="w-px h-4 bg-neutral-800" />
              <div>
                <span className="font-extrabold text-white text-sm">{currentUser.followingCount}</span>
                <span className="text-neutral-400 ml-1.5">{lang === 'hi' ? 'फॉलोइंग' : 'Following'}</span>
              </div>
              <div className="w-px h-4 bg-neutral-800" />
              <div>
                <span className="font-extrabold text-white text-sm">{myReels.length}</span>
                <span className="text-neutral-400 ml-1.5">{lang === 'hi' ? 'रील्स' : 'Reels'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Creator Wallet Bar */}
        <div className="mt-5 p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] text-neutral-400">
                {lang === 'hi' ? 'रील बाज़ार वॉलेट & क्रिएटर कमीशन' : 'Reel Bajar Wallet & Earnings'}
              </p>
              <p className="text-lg font-black text-emerald-400">
                ₹{currentUser.walletBalance.toLocaleString('en-IN')}
                <span className="text-xs font-normal text-neutral-400 ml-2">
                  ({lang === 'hi' ? 'निकासी योग्य' : 'Available'})
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleWithdraw}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors"
            >
              <span>{lang === 'hi' ? 'UPI में ट्रांसफर करें' : 'Withdraw to UPI'}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {withdrawSuccess && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-950/60 border border-emerald-600/60 flex items-center gap-2 text-xs text-emerald-300 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>
              {lang === 'hi' 
                ? 'निकासी अनुरोध स्वीकार हुआ! 24 घंटे के अंदर आपके बैंक UPI में राशि जमा कर दी जाएगी।'
                : 'Withdrawal initiated successfully! Transferred to linked UPI ID.'}
            </span>
          </div>
        )}
      </div>

      {/* Segmented Tabs */}
      <div className="flex items-center justify-around border-b border-neutral-800 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('my')}
          className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
            activeTab === 'my'
              ? 'text-pink-500 border-pink-500'
              : 'text-neutral-400 border-transparent hover:text-white'
          }`}
        >
          <Film className="w-4 h-4" />
          <span>{lang === 'hi' ? 'मेरी रील्स' : 'My Reels'} ({myReels.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
            activeTab === 'orders'
              ? 'text-pink-500 border-pink-500'
              : 'text-neutral-400 border-transparent hover:text-white'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>{lang === 'hi' ? 'मेरे ऑर्डर्स' : 'My Orders'} ({sampleOrders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('liked')}
          className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
            activeTab === 'liked'
              ? 'text-pink-500 border-pink-500'
              : 'text-neutral-400 border-transparent hover:text-white'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>{lang === 'hi' ? 'पसंद' : 'Liked'} ({likedReels.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('saved')}
          className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
            activeTab === 'saved'
              ? 'text-pink-500 border-pink-500'
              : 'text-neutral-400 border-transparent hover:text-white'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>{lang === 'hi' ? 'सेव' : 'Saved'} ({savedReels.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('earnings')}
          className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
            activeTab === 'earnings'
              ? 'text-pink-500 border-pink-500'
              : 'text-neutral-400 border-transparent hover:text-white'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>{lang === 'hi' ? 'कमाई डैशबोर्ड' : 'Earnings'}</span>
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'my' && (
        <div>
          {myReels.length === 0 ? (
            <div className="text-center py-16 bg-neutral-900/40 rounded-3xl border border-neutral-800/80">
              <Film className="w-10 h-10 text-neutral-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-neutral-300">
                {lang === 'hi' ? 'आपने अभी तक कोई रील अपलोड नहीं की है' : "You haven't uploaded any reels yet"}
              </p>
              <p className="text-xs text-neutral-500 mt-1">
                {lang === 'hi' ? 'वीडियो अपलोड करें और अपने प्रोडक्ट्स बेचें!' : 'Upload a video to showcase products!'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {myReels.map((reel) => (
                <div
                  key={reel.id}
                  onClick={() => onSelectReel(reel)}
                  className="relative aspect-[9/14] rounded-2xl overflow-hidden bg-neutral-900 border border-neutral-800 cursor-pointer group shadow-md"
                >
                  <img
                    src={reel.posterUrl}
                    alt={reel.caption}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
                  <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded-lg text-[10px] text-white flex items-center gap-1">
                    <Heart className="w-3 h-3 fill-pink-500 text-pink-500" />
                    <span>{reel.likesCount}</span>
                  </div>
                  <div className="absolute bottom-2 left-2 right-2 text-white">
                    <p className="text-xs font-bold truncate">{reel.product.title}</p>
                    <p className="text-[11px] text-pink-400 font-extrabold">₹{reel.product.price}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Placed Orders Tab */}
      {activeTab === 'orders' && (
        <div className="space-y-3">
          {sampleOrders.map((ord) => {
            const Icon = ord.icon;
            return (
              <div
                key={ord.id}
                className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={ord.image}
                    alt={ord.title}
                    className="w-14 h-14 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-neutral-400">{ord.id}</span>
                      <span className="text-neutral-600">·</span>
                      <span className="text-[10px] text-neutral-400">{ord.date}</span>
                    </div>
                    <p className="text-xs font-bold text-white truncate mt-0.5">{ord.title}</p>
                    <p className="text-xs font-extrabold text-pink-400 mt-1">₹{ord.price} (Cash on Delivery)</p>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1 flex-shrink-0">
                  <div className={`flex items-center gap-1 text-[11px] font-bold ${ord.color}`}>
                    <Icon className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? ord.statusHi : ord.statusEn}</span>
                  </div>
                  <span className="text-[10px] text-neutral-500">Free Express Delivery</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {activeTab === 'liked' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {likedReels.map((reel) => (
            <div
              key={reel.id}
              onClick={() => onSelectReel(reel)}
              className="relative aspect-[9/14] rounded-2xl overflow-hidden bg-neutral-900 border border-neutral-800 cursor-pointer group"
            >
              <img
                src={reel.posterUrl}
                alt={reel.caption}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-2 left-2 right-2 text-white">
                <p className="text-xs font-semibold truncate">{reel.creator.name}</p>
                <p className="text-[10px] text-neutral-300 truncate">{reel.product.title}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'saved' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {savedReels.map((reel) => (
            <div
              key={reel.id}
              className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center gap-3 cursor-pointer hover:border-pink-500/50 transition-colors"
              onClick={() => onSelectReel(reel)}
            >
              <img
                src={reel.product.image}
                alt={reel.product.title}
                className="w-16 h-16 rounded-xl object-cover"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-white truncate">{reel.product.title}</p>
                <p className="text-xs text-pink-400 font-bold mt-0.5">₹{reel.product.price} <span className="line-through text-neutral-500 text-[10px]">₹{reel.product.originalPrice}</span></p>
                <p className="text-[10px] text-neutral-400 mt-1">{reel.product.sellerCity}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'earnings' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
              <p className="text-xs text-neutral-400">{lang === 'hi' ? 'कुल वीडियो व्यूज' : 'Total Reel Views'}</p>
              <p className="text-xl font-black text-white mt-1">248.5K</p>
              <p className="text-[10px] text-emerald-400 mt-1">↑ +24% this week</p>
            </div>
            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
              <p className="text-xs text-neutral-400">{lang === 'hi' ? 'रील्स से उत्पन्न बिक्री' : 'Orders Generated'}</p>
              <p className="text-xl font-black text-pink-400 mt-1">142 Orders</p>
              <p className="text-[10px] text-neutral-400 mt-1">₹1,84,000 GMV</p>
            </div>
            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
              <p className="text-xs text-neutral-400">{lang === 'hi' ? 'कमीशन दर' : 'Creator Commission'}</p>
              <p className="text-xl font-black text-amber-400 mt-1">12% - 18%</p>
              <p className="text-[10px] text-neutral-400 mt-1">Direct to Bank/UPI</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
            <h4 className="text-xs font-bold text-white mb-2 flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-pink-500" />
              <span>{lang === 'hi' ? 'रील्स से सबसे ज्यादा बिकने वाले उत्पाद' : 'Top Selling Products from Your Reels'}</span>
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2 rounded-xl bg-neutral-950">
                <span className="text-neutral-200">Varanasi Pure Soft Silk Saree</span>
                <span className="font-bold text-emerald-400">+₹2,280 commission</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-xl bg-neutral-950">
                <span className="text-neutral-200">AuraPods Pro ANC Earbuds</span>
                <span className="font-bold text-emerald-400">+₹1,498 commission</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
