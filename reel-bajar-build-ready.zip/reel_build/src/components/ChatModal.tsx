import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  Check, 
  CheckCheck, 
  MessageSquare, 
  ArrowLeft, 
  Search, 
  Plus, 
  Image as ImageIcon, 
  Paperclip, 
  Smile, 
  Trash2, 
  MoreVertical, 
  ShieldAlert, 
  Ban, 
  ShoppingBag, 
  MapPin, 
  ShieldCheck, 
  ExternalLink,
  ChevronRight,
  Flame,
  UserPlus
} from 'lucide-react';
import { ChatConversation, ChatMessage, UserProfile, ProductItem } from '../types';
import { INITIAL_CONVERSATIONS, AVAILABLE_SELLERS_FOR_CHAT } from '../data/mockChatData';

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onRequireAuth: () => void;
  lang: 'hi' | 'en';
  initialProduct?: ProductItem | null;
  initialSeller?: {
    name: string;
    handle: string;
    avatar: string;
    isVerified: boolean;
    city?: string;
  } | null;
  allProducts?: ProductItem[];
  onOpenBuyModal?: (product: ProductItem) => void;
  onOpenProductDetail?: (product: ProductItem) => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onRequireAuth,
  lang,
  initialProduct,
  initialSeller,
  allProducts = [],
  onOpenBuyModal,
  onOpenProductDetail
}) => {
  const [conversations, setConversations] = useState<ChatConversation[]>(() => {
    const saved = localStorage.getItem('rb_conversations');
    return saved ? JSON.parse(saved) : INITIAL_CONVERSATIONS;
  });

  const [activeConvId, setActiveConvId] = useState<string>('conv_priya');
  const [inputText, setInputText] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [showSellerDirectory, setShowSellerDirectory] = useState<boolean>(false);
  const [showProductPicker, setShowProductPicker] = useState<boolean>(false);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [filterUnread, setFilterUnread] = useState<boolean>(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState<boolean>(false);
  const [showMenu, setShowMenu] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('rb_conversations', JSON.stringify(conversations));
  }, [conversations]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversations, activeConvId, isTyping]);

  // Handle incoming seller / product from external trigger
  useEffect(() => {
    if (initialSeller) {
      // Find or create conversation for this seller
      setConversations(prev => {
        const existing = prev.find(c => c.participantName === initialSeller.name);
        if (existing) {
          setActiveConvId(existing.id);
          // If initialProduct is passed, add initial product context message if not already there
          if (initialProduct && !existing.messages.some(m => m.productAttachment?.title === initialProduct.title)) {
            const prodMsg: ChatMessage = {
              id: 'msg_prod_' + Date.now(),
              senderId: 'user',
              senderName: currentUser?.name || 'You',
              text: `नमस्ते! मुझे इस प्रोडक्ट के बारे में जानना है: ${initialProduct.title}`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              isSender: true,
              status: 'delivered',
              productAttachment: {
                id: initialProduct.id,
                title: initialProduct.title,
                price: initialProduct.price,
                originalPrice: initialProduct.originalPrice,
                image: initialProduct.image,
                category: initialProduct.category
              }
            };
            return prev.map(c => c.id === existing.id ? { ...c, messages: [...c.messages, prodMsg] } : c);
          }
          return prev;
        } else {
          const newConv: ChatConversation = {
            id: 'conv_' + Date.now(),
            participantId: 'seller_' + Date.now(),
            participantName: initialSeller.name,
            participantAvatar: initialSeller.avatar,
            participantHandle: initialSeller.handle,
            participantCity: initialSeller.city || 'India',
            isVerified: initialSeller.isVerified,
            isOnline: true,
            lastSeen: 'Active now',
            lastMessage: initialProduct ? `Inquiring about ${initialProduct.title}` : 'Started conversation',
            lastTimestamp: 'Just now',
            unreadCount: 0,
            messages: [
              {
                id: 'init_msg_' + Date.now(),
                senderId: 'user',
                senderName: currentUser?.name || 'You',
                text: initialProduct ? `नमस्ते! क्या यह प्रोडक्ट उपलब्ध है?` : `नमस्ते! रील बाज़ार पर आपकी प्रोफाइल देखी।`,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                isSender: true,
                status: 'delivered',
                productAttachment: initialProduct ? {
                  id: initialProduct.id,
                  title: initialProduct.title,
                  price: initialProduct.price,
                  originalPrice: initialProduct.originalPrice,
                  image: initialProduct.image,
                  category: initialProduct.category
                } : undefined
              }
            ]
          };
          setActiveConvId(newConv.id);
          return [newConv, ...prev];
        }
      });
    }
  }, [initialSeller, initialProduct, currentUser]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const activeConversation = conversations.find(c => c.id === activeConvId) || conversations[0];

  // Filter conversations
  const filteredConversations = conversations.filter(c => {
    const matchesSearch = c.participantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.participantHandle.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (c.participantCity && c.participantCity.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesUnread = !filterUnread || c.unreadCount > 0;
    return matchesSearch && matchesUnread;
  });

  const handleSendMessage = (textToSend?: string, attachedProduct?: ProductItem) => {
    const text = textToSend !== undefined ? textToSend : inputText;
    if (!text.trim() && !attachedProduct && !attachedImage) return;

    if (!currentUser) {
      onRequireAuth();
      return;
    }

    if (activeConversation.isBlocked) {
      showToast(lang === 'hi' ? 'आपने इस सेलर को ब्लॉक किया है। पहले अनब्लॉक करें।' : 'Seller is blocked. Unblock to message.');
      return;
    }

    const newMsg: ChatMessage = {
      id: 'msg_' + Date.now() + Math.random(),
      senderId: currentUser.id,
      senderName: currentUser.name,
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSender: true,
      status: 'delivered',
      mediaUrl: attachedImage || undefined,
      mediaType: attachedImage ? 'image' : undefined,
      productAttachment: attachedProduct ? {
        id: attachedProduct.id,
        title: attachedProduct.title,
        price: attachedProduct.price,
        originalPrice: attachedProduct.originalPrice,
        image: attachedProduct.image,
        category: attachedProduct.category
      } : undefined
    };

    setConversations(prev =>
      prev.map(c => {
        if (c.id === activeConversation.id) {
          return {
            ...c,
            lastMessage: newMsg.text || 'Shared an image/product',
            lastTimestamp: newMsg.timestamp,
            messages: [...c.messages, newMsg]
          };
        }
        return c;
      })
    );

    setInputText('');
    setAttachedImage(null);
    setShowProductPicker(false);
    setShowEmojiPicker(false);

    // Simulated Seller Reply after 1.2s
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const responsesHi = [
        'जी नमस्ते! आपका ऑर्डर नोट कर लिया गया है। हम इसे आज शाम तक स्पीड डिलीवरी से पैक कर देंगे। 📦✨',
        'हाँ जी, यह पीस 100% ओरिजिनल है और पूरे भारत में Cash on Delivery (COD) उपलब्ध है!',
        'अगर साइज में कोई भी दिक्कत आए तो 7 दिनों के अंदर फ्री डोरस्टेप रिप्लेसमेंट की सुविधा है।',
        'ज़रूर! हमने स्पेशल डिस्काउंट लागू कर दिया है, आप सीधे नीचे दिए गए बटन से ऑर्डर कर सकते हैं।',
        'धन्यवाद सवाल पूछने के लिए! क्या आप कोई विशिष्ट रंग या साइज देखना चाहते हैं?'
      ];
      const randomResponse = responsesHi[Math.floor(Math.random() * responsesHi.length)];

      const sellerReply: ChatMessage = {
        id: 'reply_' + Date.now(),
        senderId: activeConversation.participantId,
        senderName: activeConversation.participantName,
        text: randomResponse,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isSender: false,
        status: 'read'
      };

      setConversations(prev =>
        prev.map(c => {
          if (c.id === activeConversation.id) {
            return {
              ...c,
              lastMessage: sellerReply.text,
              lastTimestamp: sellerReply.timestamp,
              messages: [...c.messages, sellerReply]
            };
          }
          return c;
        })
      );
    }, 1200);
  };

  const handleDeleteMessage = (messageId: string) => {
    setConversations(prev =>
      prev.map(c => {
        if (c.id === activeConversation.id) {
          return {
            ...c,
            messages: c.messages.filter(m => m.id !== messageId)
          };
        }
        return c;
      })
    );
    showToast(lang === 'hi' ? 'संदेश हटा दिया गया' : 'Message deleted');
  };

  const handleToggleBlock = () => {
    setConversations(prev =>
      prev.map(c => {
        if (c.id === activeConversation.id) {
          const nextBlocked = !c.isBlocked;
          showToast(nextBlocked
            ? (lang === 'hi' ? 'सेलर को ब्लॉक कर दिया गया है' : 'Seller has been blocked')
            : (lang === 'hi' ? 'सेलर को अनब्लॉक किया गया' : 'Seller unblocked'));
          return { ...c, isBlocked: nextBlocked };
        }
        return c;
      })
    );
    setShowMenu(false);
  };

  const handleStartNewChatWithSeller = (seller: typeof AVAILABLE_SELLERS_FOR_CHAT[0]) => {
    const existing = conversations.find(c => c.participantName === seller.name);
    if (existing) {
      setActiveConvId(existing.id);
    } else {
      const newConv: ChatConversation = {
        id: 'conv_' + Date.now(),
        participantId: seller.id,
        participantName: seller.name,
        participantAvatar: seller.avatar,
        participantHandle: seller.handle,
        participantCity: seller.city,
        isVerified: seller.isVerified,
        isOnline: true,
        lastSeen: 'Active now',
        lastMessage: 'नया चैट शुरू किया',
        lastTimestamp: 'Just now',
        unreadCount: 0,
        messages: [
          {
            id: 'm_start_' + Date.now(),
            senderId: seller.id,
            senderName: seller.name,
            text: `नमस्ते! रील बाज़ार स्टोर पर आपका स्वागत है। हमारे पास ${seller.category} का विशेष संग्रह है। मैं आपकी क्या मदद करूँ?`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isSender: false,
            status: 'read'
          }
        ]
      };
      setConversations(prev => [newConv, ...prev]);
      setActiveConvId(newConv.id);
    }
    setShowSellerDirectory(false);
  };

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const quickQuestions = [
    lang === 'hi' ? 'कैश ऑन डिलीवरी (COD) उपलब्ध है क्या?' : 'Is COD available?',
    lang === 'hi' ? 'डिलीवरी कितने दिनों में होगी?' : 'How fast is delivery?',
    lang === 'hi' ? 'कृपया असली अनबॉक्सिंग फोटो भेजें' : 'Send unboxing photo',
    lang === 'hi' ? 'क्या रिटर्न या एक्सचेंज की सुविधा है?' : 'What is return policy?'
  ];

  const quickEmojis = ['❤️', '🔥', '😍', '🛍️', '👍', '🙏', '🥻', '💯'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      {/* Toast Banner */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 text-pink-400 border border-pink-500/40 text-xs px-4 py-2 rounded-full shadow-2xl font-bold flex items-center gap-2 animate-fadeIn">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <div className="relative w-full max-w-4xl bg-neutral-900 border-0 sm:border border-neutral-800 rounded-none sm:rounded-3xl shadow-2xl h-full sm:h-[88vh] max-h-[820px] flex overflow-hidden">
        
        {/* ================= LEFT SIDEBAR: CONVERSATIONS LIST ================= */}
        <div className={`w-full sm:w-80 border-r border-neutral-800 flex flex-col bg-neutral-950 ${activeConvId && 'hidden sm:flex'}`}>
          {/* Top Header */}
          <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-pink-500" />
              <h2 className="font-extrabold text-sm text-white">
                {lang === 'hi' ? 'संदेश व बातचीत' : 'Direct Messages'}
              </h2>
            </div>
            
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowSellerDirectory(true)}
                className="p-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold flex items-center gap-1 shadow-md transition-colors"
                title="Start New Chat"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden md:inline">{lang === 'hi' ? 'नई चैट' : 'New'}</span>
              </button>

              <button
                onClick={onClose}
                className="sm:hidden p-1.5 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="p-3 border-b border-neutral-800/80 space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={lang === 'hi' ? 'सेलर या बातचीत खोजें...' : 'Search sellers or chats...'}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500"
              />
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 text-[11px]">
              <button
                onClick={() => setFilterUnread(false)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                  !filterUnread ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {lang === 'hi' ? 'सभी चैट' : 'All'} ({conversations.length})
              </button>
              <button
                onClick={() => setFilterUnread(true)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                  filterUnread ? 'bg-pink-600 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {lang === 'hi' ? 'अनपढ़े' : 'Unread'}
              </button>
            </div>
          </div>

          {/* Conversations Scrollable List */}
          <div className="flex-1 overflow-y-auto no-scrollbar divide-y divide-neutral-900">
            {filteredConversations.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-500 space-y-2">
                <MessageSquare className="w-8 h-8 mx-auto text-neutral-600" />
                <p>{lang === 'hi' ? 'कोई चैट नहीं मिली' : 'No conversations found'}</p>
                <button
                  onClick={() => setShowSellerDirectory(true)}
                  className="text-pink-400 font-bold hover:underline"
                >
                  {lang === 'hi' ? '+ नए सेलर से चैट शुरू करें' : '+ Start chat with a seller'}
                </button>
              </div>
            ) : (
              filteredConversations.map(conv => {
                const isActive = activeConvId === conv.id;

                return (
                  <div
                    key={conv.id}
                    onClick={() => setActiveConvId(conv.id)}
                    className={`p-3.5 flex items-start gap-3 cursor-pointer transition-colors relative ${
                      isActive ? 'bg-neutral-900/90' : 'hover:bg-neutral-900/40'
                    }`}
                  >
                    {/* Avatar with Online Green Dot */}
                    <div className="relative flex-shrink-0">
                      <img
                        src={conv.participantAvatar}
                        alt={conv.participantName}
                        className="w-11 h-11 rounded-full object-cover border border-neutral-700"
                      />
                      {conv.isOnline && (
                        <span 
                          className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-neutral-950" 
                          title="Online"
                        />
                      )}
                    </div>

                    {/* Meta info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1 min-w-0">
                          <span className="text-xs font-bold text-white truncate">
                            {conv.participantName}
                          </span>
                          {conv.isVerified && (
                            <ShieldCheck className="w-3 h-3 text-blue-400 flex-shrink-0" />
                          )}
                        </div>
                        <span className="text-[10px] text-neutral-500 whitespace-nowrap ml-1">
                          {conv.lastTimestamp}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mt-1">
                        <p className="text-[11px] text-neutral-400 truncate pr-2">
                          {conv.lastMessage}
                        </p>
                        {conv.unreadCount > 0 && (
                          <span className="w-4 h-4 rounded-full bg-pink-600 text-white text-[9px] font-black flex items-center justify-center flex-shrink-0">
                            {conv.unreadCount}
                          </span>
                        )}
                      </div>

                      {conv.participantCity && (
                        <p className="text-[9px] text-neutral-500 flex items-center gap-0.5 mt-0.5">
                          <MapPin className="w-2.5 h-2.5 text-pink-500" />
                          <span>{conv.participantCity}</span>
                        </p>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* ================= RIGHT MAIN: ACTIVE CHAT ROOM ================= */}
        <div className={`flex-1 flex flex-col bg-neutral-900 ${!activeConvId && 'hidden sm:flex'}`}>
          {/* Header */}
          <div className="p-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setActiveConvId('')}
                className="sm:hidden p-1 text-neutral-400 hover:text-white"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div className="relative">
                <img
                  src={activeConversation.participantAvatar}
                  alt={activeConversation.participantName}
                  className="w-10 h-10 rounded-full object-cover border border-neutral-700"
                />
                {activeConversation.isOnline && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-neutral-950" />
                )}
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs font-bold text-white">
                    {activeConversation.participantName}
                  </h3>
                  {activeConversation.isVerified && (
                    <span className="text-[9px] bg-blue-500/20 text-blue-400 px-1 py-0.2 rounded font-semibold flex items-center gap-0.5">
                      <ShieldCheck className="w-2.5 h-2.5" />
                      <span>Verified</span>
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 text-[10px]">
                  {activeConversation.isOnline ? (
                    <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      {lang === 'hi' ? 'ऑनलाइन (सक्रिय)' : 'Online (Active now)'}
                    </span>
                  ) : (
                    <span className="text-neutral-500">
                      {activeConversation.lastSeen || 'Offline'}
                    </span>
                  )}
                  {activeConversation.participantCity && (
                    <>
                      <span className="text-neutral-600">·</span>
                      <span className="text-neutral-400">{activeConversation.participantCity}</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Header Right Actions */}
            <div className="flex items-center gap-1.5 relative">
              <button
                onClick={() => setShowProductPicker(true)}
                className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-pink-300 border border-neutral-700 text-xs font-bold transition-colors"
                title="Share product in chat"
              >
                <ShoppingBag className="w-3.5 h-3.5 text-pink-400" />
                <span>{lang === 'hi' ? 'प्रोडक्ट शेयर' : 'Share Item'}</span>
              </button>

              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              <button
                onClick={onClose}
                className="hidden sm:block p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              {/* 3-Dots Dropdown Menu */}
              {showMenu && (
                <div className="absolute right-0 top-11 z-30 w-44 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-2xl p-1.5 text-xs space-y-1 animate-fadeIn">
                  <button
                    onClick={handleToggleBlock}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-neutral-900 text-rose-400 flex items-center gap-2 font-medium"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>{activeConversation.isBlocked ? (lang === 'hi' ? 'अनब्लॉक करें' : 'Unblock User') : (lang === 'hi' ? 'सेलर को ब्लॉक करें' : 'Block Seller')}</span>
                  </button>
                  <button
                    onClick={() => {
                      showToast(lang === 'hi' ? 'रिपोर्ट दर्ज की गई' : 'Report recorded');
                      setShowMenu(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-neutral-900 text-neutral-300 flex items-center gap-2 font-medium"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                    <span>{lang === 'hi' ? 'रिपोर्ट सेलर' : 'Report Seller'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Block Banner if user is blocked */}
          {activeConversation.isBlocked && (
            <div className="p-2 bg-rose-950/60 border-b border-rose-800/60 text-center text-xs text-rose-300 font-semibold flex items-center justify-center gap-2">
              <Ban className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'आपने इस सेलर को ब्लॉक किया है।' : 'You have blocked this seller.'}</span>
              <button onClick={handleToggleBlock} className="underline ml-1 text-white">
                {lang === 'hi' ? 'अनब्लॉक करें' : 'Unblock'}
              </button>
            </div>
          )}

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 no-scrollbar bg-neutral-950/40">
            {activeConversation.messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col group ${msg.isSender ? 'items-end' : 'items-start'}`}
              >
                <div className="relative max-w-[85%] sm:max-w-[70%]">
                  {/* Message Bubble Body */}
                  <div
                    className={`rounded-2xl p-3 text-xs leading-relaxed ${
                      msg.isSender
                        ? 'bg-gradient-to-r from-pink-600 via-pink-700 to-purple-600 text-white rounded-br-xs shadow-md'
                        : 'bg-neutral-800 text-neutral-200 rounded-bl-xs border border-neutral-700/60'
                    }`}
                  >
                    {/* Media Attachment (Image) */}
                    {msg.mediaUrl && (
                      <div className="mb-2.5 rounded-xl overflow-hidden border border-white/10 max-h-56 bg-black">
                        <img
                          src={msg.mediaUrl}
                          alt="Attachment"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {/* Product Preview Card Attachment */}
                    {msg.productAttachment && (
                      <div className="mb-2.5 p-2.5 rounded-xl bg-black/40 border border-white/15 space-y-2">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={msg.productAttachment.image}
                            alt={msg.productAttachment.title}
                            className="w-12 h-12 rounded-lg object-cover flex-shrink-0 border border-white/10"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-bold text-white text-xs truncate">
                              {msg.productAttachment.title}
                            </p>
                            <div className="flex items-baseline gap-1.5 mt-0.5">
                              <span className="text-amber-300 font-extrabold text-xs">
                                ₹{msg.productAttachment.price}
                              </span>
                              {msg.productAttachment.originalPrice && (
                                <span className="line-through text-neutral-400 text-[10px]">
                                  ₹{msg.productAttachment.originalPrice}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Product Action Buttons */}
                        <div className="flex items-center gap-1.5 pt-1 border-t border-white/10">
                          {onOpenProductDetail && (
                            <button
                              onClick={() => {
                                const prod = allProducts.find(p => p.id === msg.productAttachment?.id) || {
                                  id: msg.productAttachment?.id || 'prod_1',
                                  title: msg.productAttachment?.title || '',
                                  price: msg.productAttachment?.price || 999,
                                  originalPrice: msg.productAttachment?.originalPrice || 1999,
                                  discountPercent: 50,
                                  rating: 4.8,
                                  reviewsCount: 120,
                                  image: msg.productAttachment?.image || '',
                                  sellerName: activeConversation.participantName,
                                  sellerCity: activeConversation.participantCity || 'India',
                                  isVerifiedSeller: true,
                                  category: 'Fashion',
                                  description: 'Product shared directly in chat',
                                  inStock: true,
                                  commissionRate: 15,
                                  features: ['Genuine Quality', 'Cash on Delivery Available']
                                };
                                onOpenProductDetail(prod);
                              }}
                              className="flex-1 py-1 px-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[10px] font-bold text-center transition-colors flex items-center justify-center gap-1"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>{lang === 'hi' ? 'विवरण देखें' : 'View Specs'}</span>
                            </button>
                          )}

                          {onOpenBuyModal && (
                            <button
                              onClick={() => {
                                const prod = allProducts.find(p => p.id === msg.productAttachment?.id) || {
                                  id: msg.productAttachment?.id || 'prod_1',
                                  title: msg.productAttachment?.title || '',
                                  price: msg.productAttachment?.price || 999,
                                  originalPrice: msg.productAttachment?.originalPrice || 1999,
                                  discountPercent: 50,
                                  rating: 4.8,
                                  reviewsCount: 120,
                                  image: msg.productAttachment?.image || '',
                                  sellerName: activeConversation.participantName,
                                  sellerCity: activeConversation.participantCity || 'India',
                                  isVerifiedSeller: true,
                                  category: 'Fashion',
                                  description: 'Product shared directly in chat',
                                  inStock: true,
                                  commissionRate: 15,
                                  features: ['Genuine Quality', 'Cash on Delivery Available']
                                };
                                onOpenBuyModal(prod);
                              }}
                              className="flex-1 py-1 px-2 rounded-lg bg-pink-600 hover:bg-pink-500 text-white text-[10px] font-bold text-center shadow-md transition-colors"
                            >
                              {lang === 'hi' ? 'अभी खरीदें (COD)' : 'Buy Now (COD)'}
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Text Message */}
                    {msg.text && <p className="break-words leading-relaxed">{msg.text}</p>}
                  </div>

                  {/* Delete Button (visible on hover) */}
                  <button
                    onClick={() => handleDeleteMessage(msg.id)}
                    className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 p-1 rounded-full bg-neutral-900 border border-neutral-700 text-neutral-400 hover:text-rose-400 transition-opacity shadow-md"
                    title="Delete message"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>

                {/* Message Meta Info: Timestamp + Read Status */}
                <div className="flex items-center gap-1.5 mt-1 text-[10px] text-neutral-500 px-1">
                  <span>{msg.timestamp}</span>
                  {msg.isSender && (
                    <span title={msg.status === 'read' ? 'Read' : msg.status === 'delivered' ? 'Delivered' : 'Sent'}>
                      {msg.status === 'read' ? (
                        <CheckCheck className="w-3.5 h-3.5 text-pink-400" />
                      ) : msg.status === 'delivered' ? (
                        <CheckCheck className="w-3.5 h-3.5 text-neutral-400" />
                      ) : (
                        <Check className="w-3.5 h-3.5 text-neutral-400" />
                      )}
                    </span>
                  )}
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex items-center gap-2 text-xs text-neutral-400 bg-neutral-800/70 border border-neutral-700/60 px-3 py-2 rounded-2xl w-fit animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-pink-500 animate-bounce" />
                <span className="w-1.5 h-1.5 rounded-full bg-pink-500 animate-bounce [animation-delay:0.2s]" />
                <span className="w-1.5 h-1.5 rounded-full bg-pink-500 animate-bounce [animation-delay:0.4s]" />
                <span className="text-[11px] ml-1 font-medium">
                  {activeConversation.participantName} {lang === 'hi' ? 'टाइप कर रहे हैं...' : 'is typing...'}
                </span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Question Chips */}
          <div className="p-2 border-t border-neutral-800 bg-neutral-950 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {quickQuestions.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(q)}
                className="whitespace-nowrap px-3 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 hover:text-white hover:border-pink-500/50 hover:bg-neutral-800 transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Attached Image Preview before send */}
          {attachedImage && (
            <div className="px-4 py-2 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img src={attachedImage} alt="Preview" className="w-12 h-12 rounded-lg object-cover border border-neutral-700" />
                <span className="text-xs text-neutral-300 font-medium">{lang === 'hi' ? 'फोटो अटैच की गई' : 'Photo attached'}</span>
              </div>
              <button
                onClick={() => setAttachedImage(null)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Quick Emoji Bar */}
          {showEmojiPicker && (
            <div className="px-4 py-2 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between text-lg">
              {quickEmojis.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setInputText(prev => prev + emoji)}
                  className="p-1 hover:scale-125 transition-transform"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          {/* Message Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 border-t border-neutral-800 bg-neutral-950 flex items-center gap-2"
          >
            {/* Attachment Button */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*,video/*"
              onChange={handleImageFileUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-xl text-neutral-400 hover:text-pink-400 hover:bg-neutral-900 transition-colors"
              title="Attach Image or Video"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* Product Share Trigger */}
            <button
              type="button"
              onClick={() => setShowProductPicker(true)}
              className="p-2 rounded-xl text-neutral-400 hover:text-pink-400 hover:bg-neutral-900 transition-colors"
              title="Attach Product from Store"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>

            {/* Emoji Trigger */}
            <button
              type="button"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="p-2 rounded-xl text-neutral-400 hover:text-amber-400 hover:bg-neutral-900 transition-colors"
              title="Emoji"
            >
              <Smile className="w-4 h-4" />
            </button>

            {/* Text Input */}
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={lang === 'hi' ? 'सेलर से कुछ भी पूछें...' : 'Ask seller anything...'}
              className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500 transition-colors"
            />

            {/* Send Button */}
            <button
              type="submit"
              disabled={!inputText.trim() && !attachedImage}
              className="p-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 text-white disabled:opacity-40 hover:opacity-95 shadow-md shadow-pink-600/30 transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* ================= MODAL: START NEW CHAT (SELLER DIRECTORY) ================= */}
      {showSellerDirectory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-pink-500" />
                <h3 className="font-bold text-sm text-white">
                  {lang === 'hi' ? 'नया चैट शुरू करें' : 'Start New Chat'}
                </h3>
              </div>
              <button
                onClick={() => setShowSellerDirectory(false)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              {lang === 'hi' ? 'वेरिफाइड सेलर या क्रिएटर चुनें और तुरंत बात करें:' : 'Choose a verified maker or creator to chat:'}
            </p>

            <div className="space-y-2.5 max-h-72 overflow-y-auto no-scrollbar">
              {AVAILABLE_SELLERS_FOR_CHAT.map((seller) => (
                <div
                  key={seller.id}
                  onClick={() => handleStartNewChatWithSeller(seller)}
                  className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80 hover:border-pink-500 flex items-center justify-between cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={seller.avatar}
                      alt={seller.name}
                      className="w-10 h-10 rounded-full object-cover border border-neutral-700"
                    />
                    <div>
                      <p className="text-xs font-bold text-white flex items-center gap-1">
                        {seller.name}
                        {seller.isVerified && <ShieldCheck className="w-3 h-3 text-blue-400" />}
                      </p>
                      <p className="text-[10px] text-pink-400 font-medium">{seller.category}</p>
                      <p className="text-[9px] text-neutral-500">📍 {seller.city} · ⭐ {seller.rating}</p>
                    </div>
                  </div>

                  <ChevronRight className="w-4 h-4 text-neutral-500" />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: SHARE PRODUCT PICKER ================= */}
      {showProductPicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-pink-500" />
                <h3 className="font-bold text-sm text-white">
                  {lang === 'hi' ? 'चैट में प्रोडक्ट शेयर करें' : 'Share Product in Chat'}
                </h3>
              </div>
              <button
                onClick={() => setShowProductPicker(false)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              {lang === 'hi' ? 'कैटलॉग से प्रोडक्ट चुनें जिसे आप सेलर को भेजना चाहते हैं:' : 'Select a product to attach to your message:'}
            </p>

            <div className="flex-1 overflow-y-auto space-y-2.5 no-scrollbar pr-1">
              {allProducts.map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => {
                    handleSendMessage(`मुझे इस प्रोडक्ट के बारे में पूछना है:`, prod);
                  }}
                  className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 hover:border-pink-500 flex items-center justify-between gap-3 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={prod.image}
                      alt={prod.title}
                      className="w-12 h-12 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">{prod.title}</p>
                      <div className="flex items-baseline gap-2 mt-0.5">
                        <span className="text-xs font-black text-pink-400">₹{prod.price}</span>
                        <span className="text-[10px] text-neutral-500 line-through">₹{prod.originalPrice}</span>
                      </div>
                      <p className="text-[9px] text-neutral-400">📍 {prod.sellerCity}</p>
                    </div>
                  </div>

                  <span className="px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-[11px] font-bold flex-shrink-0">
                    {lang === 'hi' ? 'भेजें' : 'Send'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
