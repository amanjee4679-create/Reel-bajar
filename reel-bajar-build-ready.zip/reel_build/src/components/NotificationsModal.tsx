import React from 'react';
import { X, Bell, Package, Wallet, MessageSquare, Check, Sparkles, UserPlus } from 'lucide-react';
import { NotificationItem } from '../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onNotificationClick: (notif: NotificationItem) => void;
  lang: 'hi' | 'en';
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
  onNotificationClick,
  lang
}) => {
  if (!isOpen) return null;

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'order':
        return <Package className="w-4 h-4 text-emerald-400" />;
      case 'commission':
        return <Wallet className="w-4 h-4 text-amber-400" />;
      case 'chat':
        return <MessageSquare className="w-4 h-4 text-pink-400" />;
      case 'follower':
        return <UserPlus className="w-4 h-4 text-blue-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-purple-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-pink-500/10 text-pink-400 border border-pink-500/20">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">
                {lang === 'hi' ? 'सूचनाएं (Notifications)' : 'Notifications'}
              </h3>
              {unreadCount > 0 && (
                <p className="text-[10px] text-pink-400 font-semibold">
                  {unreadCount} {lang === 'hi' ? 'नयी सूचनाएं' : 'new unread notifications'}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                onClick={onMarkAllRead}
                className="text-[11px] font-semibold text-neutral-400 hover:text-white flex items-center gap-1 transition-colors"
              >
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>{lang === 'hi' ? 'सभी पढ़ें' : 'Mark all read'}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 no-scrollbar">
          {notifications.length === 0 ? (
            <div className="text-center py-12 text-neutral-500 text-xs">
              {lang === 'hi' ? 'कोई नयी सूचना नहीं है।' : 'No notifications.'}
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => onNotificationClick(notif)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                  !notif.isRead
                    ? 'bg-neutral-950 border-pink-500/30 hover:border-pink-500'
                    : 'bg-neutral-950/50 border-neutral-800/80 hover:bg-neutral-900 text-neutral-300'
                }`}
              >
                <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 flex-shrink-0 mt-0.5">
                  {getIcon(notif.type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className={`text-xs font-bold truncate ${!notif.isRead ? 'text-white' : 'text-neutral-300'}`}>
                      {notif.title}
                    </p>
                    <span className="text-[10px] text-neutral-500 whitespace-nowrap">
                      {notif.timestamp}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-0.5 leading-relaxed">
                    {notif.body}
                  </p>
                </div>

                {!notif.isRead && (
                  <span className="w-2 h-2 rounded-full bg-pink-500 flex-shrink-0 mt-1.5" />
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
