import React, { useState, useRef, useEffect } from 'react';
import { 
  Rocket, 
  Download, 
  Copy, 
  Check, 
  CheckCircle2, 
  Sparkles, 
  Terminal, 
  Image as ImageIcon, 
  Smartphone, 
  FileText, 
  ShieldAlert, 
  ExternalLink,
  Layers,
  Key,
  Flame,
  Package,
  FolderArchive
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { LAUNCH_STEPS } from '../data/mockData';
import { exportProjectZip } from '../utils/zipExporter';

interface PlayStoreLaunchHubProps {
  lang: 'hi' | 'en';
}

export const PlayStoreLaunchHub: React.FC<PlayStoreLaunchHubProps> = ({ lang }) => {
  const [activeStep, setActiveStep] = useState<string>('branding');
  const [isExportingZip, setIsExportingZip] = useState<boolean>(false);
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>({
    branding: true,
    build: false,
    listing: false,
    screenshots: false,
    publishing: false
  });

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Canvas refs for real HD image downloads
  const iconCanvasRef = useRef<HTMLCanvasElement>(null);
  const bannerCanvasRef = useRef<HTMLCanvasElement>(null);

  // Screenshot generator state
  const [activeScreenshotSlide, setActiveScreenshotSlide] = useState<number>(0);

  const copyToClipboard = (text: string, keyName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(keyName);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const toggleStepComplete = (stepId: string) => {
    setCompletedSteps(prev => {
      const next = { ...prev, [stepId]: !prev[stepId] };
      if (next[stepId]) {
        try {
          confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
        } catch {}
      }
      return next;
    });
  };

  const handleDownloadZip = async () => {
    setIsExportingZip(true);
    try {
      await exportProjectZip();
      confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
    } catch (err) {
      console.error(err);
    } finally {
      setIsExportingZip(false);
    }
  };

  // Draw 512x512 App Icon on Canvas
  useEffect(() => {
    const canvas = iconCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background Gradient
    const grad = ctx.createLinearGradient(0, 0, 512, 512);
    grad.addColorStop(0, '#FF0055');
    grad.addColorStop(0.5, '#8A2BE2');
    grad.addColorStop(1, '#4F46E5');

    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0, 0, 512, 512);

    // Rounded rectangle base
    ctx.beginPath();
    ctx.roundRect(24, 24, 464, 464, 96);
    ctx.fillStyle = grad;
    ctx.fill();

    // Shopping Bag body
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.roundRect(140, 180, 232, 230, 36);
    ctx.fill();

    // Bag Handle
    ctx.beginPath();
    ctx.arc(256, 180, 55, Math.PI, 0, false);
    ctx.lineWidth = 26;
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineCap = 'round';
    ctx.stroke();

    // Play Triangle inside bag
    ctx.beginPath();
    ctx.moveTo(236, 250);
    ctx.lineTo(296, 290);
    ctx.lineTo(236, 330);
    ctx.closePath();
    ctx.fillStyle = '#FF0055';
    ctx.fill();

    // Gold Star badge on top-right of bag
    ctx.beginPath();
    ctx.arc(365, 175, 30, 0, Math.PI * 2);
    ctx.fillStyle = '#F59E0B';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#FFFFFF';
    ctx.stroke();
  }, [activeStep]);

  // Draw 1024x500 Feature Graphic on Canvas
  useEffect(() => {
    const canvas = bannerCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dark sleek gradient background
    const bgGrad = ctx.createLinearGradient(0, 0, 1024, 500);
    bgGrad.addColorStop(0, '#0F0C20');
    bgGrad.addColorStop(0.5, '#1A0B2E');
    bgGrad.addColorStop(1, '#05050A');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 1024, 500);

    // Glow orb
    const radial = ctx.createRadialGradient(800, 250, 20, 800, 250, 400);
    radial.addColorStop(0, 'rgba(255, 0, 85, 0.4)');
    radial.addColorStop(1, 'rgba(255, 0, 85, 0)');
    ctx.fillStyle = radial;
    ctx.fillRect(0, 0, 1024, 500);

    // Headline Text
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 54px sans-serif';
    ctx.fillText('Reel Bajar · रील बाज़ार', 70, 180);

    // Gradient tagline
    ctx.fillStyle = '#FF4D8D';
    ctx.font = 'bold 36px sans-serif';
    ctx.fillText('रील्स देखो · सीधे खरीदो!', 70, 240);

    ctx.fillStyle = '#94A3B8';
    ctx.font = 'normal 22px sans-serif';
    ctx.fillText('India’s #1 Short Video Shopping & Creator Marketplace', 70, 290);
    ctx.fillText('✓ Direct from Weavers & Makers   ✓ 1-Click COD   ✓ 7-Day Returns', 70, 335);

    // App Badge
    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.beginPath();
    ctx.roundRect(70, 375, 240, 56, 16);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 20px sans-serif';
    ctx.fillText('▶ Google Play', 110, 410);

    // Right phone mockup graphic
    ctx.fillStyle = '#171725';
    ctx.beginPath();
    ctx.roundRect(700, 60, 250, 460, 32);
    ctx.fill();
    ctx.strokeStyle = '#FF0055';
    ctx.lineWidth = 4;
    ctx.stroke();

    // Phone screen play button
    ctx.fillStyle = '#FF0055';
    ctx.beginPath();
    ctx.arc(825, 250, 40, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(818, 235);
    ctx.lineTo(842, 250);
    ctx.lineTo(818, 265);
    ctx.closePath();
    ctx.fill();
  }, [activeStep]);

  const downloadIcon = () => {
    if (!iconCanvasRef.current) return;
    const link = document.createElement('a');
    link.download = 'ic_launcher-512.png';
    link.href = iconCanvasRef.current.toDataURL('image/png');
    link.click();
  };

  const downloadBanner = () => {
    if (!bannerCanvasRef.current) return;
    const link = document.createElement('a');
    link.download = 'feature_graphic-1024x500.png';
    link.href = bannerCanvasRef.current.toDataURL('image/png');
    link.click();
  };

  // Screenshots preview slides
  const screenshotSlides = [
    {
      titleHi: 'रील्स देखो, सीधे खरीदो!',
      titleEn: 'Watch Reels, Buy Directly!',
      subtitle: 'शॉर्ट वीडियो में असली प्रोडक्ट क्वालिटी देखें',
      image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80',
      badge: '100% Genuine Handloom'
    },
    {
      titleHi: 'सीधे बुनकरों और निर्माताओं से!',
      titleEn: 'Direct from Verified Makers',
      subtitle: 'कोई बिचौलिया नहीं, 50% से 70% तक की छूट',
      image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80',
      badge: 'Factory Wholesale Price'
    },
    {
      titleHi: '1-क्लिक कैश ऑन डिलीवरी (COD)',
      titleEn: '1-Click Cash on Delivery',
      subtitle: 'घर पर सामान पहुँचने पर ही पैसे दें',
      image: 'https://images.unsplash.com/photo-1570831739435-6601aa3fa4fb?auto=format&fit=crop&w=600&q=80',
      badge: 'Zero Prepayment Needed'
    },
    {
      titleHi: 'क्रिएटर बनें और कमीशन कमाएं',
      titleEn: 'Post Reels & Earn Commission',
      subtitle: 'हर ऑर्डर पर 12% से 18% तक सीधा बैंक में',
      image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80',
      badge: 'Instant UPI Payouts'
    },
    {
      titleHi: '7 दिन की आसान वापसी गारंटी',
      titleEn: '7-Day Hassle-Free Returns',
      subtitle: 'पसंद न आने पर पूरा रिफंड या रिप्लेसमेंट',
      image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=600&q=80',
      badge: 'Buyer Protection Guaranteed'
    }
  ];

  const keystoreCommand = `keytool -genkey -v -keystore reelbajar-release.keystore -alias reelbajar -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Reel Bajar, OU=App, O=Reel Bajar Commerce, L=Bengaluru, ST=Karnataka, C=IN"`;
  
  const bubblewrapCommand = `# 1. Install Bubblewrap CLI
npm install -g @bubblewrap/cli

# 2. Initialize Android Project from PWA Manifest
bubblewrap init --manifest=https://your-domain.com/manifest.webmanifest

# 3. Build Production Signed AAB (Android App Bundle)
bubblewrap build --signingKeyPath=./reelbajar-release.keystore --signingKeyAlias=reelbajar

# -> Generates: app-release-bundle.aab (Upload to Google Play Console)`;

  const playStoreShortDescHi = `रील्स देखो, सीधे खरीदो! भारत का अपना शॉर्ट वीडियो शॉपिंग और क्रिएटर बाज़ार।`;
  const playStoreTitleHi = `Reel Bajar - रील बाज़ार: Short Video Shopping`;
  
  const playStoreFullDesc = `🌟 Reel Bajar (रील बाज़ार) - रील्स देखो, परखें और सीधे खरीदो! 🛍️✨

Reel Bajar भारत का पहला ऐसा सोशल कॉमर्स मंच है जहाँ आप शॉर्ट वीडियो और रील्स देखकर सीधे बुनकरों, कारीगरों और निर्माताओं से सामान खरीद सकते हैं।

🔥 मुख्य विशेषताएं (Key Features):
• 🎬 लाइव वीडियो शॉपिंग: हर प्रोडक्ट का असली वीडियो देखें, बिना किसी बनावटी फिल्टर के।
• 🥻 सीधा कारीगरों से: बनारसी साड़ियां, जयपुरी कुर्तियां, लेदर क्राफ्ट और गैजेट्स फैक्ट्री रेट पर।
• 💵 1-क्लिक कैश ऑन डिलीवरी (COD): पूरे भारत में सामान घर पहुँचने पर ही पैसे दें।
• 🚚 मुफ्त होम डिलीवरी: 3 से 5 दिनों में पूरे भारत में सुरक्षित डिलीवरी।
• 🔄 7 दिन की आसान वापसी: साइज या क्वालिटी पसंद न आने पर 100% रिप्लेसमेंट या रिफंड।
• ✨ क्रिएटर स्टूडियो: अपनी रील्स बनाएं, प्रोडक्ट्स टैग करें और हर बिक्री पर 12%-18% कमीशन कमाएं।
• 💬 डायरेक्ट सेलर चैट: खरीदने से पहले लाइव चैट में फोटो और सवाल पूछें।

📍 श्रेणियां (Categories):
- महिला फैशन (साड़ियां, सूट, कुर्तियां)
- इलेक्ट्रॉनिक्स (TWS ईयरबड्स, स्मार्ट वॉच)
- किचन व होम डेकोर गैजेट्स
- ब्यूटी और नेचुरल स्किनकेयर
- हैंडमेड लेदर व एक्सेसरीज

📞 ग्राहक सेवा व सहायता:
ईमेल: support@reelbajar.in
वेबसाइट: https://reelbajar.in
स्थान: बेंगलुरु, कर्नाटक, भारत।`;

  const privacyPolicyText = `Privacy Policy for Reel Bajar (रील बाज़ार)
Last updated: September 2026

Reel Bajar ("we", "our", or "us") is committed to protecting your privacy in compliance with the Information Technology Act, 2000 (India) and Google Play Developer Policies.

1. Information We Collect:
- Account Information: Name, phone number for OTP verification, delivery address.
- Transaction Details: Order history, items purchased, COD/UPI status (we do not store raw card numbers or CVVs).
- User Generated Content: Reels, video uploads, audio tracks, and comments you share.

2. How We Use Information:
- To process and deliver your orders to your doorstep.
- To enable creator commission payouts to verified UPI accounts.
- To prevent fraud and enhance customer support.

3. Data Safety & Deletion:
Users can request account and data deletion at any time via Profile Settings or by emailing privacy@reelbajar.in. We never sell your personal data to third-party brokers.`;

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 space-y-8">
      {/* Top Header */}
      <div className="relative rounded-3xl bg-gradient-to-r from-amber-500/10 via-pink-500/10 to-purple-500/10 border border-amber-500/30 p-6 sm:p-8 shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold mb-3">
              <Rocket className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'hi' ? 'Play Store आधिकारिक लॉन्च सूट' : 'Official Play Store Launch Suite'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {lang === 'hi' ? 'Reel Bajar को Google Play Store पर लाइव करें' : 'Launch Reel Bajar on Google Play Store'}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 mt-2 leading-relaxed">
              {lang === 'hi'
                ? 'शुरू से लेकर Play Store पर पब्लिश होने तक का संपूर्ण रोडमैप: HD ऐप आइकन (512x512), 1024x500 बैनर, APK/AAB गाइड, ASO कीवर्ड्स और 14-दिन टेस्ट कंप्लायंस।'
                : 'Complete zero-to-publishing guide: HD 512x512 icons, 1024x500 banner, AAB build commands, ASO listing, screenshots and Play Console checklist.'}
            </p>

            {/* Quick Export ZIP Button */}
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <a
                href="/reel-bajar-source-code.zip"
                download="reel-bajar-source-code.zip"
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-pink-500 to-purple-600 hover:opacity-95 text-neutral-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-transform hover:scale-105"
              >
                <FolderArchive className="w-4 h-4 text-neutral-950" />
                <span>{lang === 'hi' ? 'संपूर्ण सोर्स कोड डाउनलोड करें (.ZIP)' : 'Download Project ZIP'}</span>
              </a>
            </div>
          </div>

          {/* Quick Stats / Progress */}
          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center gap-4 flex-shrink-0">
            <div>
              <p className="text-[11px] text-neutral-400">{lang === 'hi' ? 'लॉन्च तत्परता' : 'Launch Readiness'}</p>
              <p className="text-2xl font-black text-amber-400">
                {Math.round((Object.values(completedSteps).filter(Boolean).length / 5) * 100)}%
              </p>
              <p className="text-[10px] text-neutral-400">
                {Object.values(completedSteps).filter(Boolean).length} / 5 {lang === 'hi' ? 'कदम पूर्ण' : 'Steps done'}
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Flame className="w-6 h-6 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      {/* Step Selector Horizontal Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {LAUNCH_STEPS.map((step) => {
          const isDone = completedSteps[step.id];
          const isActive = activeStep === step.id;

          return (
            <button
              key={step.id}
              onClick={() => setActiveStep(step.id)}
              className={`p-3 rounded-2xl text-left border transition-all flex flex-col justify-between ${
                isActive
                  ? 'bg-neutral-800 border-amber-400 shadow-lg text-white'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 text-neutral-400'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${
                  isActive ? 'bg-amber-400 text-neutral-950' : 'bg-neutral-800 text-neutral-400'
                }`}>
                  STEP 0{step.stepNumber}
                </span>
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <div className="w-3.5 h-3.5 rounded-full border border-neutral-600" />
                )}
              </div>
              <p className="text-xs font-bold leading-tight text-white line-clamp-1">
                {lang === 'hi' ? step.titleHi.split('(')[0] : step.titleEn.split('(')[0]}
              </p>
            </button>
          );
        })}
      </div>

      {/* Active Step Panel */}
      <div className="rounded-3xl bg-neutral-900 border border-neutral-800 p-6 sm:p-8 space-y-6 shadow-xl">
        
        {/* STEP 1: BRANDING & ICONS */}
        {activeStep === 'branding' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-amber-400" />
                  <span>{lang === 'hi' ? '1. लोगो और ऐप आइकन (HD 512x512 & 1024x500)' : '1. Logo & App Icons (HD 512x512 & 1024x500)'}</span>
                </h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {lang === 'hi'
                    ? 'Google Play Console के लिए 32-bit PNG 512x512 ऐप आइकन और 1024x500 फीचर बैनर अनिवार्य है।'
                    : 'Google Play requires exactly 512x512 32-bit PNG app icon and 1024x500 feature graphic.'}
                </p>
              </div>

              <button
                onClick={() => toggleStepComplete('branding')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  completedSteps.branding
                    ? 'bg-emerald-600 text-white'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>{completedSteps.branding ? 'पूर्ण मार्क किया गया (Done)' : 'कदम पूर्ण मार्क करें'}</span>
              </button>
            </div>

            {/* Canvas Exporters */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* 512x512 App Icon Box */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-white">Play Store App Icon (512x512 px)</h3>
                    <p className="text-[10px] text-neutral-400">Format: 32-bit PNG · Max size 1024KB</p>
                  </div>
                  <button
                    onClick={downloadIcon}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs shadow-md transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PNG</span>
                  </button>
                </div>

                <div className="flex flex-col items-center justify-center p-4 bg-neutral-900/60 rounded-xl border border-neutral-800">
                  <canvas
                    ref={iconCanvasRef}
                    width={512}
                    height={512}
                    className="w-36 h-36 rounded-3xl shadow-2xl border border-neutral-700"
                  />
                  
                  {/* Adaptive Shapes Preview */}
                  <div className="flex items-center gap-3 mt-4 text-[10px] text-neutral-400">
                    <span>Android Adaptive Previews:</span>
                    <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-pink-600 to-indigo-600" title="Circle" />
                    <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-pink-600 to-indigo-600" title="Squircle" />
                    <div className="w-6 h-6 rounded bg-gradient-to-tr from-pink-600 to-indigo-600" title="Square" />
                  </div>
                </div>

                <div className="text-[11px] text-neutral-400 space-y-1">
                  <p className="text-white font-semibold">Mipmap Sizes Included:</p>
                  <p>• mdpi: 48x48 | hdpi: 72x72 | xhdpi: 96x96 | xxhdpi: 144x144 | xxxhdpi: 192x192</p>
                </div>
              </div>

              {/* 1024x500 Feature Graphic Box */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-white">Feature Graphic (1024x500 px)</h3>
                    <p className="text-[10px] text-neutral-400">Play Store Header Banner · Mandatory</p>
                  </div>
                  <button
                    onClick={downloadBanner}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PNG</span>
                  </button>
                </div>

                <div className="flex flex-col items-center justify-center p-4 bg-neutral-900/60 rounded-xl border border-neutral-800">
                  <canvas
                    ref={bannerCanvasRef}
                    width={1024}
                    height={500}
                    className="w-full max-w-[360px] aspect-[1024/500] rounded-xl shadow-2xl border border-neutral-700"
                  />
                  <p className="text-[10px] text-neutral-400 mt-3 text-center">
                    {lang === 'hi' ? 'उच्च रिज़ॉल्यूशन बैनर जिसमें ऐप की यूएसपी और ब्रांडिंग शामिल है।' : 'Hi-res Play Store promotional feature graphic.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: APK & AAB BUILD GUIDE */}
        {activeStep === 'build' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-amber-400" />
                  <span>{lang === 'hi' ? '2. APK और AAB (Android App Bundle) निर्माण' : '2. APK & AAB (Android App Bundle) Build Guide'}</span>
                </h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Google Play Store अब पुराने .apk की जगह केवल हस्ताक्षरित <strong>.aab (Android App Bundle)</strong> स्वीकार करता है।
                </p>
              </div>

              <button
                onClick={() => toggleStepComplete('build')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  completedSteps.build
                    ? 'bg-emerald-600 text-white'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>{completedSteps.build ? 'पूर्ण मार्क किया गया (Done)' : 'कदम पूर्ण मार्क करें'}</span>
              </button>
            </div>

            {/* Installable APK Direct Download Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-teal-950/40 to-neutral-900 border border-emerald-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{lang === 'hi' ? 'ReelBajar.apk सीधे डाउनलोड करें (Installable APK)' : 'Download ReelBajar.apk (Direct APK)'}</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">READY</span>
                  </h3>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed max-w-xl">
                  {lang === 'hi'
                    ? 'आपके एंड्रॉइड फोन के लिए प्रोडक्शन रेडी ReelBajar.apk तैयार है। इसे डाउनलोड करें और फोन में सीधे इंस्टॉल करें।'
                    : 'Production-ready ReelBajar.apk package ready for immediate download and installation on any Android phone.'}
                </p>
                <div className="flex items-center gap-2 text-[10px] text-neutral-400 pt-1">
                  <span>Package: com.reelbajar.app</span>
                  <span>·</span>
                  <span>Version: 1.0.0</span>
                  <span>·</span>
                  <span>Target SDK: 34</span>
                </div>
              </div>

              <a
                href="/ReelBajar.apk"
                download="ReelBajar.apk"
                className="py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-neutral-950 font-black text-xs shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 transition-all flex-shrink-0"
              >
                <Download className="w-4 h-4 text-neutral-950" />
                <span>{lang === 'hi' ? 'ReelBajar.apk डाउनलोड करें' : 'Download ReelBajar.apk'}</span>
              </a>
            </div>

            {/* Full Source Code ZIP Download Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-neutral-900 border border-amber-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <FolderArchive className="w-5 h-5 text-amber-400" />
                  <h3 className="text-sm font-bold text-white">
                    {lang === 'hi' ? 'संपूर्ण प्रोजेक्ट सोर्स कोड डाउनलोड करें (.ZIP)' : 'Download Complete Source Code (.ZIP)'}
                  </h3>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed max-w-xl">
                  {lang === 'hi' 
                    ? 'सभी React/Vite फाइल्स, Android Studio मैनिफेस्ट (AndroidManifest.xml), Capacitor कॉन्फ़िग, आइकॉन और स्टेप-बाय-स्टेप APK/AAB गाइड सहित।'
                    : 'Includes all React components, Android Manifest, Capacitor config, icons, and step-by-step APK/AAB build instructions.'}
                </p>
              </div>

              <a
                href="/reel-bajar-source-code.zip"
                download="reel-bajar-source-code.zip"
                className="py-3 px-5 rounded-xl bg-gradient-to-r from-amber-500 via-pink-500 to-purple-600 hover:opacity-95 text-neutral-950 font-black text-xs shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-all flex-shrink-0"
              >
                <Download className="w-4 h-4 text-neutral-950" />
                <span>{lang === 'hi' ? 'सोर्स कोड ZIP डाउनलोड करें' : 'Download Source ZIP'}</span>
              </a>
            </div>

            {/* Keystore Signing Box */}
            <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white">
                    {lang === 'hi' ? 'कदम 2.1: रिलीज की-स्टोर (Keystore) जनरेट करें' : 'Step 2.1: Generate Release Keystore'}
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard(keystoreCommand, 'keystore')}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 transition-colors"
                >
                  {copiedKey === 'keystore' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'keystore' ? 'Copied!' : 'Copy Command'}</span>
                </button>
              </div>
              <pre className="p-3.5 rounded-xl bg-black font-mono text-[11px] text-amber-300 overflow-x-auto border border-neutral-800/80">
                {keystoreCommand}
              </pre>
            </div>

            {/* Bubblewrap TWA Build Command */}
            <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-pink-400" />
                  <span className="text-xs font-bold text-white">
                    {lang === 'hi' ? 'कदम 2.2: Bubblewrap TWA से AAB बंडल तैयार करें' : 'Step 2.2: Build Signed AAB via Bubblewrap CLI'}
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard(bubblewrapCommand, 'bubblewrap')}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 transition-colors"
                >
                  {copiedKey === 'bubblewrap' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'bubblewrap' ? 'Copied!' : 'Copy Commands'}</span>
                </button>
              </div>
              <pre className="p-3.5 rounded-xl bg-black font-mono text-[11px] text-emerald-400 overflow-x-auto border border-neutral-800/80 whitespace-pre-wrap">
                {bubblewrapCommand}
              </pre>
            </div>

            {/* Package Configuration */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-neutral-400 text-[10px]">Package Name:</span>
                <p className="font-mono text-white font-bold mt-0.5">com.reelbajar.app</p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-neutral-400 text-[10px]">Target SDK / Android:</span>
                <p className="font-mono text-white font-bold mt-0.5">API 34 (Android 14+)</p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-neutral-400 text-[10px]">Version Code / Name:</span>
                <p className="font-mono text-white font-bold mt-0.5">1 / 1.0.0 (Release)</p>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: PLAY STORE LISTING & ASO */}
        {activeStep === 'listing' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-amber-400" />
                  <span>{lang === 'hi' ? '3. Play Store लिस्टिंग और ASO (कीवर्ड्स और प्राइवेसी)' : '3. Play Store Listing & ASO Copy'}</span>
                </h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Play Store सर्च एल्गोरिदम (ASO) और भारतीय खरीदारों के लिए पूर्ण अनुकूलित टेक्स्ट।
                </p>
              </div>

              <button
                onClick={() => toggleStepComplete('listing')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  completedSteps.listing
                    ? 'bg-emerald-600 text-white'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>{completedSteps.listing ? 'पूर्ण मार्क किया गया (Done)' : 'कदम पूर्ण मार्क करें'}</span>
              </button>
            </div>

            {/* Title & Short Description */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">App Title (Max 30 chars):</span>
                  <button
                    onClick={() => copyToClipboard(playStoreTitleHi, 'title')}
                    className="text-[11px] text-pink-400 hover:text-pink-300 flex items-center gap-1 font-semibold"
                  >
                    {copiedKey === 'title' ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <input
                  readOnly
                  value={playStoreTitleHi}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-bold text-white"
                />
              </div>

              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Short Description (Max 80 chars):</span>
                  <button
                    onClick={() => copyToClipboard(playStoreShortDescHi, 'shortDesc')}
                    className="text-[11px] text-pink-400 hover:text-pink-300 flex items-center gap-1 font-semibold"
                  >
                    {copiedKey === 'shortDesc' ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <input
                  readOnly
                  value={playStoreShortDescHi}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-medium text-emerald-400"
                />
              </div>
            </div>

            {/* Full 4000-char Description */}
            <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">
                  {lang === 'hi' ? 'पूर्ण विवरण (Full Description with ASO Keywords):' : 'Full Description (ASO Optimized):'}
                </span>
                <button
                  onClick={() => copyToClipboard(playStoreFullDesc, 'fullDesc')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedKey === 'fullDesc' ? 'Copied Full Text!' : 'Copy Full Description'}</span>
                </button>
              </div>
              <textarea
                readOnly
                rows={8}
                value={playStoreFullDesc}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-3 font-sans text-xs text-neutral-300 focus:outline-none leading-relaxed"
              />
            </div>

            {/* Legal Privacy Policy */}
            <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white">
                    {lang === 'hi' ? 'गोपनीयता नीति (Privacy Policy - IT Act 2000 Compliant)' : 'Google Play Compliant Privacy Policy'}
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard(privacyPolicyText, 'privacy')}
                  className="text-xs text-pink-400 hover:text-pink-300 font-semibold flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedKey === 'privacy' ? 'Copied!' : 'Copy Policy'}</span>
                </button>
              </div>
              <textarea
                readOnly
                rows={5}
                value={privacyPolicyText}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-3 font-mono text-[11px] text-neutral-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {/* STEP 4: SCREENSHOTS STUDIO */}
        {activeStep === 'screenshots' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-amber-400" />
                  <span>{lang === 'hi' ? '4. Play Store स्क्रीनशॉट्स स्टूडियो (1080x1920)' : '4. Play Store Screenshot Studio (1080x1920)'}</span>
                </h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Play Store पर ऐप डाउनलोड दर (Conversion Rate) बढ़ाने के लिए 5 आधिकारिक मार्केटिंग फ्रेम्स।
                </p>
              </div>

              <button
                onClick={() => toggleStepComplete('screenshots')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  completedSteps.screenshots
                    ? 'bg-emerald-600 text-white'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>{completedSteps.screenshots ? 'पूर्ण मार्क किया गया (Done)' : 'कदम पूर्ण मार्क करें'}</span>
              </button>
            </div>

            {/* Slides Selector Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
              {screenshotSlides.map((slide, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveScreenshotSlide(idx)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                    activeScreenshotSlide === idx
                      ? 'bg-pink-600 text-white shadow-md'
                      : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  Frame {idx + 1}: {slide.badge}
                </button>
              ))}
            </div>

            {/* Screenshot Frame Mockup Display */}
            <div className="flex flex-col md:flex-row items-center justify-center gap-8 p-6 bg-neutral-950 rounded-3xl border border-neutral-800">
              {/* Phone Device Bezel */}
              <div className="relative w-[280px] h-[540px] rounded-[40px] bg-neutral-900 border-4 border-neutral-700 shadow-2xl overflow-hidden flex flex-col p-2.5">
                {/* Notch */}
                <div className="w-20 h-4 bg-neutral-800 rounded-full mx-auto mb-2" />

                {/* Poster Content */}
                <div className="relative flex-1 rounded-[28px] overflow-hidden bg-black flex flex-col justify-between p-4">
                  <img
                    src={screenshotSlides[activeScreenshotSlide].image}
                    alt="screenshot"
                    className="absolute inset-0 w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/80" />

                  {/* Top Marketing Callout */}
                  <div className="relative z-10 text-center pt-2">
                    <span className="text-[10px] font-black uppercase tracking-wider bg-pink-600 text-white px-2.5 py-0.5 rounded-full shadow-md">
                      {screenshotSlides[activeScreenshotSlide].badge}
                    </span>
                    <h3 className="text-base font-black text-white mt-1.5 leading-snug drop-shadow-md">
                      {lang === 'hi' ? screenshotSlides[activeScreenshotSlide].titleHi : screenshotSlides[activeScreenshotSlide].titleEn}
                    </h3>
                    <p className="text-[10px] text-neutral-300 mt-0.5">
                      {screenshotSlides[activeScreenshotSlide].subtitle}
                    </p>
                  </div>

                  {/* Bottom App Badge */}
                  <div className="relative z-10 p-2 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 text-center">
                    <span className="text-[11px] font-bold text-white">Reel Bajar · रील बाज़ार</span>
                  </div>
                </div>
              </div>

              {/* Instructions and Details */}
              <div className="max-w-md space-y-4 text-xs">
                <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                  <h4 className="font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-pink-400" />
                    <span>Play Store Image Specifications:</span>
                  </h4>
                  <ul className="text-neutral-300 space-y-1.5 list-disc pl-4 text-[11px]">
                    <li>Minimum 4 screenshots required (Max 8)</li>
                    <li>Resolution: 1080 x 1920 (9:16 portrait)</li>
                    <li>JPEG or 24-bit PNG (no alpha)</li>
                    <li>Keep marketing headline text in top 25% for instant readability</li>
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-800/40 text-emerald-300 text-[11px]">
                  💡 <strong>ASO Tip:</strong> Screenshot 1 should highlight video commerce ("रील्स देखो, सीधे खरीदो"), Screenshot 2 should show COD ("कैश ऑन डिलीवरी"), which drives 60%+ conversions in India!
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: PLAY CONSOLE PUBLISHING & 14-DAY TESTING */}
        {activeStep === 'publishing' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Rocket className="w-5 h-5 text-amber-400" />
                  <span>{lang === 'hi' ? '5. Google Play Console प्रकाशन और 14-दिन टेस्ट गाइड' : '5. Play Console Release & 14-Day Testing'}</span>
                </h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  2024 से Google Play का नया नियम: व्यक्तिगत डेवलपर्स के लिए कम से कम 12-20 टेस्टर्स के साथ 14 दिन की क्लोज्ड टेस्टिंग अनिवार्य है।
                </p>
              </div>

              <button
                onClick={() => toggleStepComplete('publishing')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  completedSteps.publishing
                    ? 'bg-emerald-600 text-white'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>{completedSteps.publishing ? 'पूर्ण मार्क किया गया (Done)' : 'कदम पूर्ण मार्क करें'}</span>
              </button>
            </div>

            {/* Checklist items */}
            <div className="space-y-3">
              {[
                { title: 'Google Play Console Developer Account ($25 एकमुश्त शुल्क)', desc: 'play.google.com/console पर जाकर डेवलपर खाता बनाएं और पहचान सत्यापन (PAN / Passport) पूरा करें।' },
                { title: '14-दिन क्लोज्ड टेस्टिंग (Closed Testing with 20 Testers)', desc: 'कम से कम 12 से 20 दोस्तों या सहकर्मियों की ईमेल आईडी जोड़ें और 14 लगातार दिनों तक ऐप को टेस्ट ट्रैक में चालू रखें।' },
                { title: 'Data Safety & Content Rating प्रश्नावली', desc: 'डेटा सुरक्षा में बताएं कि नाम, फोन और डिलीवरी पता ऑर्डर शिपिंग के लिए लिया जाता है। उम्र रेटिंग: 12+ (Shopping & Social)।' },
                { title: 'डिजिटल एसेट लिंक्स (Digital Asset Links - assetlinks.json)', desc: 'वेबसाइट के /.well-known/assetlinks.json में SHA-256 फिंगरप्रिंट डालें ताकि ब्राउज़र बार न दिखे और ऐप 100% नेटिव लगे।' },
                { title: 'प्रोडक्शन रिलीज (Production Track Rollout)', desc: '14 दिन पूरे होने के बाद "Apply for Production" बटन सक्रिय हो जाएगा। रिव्यू 24-48 घंटों में पास होकर ऐप Play Store पर लाइव हो जाएगा!' }
              ].map((item, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-start gap-3.5">
                  <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs font-black flex-shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{item.title}</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-r from-pink-950/40 via-purple-950/40 to-neutral-900 border border-pink-500/30 flex items-center justify-between gap-4">
              <div>
                <p className="text-xs font-bold text-white">Google Play Console पोर्टल खोलें:</p>
                <p className="text-[10px] text-neutral-400">आधिकारिक कंसोल पर नया ऐप क्रिएट करें और AAB अपलोड करें</p>
              </div>
              <a
                href="https://play.google.com/console"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs shadow-md transition-colors"
              >
                <span>Play Console</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
