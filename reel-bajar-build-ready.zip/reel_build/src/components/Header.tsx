import React from 'react';
import { ShoppingBag, Play, Rocket, Globe, Download, Sparkles, Bell, FolderArchive } from 'lucide-react';

interface HeaderProps {
  activeTab: 'reels' | 'bajar' | 'create' | 'launch';
  setActiveTab: (tab: 'reels' | 'bajar' | 'create' | 'launch') => void;
  lang: 'hi' | 'en';
  setLang: (lang: 'hi' | 'en') => void;
  cartCount: number;
  onOpenCart: () => void;
  unreadNotificationsCount: number;
  onOpenNotifications: () => void;
  onInstallPwa: () => void;
  canInstallPwa: boolean;
  onExportZip?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  cartCount,
  onOpenCart,
  unreadNotificationsCount,
  onOpenNotifications,
  onInstallPwa,
  canInstallPwa,
  onExportZip
}) => {
  return (
    <header className="sticky top-0 z-40 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800/80 px-4 py-2.5 transition-all">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Brand Logo & Title */}
        <div 
          onClick={() => setActiveTab('reels')}
          className="flex items-center gap-2.5 cursor-pointer select-none group"
        >
          <div className="relative w-9 h-9 rounded-xl bg-gradient-to-tr from-pink-600 via-purple-600 to-indigo-600 p-0.5 shadow-lg shadow-pink-500/20 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-tr from-pink-600/30 to-purple-600/30" />
              <Play className="w-4 h-4 text-pink-500 fill-pink-500 ml-0.5 relative z-10" />
              <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-white">
                Reel <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-amber-400">Bajar</span>
              </span>
              <span className="text-[10px] font-semibold text-pink-400 bg-pink-500/10 px-1.5 py-0.2 rounded border border-pink-500/20">
                {lang === 'hi' ? 'रील बाज़ार' : 'SHOP'}
              </span>
            </div>
            <p className="text-[10px] text-neutral-400 hidden sm:block">
              {lang === 'hi' ? 'रील्स देखो · सीधे खरीदो' : 'Watch Reels · Shop Direct'}
            </p>
          </div>
        </div>

        {/* Center Navigation Tabs */}
        <nav className="flex items-center gap-1 bg-neutral-900/90 p-1 rounded-xl border border-neutral-800 text-xs font-medium">
          <button
            onClick={() => setActiveTab('reels')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'reels'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{lang === 'hi' ? 'रील्स' : 'Reels'}</span>
          </button>

          <button
            onClick={() => setActiveTab('bajar')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'bajar'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'बाज़ार' : 'Bajar'}</span>
          </button>

          <button
            onClick={() => setActiveTab('create')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'create'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{lang === 'hi' ? 'क्रिएटर स्टूडियो' : 'Studio'}</span>
            <span className="sm:hidden">{lang === 'hi' ? 'बनाएं' : 'Post'}</span>
          </button>

          <button
            onClick={() => setActiveTab('launch')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all border ${
              activeTab === 'launch'
                ? 'bg-amber-500 text-neutral-950 font-bold border-amber-400 shadow-md shadow-amber-500/20'
                : 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20 hover:text-white'
            }`}
          >
            <Rocket className="w-3.5 h-3.5" />
            <span className="font-semibold">{lang === 'hi' ? 'Play Store लॉन्च' : 'Play Store'}</span>
          </button>
        </nav>

        {/* Right Actions: Lang + Notifications + Cart + Install PWA */}
        <div className="flex items-center gap-2">
          {/* Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700 transition-colors"
            title="Notifications / सूचनाएं"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-pink-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center animate-pulse">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Cart Icon */}
          <button
            onClick={onOpenCart}
            className="relative p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-200 hover:text-white hover:border-neutral-700 transition-colors"
            aria-label="View Cart"
          >
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-pink-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => setLang(lang === 'hi' ? 'en' : 'hi')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-medium text-neutral-300 hover:text-white hover:border-neutral-700 transition-colors"
            title="Switch Language / भाषा बदलें"
          >
            <Globe className="w-3.5 h-3.5 text-neutral-400" />
            <span>{lang === 'hi' ? 'EN' : 'हिं'}</span>
          </button>

          {/* Direct Android APK Download Button */}
          <a
            href="/ReelBajar.apk"
            download="ReelBajar.apk"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-xs font-bold text-emerald-400 hover:bg-emerald-500/25 hover:text-white transition-all shadow-sm"
            title="Download ReelBajar.apk for Android"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>{lang === 'hi' ? 'APK डाउनलोड' : 'Download APK'}</span>
          </a>

          {/* Export Project ZIP Button */}
          <a
            href="/reel-bajar-source-code.zip"
            download="reel-bajar-source-code.zip"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-300 hover:bg-amber-500/20 hover:text-white transition-colors"
            title="Download Full Project ZIP for Android APK/AAB"
          >
            <FolderArchive className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'hi' ? 'ZIP डाउनलोड' : 'Export ZIP'}</span>
          </a>

          {/* Install PWA Button */}
          <button
            onClick={onInstallPwa}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-medium text-emerald-400 hover:bg-emerald-950/40 hover:border-emerald-700/50 transition-colors"
            title="Install App on Device"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'ऐप इंस्टॉल' : 'Install'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
