import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, ShieldCheck } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onCheckout: (discountAmount: number) => void;
  onExploreBajar: () => void;
  lang: 'hi' | 'en';
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  onExploreBajar,
  lang
}) => {
  const [couponCode, setCouponCode] = useState<string>('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  if (!isOpen) return null;

  const rawTotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  let discountAmount = 0;
  if (appliedCoupon === 'BAJAR100') {
    discountAmount = Math.min(100, rawTotal);
  } else if (appliedCoupon === 'REEL20') {
    discountAmount = Math.round(rawTotal * 0.2);
  }

  const finalTotal = Math.max(0, rawTotal - discountAmount);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const code = couponCode.trim().toUpperCase();
    if (code === 'BAJAR100' || code === 'REEL20' || code === 'FREESHIP') {
      setAppliedCoupon(code);
      setCouponError(null);
    } else {
      setCouponError(lang === 'hi' ? 'अमान्य कूपन कोड। "BAJAR100" या "REEL20" आज़माएं' : 'Invalid code. Try "BAJAR100" or "REEL20"');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/75 backdrop-blur-xs animate-fadeIn">
      {/* Background click to dismiss */}
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-neutral-900 border-l border-neutral-800 h-full shadow-2xl flex flex-col z-10 overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-pink-500" />
            <h3 className="font-bold text-sm text-white">
              {lang === 'hi' ? 'शॉपिंग कार्ट (Shopping Bag)' : 'Shopping Cart'}
            </h3>
            <span className="text-xs bg-neutral-800 text-neutral-300 px-2 py-0.5 rounded-full font-bold">
              {cartItems.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {cartItems.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-neutral-500">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">
                {lang === 'hi' ? 'आपकी कार्ट अभी खाली है' : 'Your cart is empty'}
              </h4>
              <p className="text-xs text-neutral-400 mt-1 max-w-xs">
                {lang === 'hi'
                  ? 'रील्स देखें और अपने पसंदीदा उत्पादों को सीधे अपनी कार्ट में जोड़ें!'
                  : 'Watch video reels and add products to your cart with 1 click!'}
              </p>
            </div>
            <button
              onClick={() => {
                onClose();
                onExploreBajar();
              }}
              className="py-2.5 px-5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs shadow-md transition-colors"
            >
              {lang === 'hi' ? 'बाज़ार एक्सप्लोर करें' : 'Explore Bajar'}
            </button>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
            {/* Cart Items List */}
            <div className="space-y-3">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80 flex items-center gap-3 relative group"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.title}
                    className="w-16 h-16 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">{item.product.title}</p>
                    <p className="text-[10px] text-neutral-400 mt-0.5">Size: {item.size} · {item.product.sellerCity}</p>
                    <div className="flex items-baseline gap-2 mt-1">
                      <span className="text-xs font-extrabold text-pink-400">₹{item.product.price}</span>
                      <span className="text-[10px] text-neutral-500 line-through">₹{item.product.originalPrice}</span>
                    </div>
                  </div>

                  {/* Quantity Actions */}
                  <div className="flex flex-col items-end justify-between h-16">
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-neutral-500 hover:text-rose-400 p-1 transition-colors"
                      title="Remove"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 rounded-lg p-0.5">
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        className="p-1 rounded text-neutral-400 hover:text-white"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold text-white px-1">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="p-1 rounded text-neutral-400 hover:text-white"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Coupon Code Section */}
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-pink-400" />
                  <span>{lang === 'hi' ? 'डिस्काउंट कूपन' : 'Have a Promo Code?'}</span>
                </span>
                <span className="text-[10px] text-pink-400 font-semibold">Try: BAJAR100</span>
              </div>

              <form onSubmit={handleApplyCoupon} className="flex items-center gap-2">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  placeholder="e.g. BAJAR100 or REEL20"
                  className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs uppercase text-white font-mono placeholder-neutral-500 focus:outline-none focus:border-pink-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-bold transition-colors"
                >
                  {lang === 'hi' ? 'लागू करें' : 'Apply'}
                </button>
              </form>

              {appliedCoupon && (
                <p className="text-[11px] text-emerald-400 font-semibold">
                  ✓ कूपन '{appliedCoupon}' सफलतापूर्वक लागू हुआ!
                </p>
              )}
              {couponError && (
                <p className="text-[11px] text-rose-400 font-medium">
                  {couponError}
                </p>
              )}
            </div>

            {/* Bill Summary */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2 text-xs">
              <div className="flex justify-between text-neutral-400">
                <span>{lang === 'hi' ? 'सामान का मूल्य' : 'Subtotal'}</span>
                <span>₹{rawTotal}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-400 font-semibold">
                  <span>{lang === 'hi' ? 'कूपन छूट' : 'Discount'}</span>
                  <span>-₹{discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between text-neutral-400">
                <span>{lang === 'hi' ? 'डिलीवरी शुल्क' : 'Delivery'}</span>
                <span className="text-emerald-400 font-bold">{lang === 'hi' ? 'मुफ्त (FREE)' : 'FREE'}</span>
              </div>
              <div className="pt-2 border-t border-neutral-800 flex justify-between font-extrabold text-white text-sm">
                <span>{lang === 'hi' ? 'कुल देय राशि' : 'Total Amount'}</span>
                <span className="text-pink-400">₹{finalTotal}</span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-[10px] text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'hi' ? 'कैश ऑन डिलीवरी (COD) उपलब्ध · 7 दिन वापसी' : 'Cash on Delivery Available · 7-Day Returns'}</span>
            </div>
          </div>
        )}

        {/* Footer Checkout Button */}
        {cartItems.length > 0 && (
          <div className="p-4 bg-neutral-950 border-t border-neutral-800">
            <button
              onClick={() => onCheckout(discountAmount)}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 text-white font-extrabold text-sm shadow-lg shadow-pink-600/30 hover:opacity-95 transition-opacity flex items-center justify-center gap-2"
            >
              <span>{lang === 'hi' ? `चेकआउट करें (₹${finalTotal})` : `Proceed to Checkout (₹${finalTotal})`}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
