import React, { useState } from 'react';
import { X, Star, ShieldCheck, Truck, RotateCcw, ShoppingBag, Play, Plus, Minus, MessageSquare } from 'lucide-react';
import { ProductItem } from '../types';

interface ProductDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: ProductItem | null;
  onAddToCart: (product: ProductItem, size: string, quantity: number) => void;
  onBuyNow: (product: ProductItem) => void;
  onWatchReel?: () => void;
  onOpenChat?: () => void;
  lang: 'hi' | 'en';
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  isOpen,
  onClose,
  product,
  onAddToCart,
  onBuyNow,
  onWatchReel,
  onOpenChat,
  lang
}) => {
  const [selectedSize, setSelectedSize] = useState<string>('Free Size');
  const [quantity, setQuantity] = useState<number>(1);
  const [addedToast, setAddedToast] = useState<boolean>(false);

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    onAddToCart(product, selectedSize, quantity);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              {product.category}
            </span>
            <span className="text-neutral-500">·</span>
            <span className="text-xs text-neutral-400">{product.sellerCity}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 no-scrollbar">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Image & Reel Play CTA */}
            <div className="space-y-3">
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-black border border-neutral-800 group shadow-lg">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 left-3 bg-pink-600 text-white font-extrabold text-[11px] px-2.5 py-0.5 rounded-lg shadow-md">
                  {product.discountPercent}% OFF
                </div>

                {onWatchReel && (
                  <button
                    onClick={() => {
                      onClose();
                      onWatchReel();
                    }}
                    className="absolute bottom-3 left-3 right-3 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-black/80 backdrop-blur-md text-white border border-white/20 hover:bg-pink-600 font-bold text-xs shadow-xl transition-colors"
                  >
                    <Play className="w-4 h-4 fill-current text-pink-400" />
                    <span>{lang === 'hi' ? 'सामान का असली वीडियो देखें' : 'Watch Live Video Demo'}</span>
                  </button>
                )}
              </div>

              {/* Verified Seller Tag Card */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs">
                <div>
                  <p className="text-[10px] text-neutral-400">{lang === 'hi' ? 'अधिकृत निर्माता / सेलर' : 'Verified Artisan / Seller'}</p>
                  <p className="font-bold text-white flex items-center gap-1 mt-0.5">
                    {product.sellerName}
                    {product.isVerifiedSeller && (
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    )}
                  </p>
                </div>
                {onOpenChat && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenChat();
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-pink-400 border border-pink-500/30 text-xs font-semibold transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'चैट करें' : 'Chat'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Info & Options */}
            <div className="space-y-4">
              <div>
                <h1 className="text-base sm:text-lg font-bold text-white leading-snug">
                  {product.title}
                </h1>
                
                {/* Rating */}
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-lg text-amber-400 text-xs font-bold">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span>{product.rating}</span>
                  </div>
                  <span className="text-xs text-neutral-400">
                    {product.reviewsCount} {lang === 'hi' ? 'समीक्षाएं (प्रमाणित खरीद)' : 'verified reviews'}
                  </span>
                </div>
              </div>

              {/* Price Banner */}
              <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80">
                <div className="flex items-baseline gap-2.5">
                  <span className="text-2xl font-black text-pink-400">₹{product.price}</span>
                  <span className="text-sm text-neutral-500 line-through">₹{product.originalPrice}</span>
                  <span className="text-xs text-emerald-400 font-bold">
                    बचत: ₹{product.originalPrice - product.price}
                  </span>
                </div>
                <p className="text-[10px] text-neutral-400 mt-1">
                  {lang === 'hi' ? 'सभी टैक्स शामिल हैं · कोई अतिरिक्त शुल्क नहीं' : 'Inclusive of all taxes · Free shipping'}
                </p>
              </div>

              {/* Size Selector */}
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  {lang === 'hi' ? 'साइज / वैरिएंट चुनें:' : 'Select Size:'}
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Free Size', 'S', 'M', 'L', 'XL'].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSelectedSize(s)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                        selectedSize === s
                          ? 'bg-pink-600 text-white border-pink-500 shadow-md'
                          : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-white'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity Selector */}
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  {lang === 'hi' ? 'मात्रा (Quantity):' : 'Quantity:'}
                </label>
                <div className="inline-flex items-center gap-3 bg-neutral-950 border border-neutral-800 rounded-xl p-1">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-xs font-bold text-white px-2">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Guarantees */}
              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                <div className="p-2 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center gap-2 text-neutral-300">
                  <Truck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>{lang === 'hi' ? 'मुफ्त होम डिलीवरी (COD)' : 'Free COD Delivery'}</span>
                </div>
                <div className="p-2 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center gap-2 text-neutral-300">
                  <RotateCcw className="w-4 h-4 text-pink-400 flex-shrink-0" />
                  <span>{lang === 'hi' ? '7 दिन आसान वापसी' : '7 Days Easy Returns'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Description & Bullet Specs */}
          <div className="space-y-2 pt-2 border-t border-neutral-800">
            <h3 className="text-xs font-bold text-white">
              {lang === 'hi' ? 'उत्पाद विवरण (Description & Specifications):' : 'Description & Specifications:'}
            </h3>
            <p className="text-xs text-neutral-300 leading-relaxed">
              {product.description}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs">
              {product.features.map((feat, idx) => (
                <div key={idx} className="flex items-center gap-2 text-neutral-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-500" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-neutral-950 border-t border-neutral-800 flex items-center gap-3">
          <button
            onClick={handleAddToCart}
            className="flex-1 py-3 px-4 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-neutral-700 transition-colors"
          >
            <ShoppingBag className="w-4 h-4 text-pink-400" />
            <span>{addedToast ? (lang === 'hi' ? '✓ कार्ट में जुड़ा!' : '✓ Added to Cart!') : (lang === 'hi' ? 'कार्ट में जोड़ें' : 'Add to Cart')}</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onBuyNow(product);
            }}
            className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 text-white font-extrabold text-xs shadow-lg shadow-pink-600/30 hover:opacity-95 transition-all flex items-center justify-center gap-1.5"
          >
            <span>{lang === 'hi' ? `अभी खरीदें (₹${product.price * quantity})` : `Buy Now (₹${product.price * quantity})`}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
