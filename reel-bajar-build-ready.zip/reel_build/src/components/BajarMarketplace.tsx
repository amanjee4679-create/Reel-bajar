import React, { useState } from 'react';
import { Search, ShoppingBag, Play, Star, ShieldCheck, Sparkles, SlidersHorizontal, Eye } from 'lucide-react';
import { ProductItem, ReelItem } from '../types';

interface BajarMarketplaceProps {
  reels: ReelItem[];
  onSelectReelByProduct: (reelId: string) => void;
  onOpenBuyModal: (product: ProductItem) => void;
  onOpenProductDetail: (product: ProductItem) => void;
  onAddToCart: (product: ProductItem) => void;
  lang: 'hi' | 'en';
}

export const BajarMarketplace: React.FC<BajarMarketplaceProps> = ({
  reels,
  onSelectReelByProduct,
  onOpenBuyModal,
  onOpenProductDetail,
  onAddToCart,
  lang
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price_low' | 'price_high' | 'rating'>('featured');
  const [verifiedOnly, setVerifiedOnly] = useState<boolean>(false);

  const categories = [
    { id: 'All', nameHi: 'सभी बाज़ार', nameEn: 'All Items' },
    { id: 'Fashion', nameHi: '🥻 फैशन व साड़ियां', nameEn: 'Fashion & Sarees' },
    { id: 'Electronics', nameHi: '🎧 इलेक्ट्रॉनिक्स', nameEn: 'Electronics' },
    { id: 'Home & Kitchen', nameHi: '🏠 होम & किचन', nameEn: 'Home & Kitchen' },
    { id: 'Beauty', nameHi: '🌸 ब्यूटी & स्किनकेयर', nameEn: 'Beauty & Skin' },
    { id: 'Accessories', nameHi: '💼 लेदर & एक्सेसरीज', nameEn: 'Accessories' },
  ];

  // Extract products from reels
  const allProducts = reels.map(r => ({
    ...r.product,
    reelId: r.id,
    creatorName: r.creator.name
  }));

  const filteredProducts = allProducts.filter(item => {
    const matchCat = selectedCategory === 'All' || item.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchQuery = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                       item.sellerCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
                       item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                       item.sellerName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchVerified = !verifiedOnly || item.isVerifiedSeller;
    return matchCat && matchQuery && matchVerified;
  }).sort((a, b) => {
    if (sortBy === 'price_low') return a.price - b.price;
    if (sortBy === 'price_high') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0; // featured default
  });

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 space-y-6">
      {/* Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-pink-950/60 via-purple-950/50 to-neutral-900 border border-pink-500/20 p-6 sm:p-8 overflow-hidden shadow-2xl">
        <div className="absolute right-0 top-0 w-80 h-80 bg-pink-500/10 blur-3xl rounded-full pointer-events-none" />
        <div className="relative z-10 max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs font-bold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
            <span>{lang === 'hi' ? 'सीधा बुनकरों और निर्माताओं से' : 'Direct from Makers & Weavers'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
            {lang === 'hi' ? 'रील बाज़ार: वीडियो देखें, परखें और सीधे खरीदें' : 'Reel Bajar: Watch Product Video & Shop Direct'}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300 mt-2 leading-relaxed">
            {lang === 'hi'
              ? 'बिना बिचौलियों के वास्तविक उत्पाद। हर सामान का असली वीडियो देखें, कैश ऑन डिलीवरी पाएं और 7 दिनों की आसान वापसी का आनंद लें।'
              : 'Zero middlemen, verified makers. Watch unedited reel demos, enjoy Cash on Delivery and easy 7-day returns.'}
          </p>
        </div>
      </div>

      {/* Search & Categories Bar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                lang === 'hi'
                  ? 'सामान, शहर, सेलर या श्रेणी खोजें (जैसे: बनारसी साड़ी, ईयरबड्स, कुर्ती)...'
                  : 'Search products, city, seller or category (e.g. Saree, Earbuds, Juicer)...'
              }
              className="w-full bg-neutral-900 border border-neutral-800 rounded-2xl pl-11 pr-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500 transition-colors shadow-inner"
            />
          </div>

          {/* Sort & Filter Controls */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-neutral-900 border border-neutral-800 text-xs text-neutral-200 rounded-2xl px-3 py-3 focus:outline-none focus:border-pink-500"
            >
              <option value="featured">{lang === 'hi' ? 'लोकप्रिय (Featured)' : 'Featured'}</option>
              <option value="price_low">{lang === 'hi' ? 'कीमत: कम से ज्यादा' : 'Price: Low to High'}</option>
              <option value="price_high">{lang === 'hi' ? 'कीमत: ज्यादा से कम' : 'Price: High to Low'}</option>
              <option value="rating">{lang === 'hi' ? 'उच्च रेटिंग (Top Rated)' : 'Top Rated'}</option>
            </select>

            <button
              onClick={() => setVerifiedOnly(!verifiedOnly)}
              className={`flex items-center gap-1.5 px-3 py-3 rounded-2xl text-xs font-bold border transition-colors ${
                verifiedOnly
                  ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
              }`}
              title="Verified sellers only"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'hi' ? 'वेरिफाइड' : 'Verified'}</span>
            </button>
          </div>
        </div>

        {/* Category Horizontal Filter */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-white text-neutral-950 shadow-md font-bold'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800 hover:bg-neutral-800/80'
              }`}
            >
              {lang === 'hi' ? cat.nameHi : cat.nameEn}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-16 bg-neutral-900/40 rounded-3xl border border-neutral-800">
          <SlidersHorizontal className="w-10 h-10 text-neutral-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-neutral-300">
            {lang === 'hi' ? 'कोई प्रोडक्ट नहीं मिला' : 'No products found'}
          </p>
          <p className="text-xs text-neutral-500 mt-1">
            {lang === 'hi' ? 'खोज शब्द बदलकर या श्रेणी रीसेट करके दोबारा देखें।' : 'Try different keywords or reset category filters.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredProducts.map((prod) => (
            <div
              key={prod.id}
              className="group rounded-2xl bg-neutral-900 border border-neutral-800/90 overflow-hidden flex flex-col hover:border-pink-500/40 hover:shadow-xl transition-all"
            >
              {/* Image & Video Reel Action */}
              <div 
                className="relative aspect-[4/3] bg-neutral-950 overflow-hidden cursor-pointer"
                onClick={() => onOpenProductDetail(prod)}
              >
                <img
                  src={prod.image}
                  alt={prod.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />

                {/* Discount Tag */}
                <div className="absolute top-2.5 left-2.5 bg-pink-600 text-white text-[10px] font-black px-2 py-0.5 rounded-lg shadow-md">
                  {prod.discountPercent}% OFF
                </div>

                {/* Watch Reel Floating CTA Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectReelByProduct(prod.reelId);
                  }}
                  className="absolute bottom-2.5 right-2.5 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/75 backdrop-blur-md border border-white/20 text-white hover:bg-pink-600 text-[11px] font-bold shadow-lg transition-colors group/reelBtn"
                >
                  <Play className="w-3 h-3 fill-current text-pink-400 group-hover/reelBtn:text-white" />
                  <span>{lang === 'hi' ? 'रील देखें' : 'Watch Reel'}</span>
                </button>
              </div>

              {/* Content */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div 
                  className="cursor-pointer"
                  onClick={() => onOpenProductDetail(prod)}
                >
                  {/* Seller & City (Zero-Pill clean metadata) */}
                  <div className="flex items-center gap-1.5 text-[11px] text-neutral-400 mb-1">
                    <span>{prod.sellerCity}</span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1 text-neutral-300 truncate">
                      {prod.sellerName}
                      {prod.isVerifiedSeller && (
                        <ShieldCheck className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                      )}
                    </span>
                  </div>

                  <h3 className="text-xs font-bold text-white line-clamp-2 leading-snug group-hover:text-pink-300 transition-colors">
                    {prod.title}
                  </h3>

                  {/* Rating */}
                  <div className="flex items-center gap-1.5 text-[11px] text-amber-400 mt-1.5">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span className="font-bold text-white">{prod.rating}</span>
                    <span className="text-neutral-500">({prod.reviewsCount})</span>
                  </div>
                </div>

                {/* Price & Actions */}
                <div className="pt-2 border-t border-neutral-800/80">
                  <div className="flex items-baseline gap-2 mb-2.5">
                    <span className="text-base font-black text-white">₹{prod.price}</span>
                    <span className="text-xs text-neutral-500 line-through">₹{prod.originalPrice}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onAddToCart(prod)}
                      className="py-2 px-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold flex items-center justify-center gap-1 transition-colors"
                    >
                      <ShoppingBag className="w-3 h-3 text-pink-400" />
                      <span>{lang === 'hi' ? '+ कार्ट' : '+ Cart'}</span>
                    </button>

                    <button
                      onClick={() => onOpenBuyModal(prod)}
                      className="py-2 px-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 text-white text-xs font-bold flex items-center justify-center gap-1 hover:opacity-95 shadow-md shadow-pink-600/20 transition-opacity"
                    >
                      <span>{lang === 'hi' ? 'खरीदें' : 'Buy Now'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
