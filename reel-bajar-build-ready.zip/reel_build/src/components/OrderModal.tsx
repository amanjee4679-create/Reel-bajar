import React, { useState } from 'react';
import { X, ShieldCheck, Truck, CheckCircle2, MessageCircle, CreditCard, Banknote } from 'lucide-react';
import confetti from 'canvas-confetti';
import { ProductItem, UserProfile } from '../types';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: ProductItem | null;
  currentUser: UserProfile | null;
  onRequireAuth: () => void;
  lang: 'hi' | 'en';
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  product,
  currentUser,
  onRequireAuth,
  lang
}) => {
  const [name, setName] = useState(currentUser?.name || 'Aman Kumar');
  const [phone, setPhone] = useState(currentUser?.phone?.replace('+91 ', '') || '9876543210');
  const [address, setAddress] = useState('Flat 402, Shanti Vihar, Station Road');
  const [city, setCity] = useState('Varanasi');
  const [pincode, setPincode] = useState('221001');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'upi' | 'card'>('cod');
  const [selectedSize, setSelectedSize] = useState('Free Size');
  const [isPlaced, setIsPlaced] = useState(false);
  const [orderId, setOrderId] = useState('');

  if (!isOpen || !product) return null;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onRequireAuth();
      return;
    }
    const generatedId = 'RB-' + Math.floor(100000 + Math.random() * 900000);
    setOrderId(generatedId);
    setIsPlaced(true);

    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch {
      // safe fallback
    }
  };

  const handleWhatsAppOrder = () => {
    const message = encodeURIComponent(
      `नमस्ते! मुझे Reel Bajar पर यह प्रोडक्ट ऑर्डर करना है:\n\n` +
      `📦 प्रोडक्ट: ${product.title}\n` +
      `💰 कीमत: ₹${product.price} (MRP: ₹${product.originalPrice})\n` +
      `📏 साइज: ${selectedSize}\n` +
      `👤 नाम: ${name}\n` +
      `📍 पता: ${address}, ${city} - ${pincode}\n` +
      `💳 भुगतान: ${paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : 'Online UPI'}`
    );
    window.open(`https://wa.me/919876543210?text=${message}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h3 className="font-bold text-sm text-white">
              {lang === 'hi' ? '1-क्लिक सुरक्षित ऑर्डर (Checkout)' : 'Express Secure Checkout'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!isPlaced ? (
          <form onSubmit={handlePlaceOrder} className="flex-1 overflow-y-auto p-5 space-y-4 no-scrollbar">
            {/* Product Summary Card */}
            <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center gap-3.5">
              <img
                src={product.image}
                alt={product.title}
                className="w-16 h-16 rounded-xl object-cover border border-neutral-700 flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-white truncate">{product.title}</p>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-base font-black text-pink-500">₹{product.price}</span>
                  <span className="text-xs text-neutral-500 line-through">₹{product.originalPrice}</span>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-800/40">
                    {product.discountPercent}% OFF
                  </span>
                </div>
                <p className="text-[10px] text-neutral-400 mt-1 flex items-center gap-1">
                  <Truck className="w-3 h-3 text-emerald-400" />
                  <span>{lang === 'hi' ? 'मुफ्त होम डिलीवरी (3-4 दिन)' : 'Free Shipping across India'}</span>
                </p>
              </div>
            </div>

            {/* Size / Variant Picker */}
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                {lang === 'hi' ? 'साइज / वैरिएंट चुनें:' : 'Select Size / Variant:'}
              </label>
              <div className="flex items-center gap-2">
                {['Free Size', 'S', 'M', 'L', 'XL'].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSelectedSize(s)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                      selectedSize === s
                        ? 'bg-pink-600 text-white border-pink-500 shadow-sm'
                        : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-white'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Delivery Address Form */}
            <div className="space-y-3 pt-2">
              <p className="text-xs font-bold text-neutral-200">
                {lang === 'hi' ? 'डिलीवरी का पता (Shipping Address):' : 'Shipping Address:'}
              </p>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'नाम' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'मोबाइल नंबर' : 'Phone'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-neutral-400 mb-1">
                  {lang === 'hi' ? 'घर का पता / सड़क' : 'Address / House No'}
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'शहर (City)' : 'City'}
                  </label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">
                    {lang === 'hi' ? 'पिनकोड (Pincode)' : 'Pincode'}
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                  />
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-neutral-200 mb-2">
                {lang === 'hi' ? 'भुगतान का तरीका (Payment Method):' : 'Payment Mode:'}
              </label>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cod')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'cod'
                      ? 'bg-pink-950/40 border-pink-500 text-white'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                  }`}
                >
                  <Banknote className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-[11px]">Cash on Delivery</span>
                  <span className="text-[9px] text-emerald-400 font-semibold">{lang === 'hi' ? 'घर पर पैसे दें' : 'Pay at doorstep'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'upi'
                      ? 'bg-pink-950/40 border-pink-500 text-white'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                  }`}
                >
                  <span className="font-black text-xs text-amber-400">UPI</span>
                  <span className="font-bold text-[11px]">GPay / PhonePe</span>
                  <span className="text-[9px] text-neutral-400">{lang === 'hi' ? 'इंस्टेंट डिस्काउंट' : 'Fast Checkout'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'card'
                      ? 'bg-pink-950/40 border-pink-500 text-white'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-indigo-400" />
                  <span className="font-bold text-[11px]">Card / Netbanking</span>
                  <span className="text-[9px] text-neutral-400">{lang === 'hi' ? 'सभी बैंक' : 'All Banks'}</span>
                </button>
              </div>
            </div>

            {/* Buttons */}
            <div className="space-y-2 pt-2">
              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 text-white font-extrabold text-sm shadow-lg shadow-pink-600/30 hover:opacity-95 transition-opacity"
              >
                {lang === 'hi'
                  ? `ऑर्डर कन्फर्म करें (₹${product.price})`
                  : `Confirm Order (₹${product.price})`}
              </button>

              <button
                type="button"
                onClick={handleWhatsAppOrder}
                className="w-full py-2.5 px-4 rounded-2xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{lang === 'hi' ? 'WhatsApp पर सीधा ऑर्डर भेजें' : 'Send Order directly on WhatsApp'}</span>
              </button>
            </div>

            <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-500">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
              <span>{lang === 'hi' ? '7 दिन की आसान वापसी और 100% असली सामान' : '7 Days Easy Return & 100% Genuine Guarantee'}</span>
            </div>
          </form>
        ) : (
          /* Order Confirmed Screen */
          <div className="p-8 text-center space-y-4 my-auto">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-xl">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <span className="text-[11px] font-bold text-pink-500 uppercase tracking-wider">
                {lang === 'hi' ? 'ऑर्डर सफल हुआ!' : 'Order Placed!'}
              </span>
              <h2 className="text-xl font-black text-white mt-1">
                {lang === 'hi' ? 'बधाई! आपका ऑर्डर बुक हो गया है' : 'Congratulations! Your Order is Confirmed'}
              </h2>
              <p className="text-xs text-neutral-400 mt-1">
                {lang === 'hi'
                  ? `ट्रैकिंग आईडी: ${orderId} · 3-4 दिनों में डिलीवरी`
                  : `Tracking ID: ${orderId} · Delivery in 3-4 days`}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 text-left text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-neutral-400">आइटम:</span>
                <span className="text-white font-semibold">{product.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">कुल देय राशि:</span>
                <span className="text-emerald-400 font-bold">₹{product.price} ({paymentMethod === 'cod' ? 'COD' : 'Paid'})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">डिलीवरी का पता:</span>
                <span className="text-neutral-200">{address}, {city}</span>
              </div>
            </div>

            <button
              onClick={() => {
                setIsPlaced(false);
                onClose();
              }}
              className="w-full py-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs transition-colors"
            >
              {lang === 'hi' ? 'और रील्स देखें (Continue Shopping)' : 'Continue Shopping'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
