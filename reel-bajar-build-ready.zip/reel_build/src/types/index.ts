export interface ProductItem {
  id: string;
  title: string;
  price: number;
  originalPrice: number;
  discountPercent: number;
  rating: number;
  reviewsCount: number;
  image: string;
  sellerName: string;
  sellerCity: string;
  isVerifiedSeller: boolean;
  category: string;
  description: string;
  inStock: boolean;
  commissionRate: number; // e.g. 10%
  features: string[];
}

export interface CommentItem {
  id: string;
  author: string;
  avatar: string;
  text: string;
  timeAgo: string;
  likes: number;
  isLiked?: boolean;
}

export interface ReelItem {
  id: string;
  videoUrl: string;
  posterUrl: string;
  creator: {
    id?: string;
    name: string;
    handle: string;
    avatar: string;
    isVerified: boolean;
    followers: string;
    bio?: string;
  };
  caption: string;
  tags: string[];
  musicTrack: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  isLiked?: boolean;
  isSaved?: boolean;
  product: ProductItem;
  comments: CommentItem[];
}

export interface CartItem {
  id: string;
  product: ProductItem;
  quantity: number;
  size: string;
}

export interface NotificationItem {
  id: string;
  type: 'order' | 'commission' | 'chat' | 'follower' | 'deal';
  title: string;
  body: string;
  timestamp: string;
  isRead: boolean;
  linkTab?: 'reels' | 'bajar' | 'create' | 'launch';
}

export interface UserProfile {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  bio: string;
  followersCount: number;
  followingCount: number;
  isSeller: boolean;
  walletBalance: number;
  phone?: string;
  email?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  isSender: boolean;
  status?: 'sent' | 'delivered' | 'read';
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  productAttachment?: {
    id?: string;
    title: string;
    price: number;
    originalPrice?: number;
    image: string;
    category?: string;
  };
}

export interface ChatConversation {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar: string;
  participantHandle: string;
  participantCity?: string;
  isVerified: boolean;
  isOnline: boolean;
  lastSeen?: string;
  lastMessage: string;
  lastTimestamp: string;
  unreadCount: number;
  isBlocked?: boolean;
  messages: ChatMessage[];
}

export interface LaunchStep {
  id: string;
  stepNumber: number;
  titleHi: string;
  titleEn: string;
  taglineHi: string;
  taglineEn: string;
  category: 'branding' | 'build' | 'listing' | 'screenshots' | 'publishing';
  isCompleted: boolean;
}
