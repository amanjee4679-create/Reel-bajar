import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ReelPlayer } from './components/ReelPlayer';
import { BajarMarketplace } from './components/BajarMarketplace';
import { CommentsDrawer } from './components/CommentsDrawer';
import { ChatModal } from './components/ChatModal';
import { VideoUploadModal } from './components/VideoUploadModal';
import { ProfileView } from './components/ProfileView';
import { OrderModal } from './components/OrderModal';
import { AuthModal } from './components/AuthModal';
import { PlayStoreLaunchHub } from './components/PlayStoreLaunchHub';
import { CartDrawer } from './components/CartDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CreatorProfileModal } from './components/CreatorProfileModal';
import { ReportModal } from './components/ReportModal';
import { NotificationsModal } from './components/NotificationsModal';
import { INITIAL_REELS } from './data/mockData';
import { ReelItem, ProductItem, UserProfile, CartItem, NotificationItem } from './types';
import { Film, ShoppingBag, PlusCircle, MessageSquare, User as UserIcon } from 'lucide-react';

import { exportProjectZip } from './utils/zipExporter';

export default function App() {
  const [activeTab, setActiveTab] = useState<'reels' | 'bajar' | 'create' | 'launch'>('reels');
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [lang, setLang] = useState<'hi' | 'en'>('hi');

  // Reels State
  const [reels, setReels] = useState<ReelItem[]>(() => {
    const saved = localStorage.getItem('rb_reels');
    return saved ? JSON.parse(saved) : INITIAL_REELS;
  });
  const [currentReelIndex, setCurrentReelIndex] = useState<number>(0);

  // Hidden/Reported Reels & Blocked Creators
  const [reportedReelIds, setReportedReelIds] = useState<string[]>([]);
  const [blockedCreatorNames, setBlockedCreatorNames] = useState<string[]>([]);

  // User Auth State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('rb_user');
    if (saved) return JSON.parse(saved);
    return {
      id: 'user_aman',
      name: 'Aman Kumar (अमन)',
      handle: '@aman_reels',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      bio: 'रील्स और सोशल शॉपिंग लवर | रील बाज़ार वेरिफाइड खरीदार 🇮🇳',
      followersCount: 420,
      followingCount: 38,
      isSeller: true,
      walletBalance: 3250,
      phone: '+91 9876543210'
    };
  });

  // Followed Creators List
  const [followingCreatorNames, setFollowingCreatorNames] = useState<string[]>([
    'Priya Sharma (प्रिया)'
  ]);

  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 'cart-1',
      product: INITIAL_REELS[0].product,
      quantity: 1,
      size: 'Free Size'
    }
  ]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // Notifications State
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'n1',
      type: 'commission',
      title: '₹280 कमीशन वॉलेट में जमा!',
      body: 'आपकी बनारसी साड़ी रील के जरिए एक नया ऑर्डर प्लेस हुआ है।',
      timestamp: '10 मिनट पहले',
      isRead: false
    },
    {
      id: 'n2',
      type: 'order',
      title: 'ऑर्डर #RB-839211 डिस्पैच हुआ',
      body: 'आपका पार्सल ब्लू डार्ट कूरियर द्वारा भेज दिया गया है।',
      timestamp: '2 घंटे पहले',
      isRead: false
    },
    {
      id: 'n3',
      type: 'chat',
      title: 'Priya Sharma (सेलर) का संदेश',
      body: 'नमस्ते! आपके ऑर्डर के लिए स्पेशल फ्री मैचिंग ब्लाउज पैक किया गया है।',
      timestamp: 'कल',
      isRead: true
    },
    {
      id: 'n4',
      type: 'deal',
      title: '🔥 महा लूट ऑफर: सिल्क साड़ियों पर 65% छूट',
      body: 'सीधे बुनकरों से लिमिटेड फेस्टिव स्टॉक अब लाइव है।',
      timestamp: 'कल',
      isRead: true
    }
  ]);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);

  // Modals State
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [isCommentsOpen, setIsCommentsOpen] = useState<boolean>(false);
  const [activeCommentsReel, setActiveCommentsReel] = useState<ReelItem | null>(null);

  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatProduct, setChatProduct] = useState<ProductItem | null>(null);
  const [chatSeller, setChatSeller] = useState<ReelItem['creator'] | null>(null);

  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [isOrderOpen, setIsOrderOpen] = useState<boolean>(false);
  const [selectedProductForOrder, setSelectedProductForOrder] = useState<ProductItem | null>(null);

  // Product Detail Modal
  const [selectedDetailProduct, setSelectedDetailProduct] = useState<ProductItem | null>(null);

  // Creator Profile Modal
  const [selectedCreatorProfile, setSelectedCreatorProfile] = useState<ReelItem['creator'] | null>(null);

  // Report Modal
  const [selectedReportReel, setSelectedReportReel] = useState<ReelItem | null>(null);

  // Saved / Liked tracking
  const [likedReelIds, setLikedReelIds] = useState<string[]>(['reel-1']);
  const [savedReelIds, setSavedReelIds] = useState<string[]>(['reel-2']);

  // PWA Install prompt handling
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [canInstallPwa, setCanInstallPwa] = useState<boolean>(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setCanInstallPwa(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallPwa = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setCanInstallPwa(false);
      }
      setDeferredPrompt(null);
    } else {
      alert(lang === 'hi'
        ? 'अपने ब्राउज़र मेनू (⋮) पर टैप करें और "Add to Home screen" चुनें।'
        : 'Tap your browser menu (⋮) and select "Add to Home screen" to install.');
    }
  };

  // Sync reels to localStorage
  useEffect(() => {
    localStorage.setItem('rb_reels', JSON.stringify(reels));
  }, [reels]);

  // Sync user
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('rb_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('rb_user');
    }
  }, [currentUser]);

  // Like Reel Handler
  const handleLikeReel = (reelId: string) => {
    setReels(prev =>
      prev.map(r => {
        if (r.id === reelId) {
          const isCurrentlyLiked = likedReelIds.includes(reelId);
          const nextLiked = !isCurrentlyLiked;
          return {
            ...r,
            isLiked: nextLiked,
            likesCount: nextLiked ? r.likesCount + 1 : Math.max(0, r.likesCount - 1)
          };
        }
        return r;
      })
    );

    setLikedReelIds(prev =>
      prev.includes(reelId) ? prev.filter(id => id !== reelId) : [...prev, reelId]
    );
  };

  // Save / Bookmark Reel Handler
  const handleSaveReel = (reelId: string) => {
    setSavedReelIds(prev =>
      prev.includes(reelId) ? prev.filter(id => id !== reelId) : [...prev, reelId]
    );
    setReels(prev =>
      prev.map(r => r.id === reelId ? { ...r, isSaved: !r.isSaved } : r)
    );
  };

  // Follow/Unfollow Handler
  const handleToggleFollow = (creatorName: string) => {
    setFollowingCreatorNames(prev => {
      const exists = prev.includes(creatorName);
      if (exists) {
        return prev.filter(name => name !== creatorName);
      } else {
        // add notification
        const newNotif: NotificationItem = {
          id: 'follow_' + Date.now(),
          type: 'follower',
          title: `अब आप ${creatorName} को फॉलो कर रहे हैं`,
          body: 'इनके नए प्रोडक्ट्स और रील्स सबसे पहले आपकी फीड में दिखेंगे।',
          timestamp: 'अभी-अभी',
          isRead: false
        };
        setNotifications(n => [newNotif, ...n]);
        return [...prev, creatorName];
      }
    });
  };

  // Report & Block Moderation
  const handleReportReel = (reelId: string, _reason: string) => {
    setReportedReelIds(prev => [...prev, reelId]);
    if (currentReelIndex >= visibleReels.length - 1) {
      setCurrentReelIndex(0);
    }
  };

  const handleBlockCreator = (creatorName: string) => {
    setBlockedCreatorNames(prev => [...prev, creatorName]);
    if (currentReelIndex >= visibleReels.length - 1) {
      setCurrentReelIndex(0);
    }
  };

  // Cart Handlers
  const handleAddToCart = (product: ProductItem, size: string = 'Free Size', quantity: number = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id && item.size === size);
      if (existing) {
        return prev.map(item =>
          item.id === existing.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      } else {
        return [
          ...prev,
          {
            id: 'cart_' + Date.now() + Math.random(),
            product,
            size,
            quantity
          }
        ];
      }
    });
  };

  const handleUpdateCartQty = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(cartItemId);
    } else {
      setCartItems(prev =>
        prev.map(item => item.id === cartItemId ? { ...item, quantity: newQty } : item)
      );
    }
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== cartItemId));
  };

  const handleCheckoutFromCart = (_discountAmount: number) => {
    if (cartItems.length > 0) {
      setSelectedProductForOrder(cartItems[0].product);
      setIsCartOpen(false);
      setIsOrderOpen(true);
    }
  };

  // Comment Handlers
  const handleOpenComments = (reel: ReelItem) => {
    setActiveCommentsReel(reel);
    setIsCommentsOpen(true);
  };

  const handleAddComment = (text: string) => {
    if (!activeCommentsReel || !currentUser) return;
    const newComment = {
      id: 'cmt_' + Date.now(),
      author: currentUser.name,
      avatar: currentUser.avatar,
      text: text,
      timeAgo: 'Just now',
      likes: 0
    };

    setReels(prev =>
      prev.map(r => {
        if (r.id === activeCommentsReel.id) {
          const updatedComments = [newComment, ...r.comments];
          return {
            ...r,
            comments: updatedComments,
            commentsCount: updatedComments.length
          };
        }
        return r;
      })
    );

    setActiveCommentsReel(prev => prev ? {
      ...prev,
      comments: [newComment, ...prev.comments],
      commentsCount: prev.comments.length + 1
    } : null);
  };

  const handleLikeComment = (commentId: string) => {
    if (!activeCommentsReel) return;
    setActiveCommentsReel(prev => {
      if (!prev) return null;
      return {
        ...prev,
        comments: prev.comments.map(c =>
          c.id === commentId ? { ...c, likes: (c.likes || 0) + 1, isLiked: true } : c
        )
      };
    });
  };

  // Chat Handler
  const handleOpenChat = (reel?: ReelItem) => {
    if (reel) {
      setChatProduct(reel.product);
      setChatSeller(reel.creator);
    } else {
      setChatProduct(null);
      setChatSeller(null);
    }
    setIsChatOpen(true);
  };

  // Buy / Order Handler
  const handleOpenBuyModal = (product: ProductItem) => {
    setSelectedProductForOrder(product);
    setIsOrderOpen(true);
  };

  // Publish New Reel from Creator Studio
  const handlePublishReel = (newReel: ReelItem) => {
    setReels(prev => [newReel, ...prev]);
    setCurrentReelIndex(0);
    setActiveTab('reels');
    setIsProfileOpen(false);

    // add notification
    const newNotif: NotificationItem = {
      id: 'publish_' + Date.now(),
      type: 'deal',
      title: 'आपकी रील पब्लिश हो गई! 🎬',
      body: 'आपका प्रोडक्ट अब Reel Bajar फीड पर लाइव है और कोई भी इसे ऑर्डर कर सकता है।',
      timestamp: 'अभी-अभी',
      isRead: false
    };
    setNotifications(n => [newNotif, ...n]);
  };

  // Select Reel from Marketplace
  const handleSelectReelByProduct = (reelId: string) => {
    const idx = visibleReels.findIndex(r => r.id === reelId);
    if (idx !== -1) {
      setCurrentReelIndex(idx);
    }
    setActiveTab('reels');
    setIsProfileOpen(false);
  };

  // Filtered Reels excluding reported / blocked
  const visibleReels = reels.filter(
    r => !reportedReelIds.includes(r.id) && !blockedCreatorNames.includes(r.creator.name)
  );

  const myUploadedReels = currentUser ? visibleReels.filter(r => r.creator.name === currentUser.name) : [];
  const likedReelsList = visibleReels.filter(r => likedReelIds.includes(r.id));
  const savedReelsList = visibleReels.filter(r => savedReelIds.includes(r.id));
  const unreadNotificationsCount = notifications.filter(n => !n.isRead).length;

  const [showZipBanner, setShowZipBanner] = useState<boolean>(true);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans pb-16 md:pb-0">
      {/* Quick Source Code ZIP Download Banner */}
      {showZipBanner && (
        <div className="bg-gradient-to-r from-amber-600 via-pink-600 to-purple-700 text-white text-xs px-3 sm:px-4 py-2 flex items-center justify-between gap-2 shadow-md z-30">
          <div className="flex items-center gap-2 font-medium truncate">
            <span className="text-sm sm:text-base flex-shrink-0">📦</span>
            <span className="truncate">
              {lang === 'hi'
                ? 'Reel Bajar पूरा प्रोजेक्ट सोर्स कोड ZIP (104 KB) तैयार है'
                : 'Reel Bajar Full Source Code ZIP (104 KB) ready'}
            </span>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <a
              href="/reel-bajar-source-code.zip"
              download="reel-bajar-source-code.zip"
              className="px-2.5 sm:px-3 py-1 bg-white text-neutral-950 font-black rounded-lg hover:bg-neutral-100 transition-colors shadow-sm text-[11px] sm:text-xs flex items-center gap-1"
            >
              <span>{lang === 'hi' ? 'ZIP डाउनलोड' : 'Download ZIP'}</span>
            </a>
            <button
              onClick={() => setShowZipBanner(false)}
              className="text-white/80 hover:text-white text-xs font-bold px-1"
              title="Close"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Top Main Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setIsProfileOpen(false);
          if (tab === 'create') {
            setIsUploadOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        lang={lang}
        setLang={setLang}
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        unreadNotificationsCount={unreadNotificationsCount}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onInstallPwa={handleInstallPwa}
        canInstallPwa={canInstallPwa}
        onExportZip={exportProjectZip}
      />

      {/* Main Body Content View */}
      <main className="flex-1 flex flex-col">
        {isProfileOpen ? (
          <ProfileView
            currentUser={currentUser}
            onLoginRequest={() => setIsAuthOpen(true)}
            onLogout={() => {
              setCurrentUser(null);
              setIsProfileOpen(false);
            }}
            onUpdateProfile={(updated) => setCurrentUser(updated)}
            myReels={myUploadedReels}
            likedReels={likedReelsList}
            savedReels={savedReelsList}
            onSelectReel={(reel) => {
              const idx = visibleReels.findIndex(r => r.id === reel.id);
              if (idx !== -1) setCurrentReelIndex(idx);
              setIsProfileOpen(false);
              setActiveTab('reels');
            }}
            lang={lang}
          />
        ) : activeTab === 'reels' ? (
          <ReelPlayer
            reels={visibleReels}
            currentReelIndex={currentReelIndex}
            setCurrentReelIndex={setCurrentReelIndex}
            onLikeReel={handleLikeReel}
            onSaveReel={handleSaveReel}
            onOpenComments={handleOpenComments}
            onOpenChat={handleOpenChat}
            onOpenBuyModal={handleOpenBuyModal}
            onOpenProductDetail={(prod) => setSelectedDetailProduct(prod)}
            onOpenCreatorProfile={(creator) => setSelectedCreatorProfile(creator)}
            onOpenReportModal={(reel) => setSelectedReportReel(reel)}
            followingCreatorNames={followingCreatorNames}
            onToggleFollow={handleToggleFollow}
            lang={lang}
          />
        ) : activeTab === 'bajar' ? (
          <BajarMarketplace
            reels={visibleReels}
            onSelectReelByProduct={handleSelectReelByProduct}
            onOpenBuyModal={handleOpenBuyModal}
            onOpenProductDetail={(prod) => setSelectedDetailProduct(prod)}
            onAddToCart={(prod) => handleAddToCart(prod)}
            lang={lang}
          />
        ) : activeTab === 'launch' ? (
          <PlayStoreLaunchHub lang={lang} />
        ) : null}
      </main>

      {/* Mobile Bottom Navigation Bar (Instagram/TikTok/Meesho style) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-neutral-950/95 backdrop-blur-md border-t border-neutral-800/80 px-2 py-1.5 flex items-center justify-around">
        {/* 1. Home / Reels */}
        <button
          onClick={() => {
            setIsProfileOpen(false);
            setActiveTab('reels');
          }}
          className={`flex flex-col items-center gap-0.5 py-1 px-2 transition-colors ${
            !isProfileOpen && activeTab === 'reels' ? 'text-pink-500 font-bold' : 'text-neutral-400'
          }`}
        >
          <Film className="w-5 h-5" />
          <span className="text-[10px]">{lang === 'hi' ? 'रील्स' : 'Reels'}</span>
        </button>

        {/* 2. Bajar / Shop */}
        <button
          onClick={() => {
            setIsProfileOpen(false);
            setActiveTab('bajar');
          }}
          className={`flex flex-col items-center gap-0.5 py-1 px-2 transition-colors ${
            !isProfileOpen && activeTab === 'bajar' ? 'text-pink-500 font-bold' : 'text-neutral-400'
          }`}
        >
          <ShoppingBag className="w-5 h-5" />
          <span className="text-[10px]">{lang === 'hi' ? 'बाज़ार' : 'Bajar'}</span>
        </button>

        {/* 3. Central Upload / Create Reel Button */}
        <button
          onClick={() => setIsUploadOpen(true)}
          className="flex flex-col items-center gap-0.5 py-1 px-2 text-pink-500 hover:scale-105 transition-transform"
        >
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-pink-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-pink-600/30">
            <PlusCircle className="w-5 h-5" />
          </div>
          <span className="text-[9px] font-bold text-neutral-300">{lang === 'hi' ? 'अपलोड' : 'Post'}</span>
        </button>

        {/* 4. Chat */}
        <button
          onClick={() => handleOpenChat()}
          className="flex flex-col items-center gap-0.5 py-1 px-2 text-neutral-400 hover:text-white transition-colors"
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[10px]">{lang === 'hi' ? 'चैट' : 'Chat'}</span>
        </button>

        {/* 5. Profile */}
        <button
          onClick={() => {
            if (!currentUser) {
              setIsAuthOpen(true);
            } else {
              setIsProfileOpen(true);
            }
          }}
          className={`flex flex-col items-center gap-0.5 py-1 px-2 transition-colors ${
            isProfileOpen ? 'text-pink-500 font-bold' : 'text-neutral-400'
          }`}
        >
          {currentUser ? (
            <img
              src={currentUser.avatar}
              alt="avatar"
              className="w-5 h-5 rounded-full object-cover border border-neutral-700"
            />
          ) : (
            <UserIcon className="w-5 h-5" />
          )}
          <span className="text-[10px]">{lang === 'hi' ? 'प्रोफाइल' : 'Profile'}</span>
        </button>
      </nav>

      {/* Global Modals */}
      {/* 1. Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          setIsProfileOpen(true);
        }}
        lang={lang}
      />

      {/* 2. Comments Drawer */}
      <CommentsDrawer
        isOpen={isCommentsOpen}
        onClose={() => setIsCommentsOpen(false)}
        comments={activeCommentsReel ? activeCommentsReel.comments : []}
        onAddComment={handleAddComment}
        onLikeComment={handleLikeComment}
        currentUser={currentUser}
        onRequireAuth={() => setIsAuthOpen(true)}
        lang={lang}
      />

      {/* 3. Direct Chat Modal */}
      <ChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        currentUser={currentUser}
        onRequireAuth={() => setIsAuthOpen(true)}
        lang={lang}
        initialProduct={chatProduct}
        initialSeller={chatSeller}
        allProducts={visibleReels.map(r => r.product)}
        onOpenBuyModal={handleOpenBuyModal}
        onOpenProductDetail={(prod) => setSelectedDetailProduct(prod)}
      />

      {/* 4. Video Upload / Reel Creator Studio Modal */}
      <VideoUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onPublishReel={handlePublishReel}
        currentUser={currentUser}
        onRequireAuth={() => setIsAuthOpen(true)}
        lang={lang}
      />

      {/* 5. Instant Checkout / Order Modal */}
      <OrderModal
        isOpen={isOrderOpen}
        onClose={() => setIsOrderOpen(false)}
        product={selectedProductForOrder}
        currentUser={currentUser}
        onRequireAuth={() => setIsAuthOpen(true)}
        lang={lang}
      />

      {/* 6. Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        onCheckout={handleCheckoutFromCart}
        onExploreBajar={() => {
          setActiveTab('bajar');
          setIsProfileOpen(false);
        }}
        lang={lang}
      />

      {/* 7. Product Detail Modal */}
      <ProductDetailModal
        isOpen={!!selectedDetailProduct}
        onClose={() => setSelectedDetailProduct(null)}
        product={selectedDetailProduct}
        onAddToCart={(prod, size, qty) => {
          handleAddToCart(prod, size, qty);
          setIsCartOpen(true);
        }}
        onBuyNow={(prod) => {
          handleOpenBuyModal(prod);
        }}
        onWatchReel={() => {
          if (selectedDetailProduct) {
            handleSelectReelByProduct(selectedDetailProduct.id);
          }
        }}
        onOpenChat={() => {
          if (selectedDetailProduct) {
            setChatProduct(selectedDetailProduct);
            const foundReel = visibleReels.find(r => r.product.id === selectedDetailProduct.id);
            if (foundReel) {
              setChatSeller(foundReel.creator);
            } else {
              setChatSeller({
                name: selectedDetailProduct.sellerName,
                handle: `@${selectedDetailProduct.sellerName.toLowerCase().replace(/\s+/g, '_')}`,
                avatar: selectedDetailProduct.image,
                isVerified: selectedDetailProduct.isVerifiedSeller,
                followers: '50K'
              });
            }
            setIsChatOpen(true);
          }
        }}
        lang={lang}
      />

      {/* 8. Creator Profile Modal */}
      <CreatorProfileModal
        isOpen={!!selectedCreatorProfile}
        onClose={() => setSelectedCreatorProfile(null)}
        creator={selectedCreatorProfile}
        reels={visibleReels}
        isFollowing={selectedCreatorProfile ? followingCreatorNames.includes(selectedCreatorProfile.name) : false}
        onToggleFollow={handleToggleFollow}
        onSelectReel={(reel) => {
          const idx = visibleReels.findIndex(r => r.id === reel.id);
          if (idx !== -1) setCurrentReelIndex(idx);
          setActiveTab('reels');
          setIsProfileOpen(false);
        }}
        onOpenChat={(reel) => {
          if (selectedCreatorProfile) {
            setChatSeller(selectedCreatorProfile);
            setChatProduct(reel ? reel.product : null);
            setIsChatOpen(true);
          }
        }}
        onOpenBuyModal={handleOpenBuyModal}
        onAddToCart={(prod) => {
          handleAddToCart(prod);
          setIsCartOpen(true);
        }}
        lang={lang}
      />

      {/* 9. Report & Moderation Modal */}
      <ReportModal
        isOpen={!!selectedReportReel}
        onClose={() => setSelectedReportReel(null)}
        reel={selectedReportReel}
        onReportReel={handleReportReel}
        onBlockCreator={handleBlockCreator}
        lang={lang}
      />

      {/* 10. Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllRead={() => {
          setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
        }}
        onNotificationClick={(notif) => {
          setNotifications(prev =>
            prev.map(n => n.id === notif.id ? { ...n, isRead: true } : n)
          );
          setIsNotificationsOpen(false);
          if (notif.type === 'commission') {
            setIsProfileOpen(true);
          } else if (notif.type === 'chat') {
            setIsChatOpen(true);
          } else if (notif.type === 'order') {
            setIsProfileOpen(true);
          } else if (notif.type === 'deal') {
            setActiveTab('bajar');
            setIsProfileOpen(false);
          }
        }}
        lang={lang}
      />
    </div>
  );
}
